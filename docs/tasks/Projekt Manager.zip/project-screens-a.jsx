// Accurate mockups for ProjectsPage, ProjectDetailPage, ProjectForm —
// modeled exactly after apps/web/src/pages/{ProjectsPage,ProjectDetailPage}.tsx
// and apps/web/src/components/projects/ProjectForm.tsx on branch main.
//
// Re-uses shell.jsx atoms: AppShell, Sidebar, TopBar, PageHeader, Section,
// Pill, Badge, Icon, useLucide.

const PROJ_SAMPLE = [
  { id: 1, name: "Apollo CRM", code: "AC", status: "active", statusLabel: "Aktiv", statusTone: "fern", color: "#2E5984", desc: "Konsolidierung der Kundendaten und Migration des Vertriebs-Funnels in das neue CRM. Steering Committee jeden 2. Mittwoch.", tags: [{ name: "Roadmap", color: "#4D9359" }, { name: "Backend", color: "#2E5984" }], done: 18, total: 32, openCount: 7, updatedAt: "12. Mai 2026" },
  { id: 2, name: "Helios Reporting", code: "HR", status: "active", statusLabel: "Aktiv", statusTone: "fern", color: "#2F8E96", desc: "Monatliche Vertriebsberichte automatisieren – Excel-Export ablösen.", tags: [{ name: "Daten", color: "#2F8E96" }], done: 9, total: 14, openCount: 3 },
  { id: 3, name: "Orion Onboarding", code: "OO", status: "on_hold", statusLabel: "Pausiert", statusTone: "tangerine", color: "#ED8C3A", desc: "Neuer Self-Service-Flow für Onboarding bei Bestandskunden.", tags: [{ name: "UX", color: "#C13D9A" }], done: 4, total: 22, openCount: 8 },
  { id: 4, name: "Lumen Mobile", code: "LM", status: "on_hold", statusLabel: "Pausiert", statusTone: "tangerine", color: "#D9416A", desc: "Mobile-App MVP wartet auf Freigabe vom Steering Committee.", tags: [], done: 6, total: 18, openCount: 6 },
  { id: 5, name: "Atlas Migration", code: "AM", status: "completed", statusLabel: "Abgeschlossen", statusTone: "violet", color: "#6A40BE", desc: "Migration von Legacy-System abgeschlossen.", tags: [{ name: "Infra", color: "#1B355C" }], done: 24, total: 24, openCount: 0 },
  { id: 6, name: "Vega Archiv", code: "VA", status: "archived", statusLabel: "Archiviert", statusTone: "steel", color: "#6B92BD", desc: "Alte Wikis und Dokumente konsolidiert für Auditzwecke.", tags: [], done: 12, total: 12, openCount: 0 }
];

// Reusable bits matching code in apps/web/src/components/ui/*
function PSProjectCardBoard({ p }) {
  const progress = p.total > 0 ? Math.round((p.done / p.total) * 100) : 0;
  return (
    <article className="card overflow-hidden">
      <div style={{ background: p.color, height: 4 }}></div>
      <div className="p-4 grid gap-3">
        <div className="flex items-start gap-3">
          <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl text-white shadow-sm" style={{ background: p.color }}>
            <Icon name="folder-open" size={20} />
          </span>
          <div className="min-w-0">
            <h2 className="text-base font-semibold text-ink leading-tight">{p.name}</h2>
            <p className="mt-1 font-mono text-xs uppercase text-slate-500">{p.code}</p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Pill tone={p.statusTone}>{p.statusLabel}</Pill>
          {p.tags.map((t) => <Badge key={t.name} color={t.color}>{t.name}</Badge>)}
        </div>
        {p.desc ? <p className="text-sm text-slate-600 line-clamp-3">{p.desc}</p> : null}
        <div className="grid gap-2 border-t border-line pt-3">
          {p.total > 0 ? <Progress value={progress} color={p.color} label={`${p.done} / ${p.total} erledigt`} /> : null}
          <span className="justify-self-end text-xs font-semibold text-slate-500">{p.openCount} offen</span>
        </div>
      </div>
    </article>
  );
}

function PSProjectRow({ p }) {
  return (
    <article className="card flex items-stretch overflow-hidden">
      <div style={{ background: p.color, width: 4 }}></div>
      <div className="flex flex-1 items-center gap-4 p-4">
        <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl text-white" style={{ background: p.color }}>
          <Icon name="folder-open" size={20} />
        </span>
        <div className="min-w-0 flex-1">
          <h3 className="text-sm font-semibold text-ink">{p.name}</h3>
          {p.desc ? <p className="text-xs text-slate-600 truncate">{p.desc}</p> : null}
        </div>
        <div className="flex items-center gap-2">
          <Pill tone={p.statusTone}>{p.statusLabel}</Pill>
          {p.tags[0] ? <Badge color={p.tags[0].color}>{p.tags[0].name}</Badge> : null}
        </div>
        <span className="text-xs font-semibold text-slate-500 w-20 text-right">{p.openCount} offen</span>
        <div className="flex gap-1">
          <button className="btn btn-ghost btn-icon"><Icon name="edit-3" size={18} /></button>
          <button className="btn btn-ghost btn-icon"><Icon name="trash-2" size={18} /></button>
        </div>
      </div>
    </article>
  );
}

// ───── 1) ProjectsPage – Board ─────
window.PS_ProjectsPageBoard = function () {
  useLucide();
  const cols = [
    { value: "active", label: "Aktiv" }, { value: "on_hold", label: "Pausiert" },
    { value: "completed", label: "Abgeschlossen" }, { value: "archived", label: "Archiviert" }
  ];
  return (
    <AppShell active="/projects">
      <PageHeader title="Projekte" subtitle="6 Einträge" />
      <ListBoardChrome viewMode="board" addLabel="Neues Projekt" filters={
        <FilterChips value="all" allCount={6} options={[
          { value: "active", label: "Aktiv", count: 2 }, { value: "on_hold", label: "Pausiert", count: 2 },
          { value: "completed", label: "Abgeschlossen", count: 1 }, { value: "archived", label: "Archiviert", count: 1 }
        ]} />
      } />
      <div className="grid grid-flow-col auto-cols-[minmax(17rem,1fr)] gap-4 overflow-x-auto pb-2">
        {cols.map((col) => {
          const items = PROJ_SAMPLE.filter((p) => p.status === col.value);
          return (
            <section key={col.value} className="grid min-h-[260px] content-start gap-3 rounded-lg border border-line p-3" style={{ background: "rgba(244,247,250,0.6)" }}>
              <header className="flex items-center justify-between gap-3">
                <h2 className="truncate text-sm font-semibold text-ink">{col.label}</h2>
                <div className="flex items-center gap-2">
                  <span className="rounded-full bg-white px-2 py-1 text-xs font-semibold text-slate-600 shadow-sm">{items.length}</span>
                  <button className="btn btn-ghost btn-icon" style={{ background: "#fff", border: "1px solid var(--color-line)" }}><Icon name="plus" size={18} /></button>
                </div>
              </header>
              {items.map((p) => <PSProjectCardBoard key={p.id} p={p} />)}
            </section>
          );
        })}
      </div>
    </AppShell>
  );
};

// ───── 2) ProjectsPage – Liste ─────
window.PS_ProjectsPageList = function () {
  useLucide();
  return (
    <AppShell active="/projects">
      <PageHeader title="Projekte" subtitle="6 Einträge" />
      <ListBoardChrome viewMode="list" addLabel="Neues Projekt" filters={
        <FilterChips value="all" allCount={6} options={[
          { value: "active", label: "Aktiv", count: 2 }, { value: "on_hold", label: "Pausiert", count: 2 },
          { value: "completed", label: "Abgeschlossen", count: 1 }, { value: "archived", label: "Archiviert", count: 1 }
        ]} />
      } />
      <div className="grid gap-3">
        {PROJ_SAMPLE.map((p) => <PSProjectRow key={p.id} p={p} />)}
      </div>
    </AppShell>
  );
};

// ───── 3) ProjectDetailPage – nur Hero ─────
// Source: apps/web/src/pages/ProjectDetailPage.tsx
// Inhalt: Hero-Header (Steel→Violet) mit Breadcrumb, Titel, Beschreibung,
// "Bearbeiten"-Button und 5 Stats. Mehr ist es nicht – die eigentliche
// Verwaltung passiert im ProjectForm-Modal nach Klick auf "Bearbeiten".
window.PS_ProjectDetailPage = function () {
  useLucide();
  const p = PROJ_SAMPLE[0];
  const progress = p.total > 0 ? Math.round((p.done / p.total) * 100) : 0;
  return (
    <AppShell active="/projects">
      <header className="relative overflow-hidden rounded-2xl p-6 text-white" style={{ background: "linear-gradient(135deg, var(--color-steel-700), var(--color-steel-600), var(--color-violet))", boxShadow: "var(--shadow-steel)" }}>
        <div className="pointer-events-none absolute -right-20 -top-48 h-[480px] w-[480px] rounded-full bg-white/10 blur-sm"></div>
        <div className="relative grid gap-5">
          <div className="flex flex-wrap items-start justify-between gap-5">
            <div className="min-w-0">
              <nav className="flex flex-wrap items-center gap-2 text-sm text-white/70">
                <a className="hover:text-white">Projekte</a>
                <Icon name="chevron-right" size={16} />
                <span className="text-white">{p.name}</span>
              </nav>
              <h1 className="mt-3 text-[30px] font-bold leading-tight tracking-normal">{p.name}</h1>
              <p className="mt-1 max-w-[720px] text-[15px] leading-6 text-white/85">{p.desc}</p>
            </div>
            <button className="btn btn-ghost text-white" style={{ background: "rgba(255,255,255,0.1)", border: "1px solid rgba(255,255,255,0.2)" }}>
              <Icon name="edit-3" size={17} />Bearbeiten
            </button>
          </div>
          <div className="grid gap-4 border-t border-white/20 pt-5 sm:grid-cols-2 lg:grid-cols-5">
            {[
              { label: "Fortschritt", value: `${progress} %` },
              { label: "Aufgaben", value: `${p.done} / ${p.total}` },
              { label: "Offen", value: p.openCount },
              { label: "Backlog", value: 6 },
              { label: "Aktualisiert", value: p.updatedAt }
            ].map((s, i) => (
              <div key={i}>
                <span className="kicker-light">{s.label}</span>
                <span className="mt-1 block text-2xl font-bold">{s.value}</span>
              </div>
            ))}
          </div>
        </div>
      </header>
    </AppShell>
  );
};
