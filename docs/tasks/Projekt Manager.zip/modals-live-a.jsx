// Live modals — ProjectForm, FeatureForm, TicketForm, EventForm, WikiForm.

// ───── Project Form ─────
function LiveProjectForm() {
  const { modal, closeModal, setModalTab, openModal } = useNav();
  const isEdit = modal.mode === "edit";
  const project = modal.entity;
  const activeTab = modal.tab || "details";
  const tabs = [
    { value: "details", label: "Details" },
    { value: "milestones", label: "Meilensteine", count: project ? (MOCK.milestones[project.id] || []).length : 0 },
    { value: "features", label: "Features", count: project ? (MOCK.projectFeatures[project.id] || []).length : 0 },
    { value: "tasks", label: "Aufgaben", count: project ? (MOCK.tasks[project.id] || []).length : 0 },
    { value: "tickets", label: "Tickets", count: project ? MOCK.tickets.filter((t) => t.projectId === project.id).length : 0 },
    { value: "comments", label: "Kommentare", count: 4 },
    { value: "notes", label: "Notizen", count: 2 },
    { value: "attachments", label: "Dateien", count: 6 },
    { value: "backlog", label: "Backlog", count: project ? (MOCK.backlog[project.id] || []).length : 0 },
    { value: "import", label: "Import" }
  ].filter((t) => isEdit || t.value !== "import");

  return (
    <LiveModalShell
      icon="folder-kanban"
      breadcrumb={["Projekte", isEdit ? project.name : "Neues Projekt"]}
      title={isEdit ? "Projekt bearbeiten" : "Projekt anlegen"}
      subtitle={isEdit ? `Zuletzt aktualisiert am ${project.updatedAt}` : "Stammdaten, Status und Beziehungen festlegen."}
      submitLabel={isEdit ? "Speichern" : "Projekt anlegen"}
      footerStart={isEdit ? <button onClick={closeModal} className="btn btn-ghost text-crimson"><Icon name="trash-2" size={17} />Löschen</button> : null}
      onClose={closeModal}
    >
      <LiveTabBar tabs={tabs} active={activeTab} onChange={setModalTab} />
      <div className="grid min-h-0 flex-1 gap-5 overflow-auto bg-shell p-5">
        {activeTab === "details" ? <ProjectFormDetails project={project} /> : null}
        {activeTab === "milestones" ? <ProjectFormMilestones project={project} isEdit={isEdit} /> : null}
        {activeTab === "features" ? <ProjectFormFeatures project={project} openModal={openModal} /> : null}
        {activeTab === "tasks" ? <ProjectFormTasks project={project} /> : null}
        {activeTab === "tickets" ? <ProjectFormTickets project={project} openModal={openModal} /> : null}
        {activeTab === "backlog" ? <ProjectFormBacklog project={project} /> : null}
        {activeTab === "comments" ? <ProjectFormComments /> : null}
        {activeTab === "notes" ? <ProjectFormNotes /> : null}
        {activeTab === "attachments" ? <ProjectFormAttachments /> : null}
        {activeTab === "import" ? <ProjectFormImport /> : null}
      </div>
    </LiveModalShell>
  );
}

function RteMock({ html, minHeight = "9rem" }) {
  return (
    <div className="rte" style={{ minHeight }}>
      <div className="rte-toolbar">
        {["B", "I", "U", "S"].map((t) => <button key={t} className="rte-btn">{t}</button>)}
        <span className="mx-1 w-px bg-line"></span>
        {["H1", "H2"].map((t) => <button key={t} className="rte-btn">{t}</button>)}
        <span className="mx-1 w-px bg-line"></span>
        <button className="rte-btn"><Icon name="list" size={14} /></button>
        <button className="rte-btn"><Icon name="list-ordered" size={14} /></button>
        <button className="rte-btn"><Icon name="link" size={14} /></button>
        <button className="rte-btn"><Icon name="image" size={14} /></button>
      </div>
      <div className="rte-body" dangerouslySetInnerHTML={{ __html: html }}></div>
    </div>
  );
}

function ProjectFormDetails({ project }) {
  const swatches = ["#2E5984", "#D9416A", "#ED8C3A", "#E2BA2C", "#4D9359", "#2F8E96", "#6A40BE", "#C13D9A", "#0F2542"];
  const [color, setColor] = React.useState(project?.color || swatches[0]);
  const [status, setStatus] = React.useState(project?.status || "active");
  return (
    <>
      <Section title="Stammdaten">
        <div className="grid gap-4 md:grid-cols-[minmax(0,1fr)_10rem]">
          <Field label="Projektname" required><input className="input" defaultValue={project?.name || ""} placeholder="z. B. Apollo CRM" /></Field>
          <Field label="Kürzel"><input className="input input-mono" defaultValue={project?.code || ""} readOnly /></Field>
        </div>
        <div className="mt-4"><Field label="Beschreibung">
          <RteMock html={project?.desc || "<p style='color:#94a3b8'>Worum geht es in diesem Projekt?</p>"} />
        </Field></div>
      </Section>
      <Section title="Identität">
        <div className="grid gap-4 md:grid-cols-2">
          <Field label="Farbe">
            <div className="flex flex-wrap gap-2">
              {swatches.map((s) => (
                <button key={s} type="button" onClick={() => setColor(s)} className={`h-9 w-9 rounded-full border-2 ${color === s ? "border-steel-900" : "border-white"}`} style={{ background: s, boxShadow: "0 0 0 1px var(--color-line)" }}></button>
              ))}
            </div>
          </Field>
          <Field label="Status">
            <div className="inline-flex items-center gap-1 rounded-md border border-line bg-white p-1">
              {[
                { value: "active", label: "Aktiv", color: "var(--color-steel-700)" },
                { value: "on_hold", label: "Pausiert", color: "var(--color-tangerine)" },
                { value: "completed", label: "Abgeschlossen", color: "var(--color-violet)" },
                { value: "archived", label: "Archiviert", color: "var(--color-steel-700)" }
              ].map((o) => (
                <button key={o.value} type="button" onClick={() => setStatus(o.value)} className={`h-9 px-3 rounded-sm text-sm font-semibold transition ${o.value === status ? "text-white" : "text-slate-600 hover:text-ink"}`} style={o.value === status ? { background: o.color } : {}}>
                  {o.label}
                </button>
              ))}
            </div>
          </Field>
        </div>
      </Section>
      <Section title="Zeitraum">
        <div className="grid gap-4 md:grid-cols-2">
          <Field label="Start"><input className="input" type="date" defaultValue={project?.startDate || ""} /></Field>
          <Field label="Fällig"><input className="input" type="date" defaultValue={project?.dueDate || ""} /></Field>
        </div>
      </Section>
      <Section title="Tags">
        <div className="flex flex-wrap gap-2">
          {(project?.tags || []).map((t) => <Badge key={t.name} color={t.color}>{t.name} ✕</Badge>)}
          <button className="badge badge-mute" style={{ borderStyle: "dashed" }}>+ Tag</button>
        </div>
      </Section>
    </>
  );
}

function ProjectFormFeatures({ project, openModal }) {
  const features = (MOCK.projectFeatures[project?.id] || []).map((fid) => MOCK.features.find((f) => f.id === fid)).filter(Boolean);
  return (
    <Section title="Features" action={<div className="flex gap-2"><button className="btn btn-secondary"><Icon name="link" size={17} />Verknüpfen</button><button className="btn btn-primary"><Icon name="plus" size={17} />Neu</button></div>}>
      <div className="grid gap-3 md:grid-cols-2">
        {features.map((f) => (
          <article key={f.id} className="card p-4 grid gap-2">
            <div className="flex items-start gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-steel-600 text-white"><Icon name="book-open" size={18} /></span>
              <div>
                <h3 className="text-sm font-semibold text-ink">{f.title}</h3>
                <p className="font-mono text-xs text-slate-500">/features/{f.slug}</p>
                <span className="mt-1 inline-flex"><Pill tone={f.statusTone}>{f.statusLabel}</Pill></span>
              </div>
            </div>
            <div className="flex justify-end gap-1 border-t border-line pt-2">
              <button className="btn btn-ghost btn-icon"><Icon name="unlink" size={17} /></button>
            </div>
          </article>
        ))}
      </div>
    </Section>
  );
}

function ProjectFormTasks({ project }) {
  const tasks = MOCK.tasks[project?.id] || [];
  return (
    <Section title="Aufgaben" action={<div className="flex gap-2"><button className="btn btn-secondary"><Icon name="link" size={17} />Verknüpfen</button><button className="btn btn-primary"><Icon name="plus" size={17} />Neue Aufgabe</button></div>}>
      <div className="grid grid-cols-3 gap-3">
        {[
          { col: "Offen", tone: "crimson", value: "todo" },
          { col: "In Arbeit", tone: "tangerine", value: "in_progress" },
          { col: "Erledigt", tone: "fern", value: "done" }
        ].map((c) => {
          const items = tasks.filter((t) => t.status === c.value);
          return (
            <section key={c.col} className="grid content-start gap-2 rounded-lg border border-line p-3" style={{ background: "rgba(244,247,250,0.6)" }}>
              <header className="flex items-center justify-between">
                <div className="flex items-center gap-2"><span className="h-2 w-2 rounded-full" style={{ background: `var(--color-${c.tone})` }}></span><h3 className="text-sm font-semibold">{c.col}</h3></div>
                <span className="rounded-full bg-white px-2 py-0.5 text-xs font-semibold text-slate-600 shadow-sm">{items.length}</span>
              </header>
              {items.map((t, i) => (
                <article key={i} className="card p-3 grid gap-2">
                  <p className="text-sm font-semibold text-ink">{t.title}</p>
                  <div className="flex items-center gap-2"><Badge tone={t.priorityTone}>{t.priorityLabel}</Badge></div>
                  <div className="flex items-center justify-between border-t border-line pt-2 text-xs text-slate-500">
                    <span className="inline-flex items-center gap-1"><Icon name="calendar-clock" size={13} />{t.due}</span>
                    <span className="flex h-6 w-6 items-center justify-center rounded-full bg-steel-100 text-steel-700 text-[10px] font-bold">{t.assignee}</span>
                  </div>
                </article>
              ))}
            </section>
          );
        })}
      </div>
    </Section>
  );
}

function ProjectFormTickets({ project, openModal }) {
  const tickets = MOCK.tickets.filter((t) => t.projectId === project?.id);
  return (
    <Section title="Tickets" action={<div className="flex gap-2"><button className="btn btn-secondary"><Icon name="link" size={17} />Verknüpfen</button><button className="btn btn-primary" onClick={() => openModal({ kind: "ticket-form", mode: "create" })}><Icon name="plus" size={17} />Neues Ticket</button></div>}>
      <div className="grid gap-3">
        {tickets.map((t) => (
          <article key={t.id} className="card flex items-stretch overflow-hidden">
            <div style={{ background: t.priorityColor, width: 4 }}></div>
            <div className="flex flex-1 items-center gap-4 p-3">
              <Icon name="bug" size={16} style={{ color: "var(--color-crimson)" }} />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-ink truncate">TICKET-{t.id} · {t.title}</p>
              </div>
              <Pill tone={t.statusTone}>{t.statusLabel}</Pill>
              <Badge tone={t.priorityTone}>{t.priorityLabel}</Badge>
            </div>
          </article>
        ))}
      </div>
    </Section>
  );
}

function ProjectFormBacklog({ project }) {
  const items = MOCK.backlog[project?.id] || [];
  return (
    <Section title="Backlog" action={<button className="btn btn-primary"><Icon name="plus" size={17} />Neues Item</button>}>
      <div className="card overflow-hidden">
        <div className="grid grid-cols-[minmax(0,1fr)_10rem_8rem_6rem_4rem_auto] gap-3 border-b border-line bg-shell px-4 py-2 text-xs font-bold uppercase text-slate-500">
          <span>Titel</span><span>Feature</span><span>Priorität</span><span>Status</span><span>Effort</span><span className="text-right">Aktionen</span>
        </div>
        {items.map((it, i) => (
          <div key={i} className="grid grid-cols-[minmax(0,1fr)_10rem_8rem_6rem_4rem_auto] items-center gap-3 border-b border-line px-4 py-3 text-sm last:border-b-0">
            <span className="font-medium text-ink truncate">{it.title}</span>
            <span className="text-slate-600 truncate font-mono text-xs">{it.feature}</span>
            <Badge tone={it.priorityTone}>{it.priority}</Badge>
            <Pill tone={it.tone}>{it.status}</Pill>
            <span className="font-mono text-xs text-slate-500">{it.effort}</span>
            <div className="flex justify-end gap-1">
              <button className="btn btn-ghost btn-icon"><Icon name="edit-3" size={17} /></button>
              <button className="btn btn-ghost btn-icon"><Icon name="trash-2" size={17} /></button>
            </div>
          </div>
        ))}
      </div>
    </Section>
  );
}

function ProjectFormComments() {
  const comments = [
    { user: "RM", color: "#2E5984", date: "vor 2h", text: "Steering hat den Migrations-Plan genehmigt. Wir starten mit Phase 2 nächste Woche." },
    { user: "MR", color: "#6A40BE", date: "vor 5h", text: "Datenmapping ist offen — bitte bis Mittwoch klären, sonst rutscht der Smoke-Test." },
    { user: "AK", color: "#2F8E96", date: "gestern", text: "Stakeholder-Interviews sind bis Donnerstag terminiert." },
    { user: "JS", color: "#4D9359", date: "vor 2 Tagen", text: "Reset-Bug ist hotgefixt, Patch geht morgen live." }
  ];
  return (
    <Section title="Kommentare">
      <div className="grid gap-3">
        {comments.map((c, i) => (
          <article key={i} className="card p-4 flex gap-3">
            <span className="flex h-9 w-9 items-center justify-center rounded-full text-white text-xs font-bold" style={{ background: c.color }}>{c.user}</span>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold text-ink">{c.user}</span>
                <span className="text-xs text-slate-500">{c.date}</span>
              </div>
              <p className="mt-1 text-sm text-slate-700">{c.text}</p>
            </div>
          </article>
        ))}
        <div className="card p-3 flex items-end gap-2">
          <textarea className="textarea flex-1" placeholder="Kommentar schreiben…" rows={2}></textarea>
          <button className="btn btn-primary"><Icon name="send" size={17} />Senden</button>
        </div>
      </div>
    </Section>
  );
}

function ProjectFormNotes() {
  const notes = [
    { title: "Onboarding-Notizen Steering", date: "12. Mai 2026", excerpt: "Roadmap-Q3-Themen: Self-Service, Reporting, Audit-Log…" },
    { title: "Migrations-Risiken", date: "08. Mai 2026", excerpt: "Datenmapping CRM ↔ SAP, fehlende Felder bei Kontakten…" }
  ];
  return (
    <Section title="Notizen" action={<button className="btn btn-primary"><Icon name="plus" size={17} />Neue Notiz</button>}>
      <div className="grid gap-3 md:grid-cols-2">
        {notes.map((n, i) => (
          <article key={i} className="card p-4">
            <div className="flex items-center gap-2"><Icon name="sticky-note" size={16} style={{ color: "var(--color-fern)" }} /><h3 className="text-sm font-semibold text-ink">{n.title}</h3></div>
            <p className="mt-2 text-xs text-slate-500">{n.date}</p>
            <p className="mt-2 text-sm text-slate-600">{n.excerpt}</p>
          </article>
        ))}
      </div>
    </Section>
  );
}

function ProjectFormAttachments() {
  const files = [
    { name: "kickoff-meeting.pdf", size: "2.4 MB", icon: "file-text" },
    { name: "datenmodell-v3.png", size: "1.1 MB", icon: "image" },
    { name: "scope-q3-2026.xlsx", size: "84 KB", icon: "file-spreadsheet" },
    { name: "vertrag-anbieter.pdf", size: "612 KB", icon: "file-text" }
  ];
  return (
    <Section title="Dateien">
      <div className="rounded-lg border-2 border-dashed border-line bg-white p-8 text-center">
        <Icon name="upload-cloud" size={28} style={{ color: "var(--color-steel-500)", display: "inline-block" }} />
        <p className="mt-2 text-sm text-slate-600">Dateien per Drag & Drop oder <button className="text-steel-700 font-semibold underline">durchsuchen</button></p>
      </div>
      <div className="grid gap-2 mt-3">
        {files.map((f, i) => (
          <div key={i} className="flex items-center gap-3 rounded-md border border-line bg-white p-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-md bg-steel-100 text-steel-700"><Icon name={f.icon} size={18} /></span>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-ink truncate">{f.name}</p>
              <p className="text-xs text-slate-500">{f.size}</p>
            </div>
            <button className="btn btn-ghost btn-icon"><Icon name="download" size={17} /></button>
            <button className="btn btn-ghost btn-icon text-crimson"><Icon name="trash-2" size={17} /></button>
          </div>
        ))}
      </div>
    </Section>
  );
}

function ProjectFormImport() {
  return (
    <Section title="Wiki-Import">
      <p className="text-sm text-slate-600 mb-3">Importiere ein bestehendes Wiki (Markdown-Verzeichnis) als Feature-Definitionen.</p>
      <Field label="Quell-Pfad"><input className="input input-mono" defaultValue="/wikis/apollo-crm" /></Field>
      <div className="mt-4 flex gap-2">
        <button className="btn btn-secondary"><Icon name="eye" size={17} />Vorschau</button>
        <button className="btn btn-primary"><Icon name="cloud-download" size={17} />Importieren</button>
      </div>
    </Section>
  );
}

// ───── Meilensteine Tab (MilestoneListBoardView) ─────
// Mirrors apps/web/src/components/milestones/MilestoneListBoardView.tsx + MilestoneCard.tsx.
// Status-Spalten nutzen PROJECT_STATUSES (active / on_hold / completed / archived).
function ProjectFormMilestones({ project, isEdit }) {
  const [mode, setMode] = React.useState("board");
  const [search, setSearch] = React.useState("");
  const items = (MOCK.milestones[project?.id] || []).filter((m) => !search.trim() || m.name.toLowerCase().includes(search.toLowerCase()));

  // Empty state in create mode — meilensteine sind erst nach dem Speichern verfügbar.
  if (!isEdit) {
    return (
      <Section title="Meilensteine">
        <EmptyState icon="flag" title="Meilensteine sind nach dem Speichern verfügbar." tone="teal" />
      </Section>
    );
  }

  const cols = [
    { value: "active",    label: "Aktiv" },
    { value: "on_hold",   label: "Pausiert" },
    { value: "completed", label: "Abgeschlossen" },
    { value: "archived", label: "Archiviert" }
  ];

  return (
    <Section title="Meilensteine">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <label className="relative">
          <Icon name="search" size={16} style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", color: "var(--color-slate-400)" }} />
          <input value={search} onChange={(e) => setSearch(e.target.value)} className="h-10 w-64 rounded-md border border-line bg-white pl-9 pr-3 text-sm outline-none focus:border-steel-600" placeholder="Suchen" />
        </label>
        <div className="flex items-center gap-2">
          <div className="inline-flex h-10 items-center gap-1 rounded-md border border-line bg-white p-1">
            <button onClick={() => setMode("list")}  className={`h-8 px-2 rounded-sm ${mode === "list"  ? "bg-steel-700 text-white" : "text-slate-500"}`} title="Liste"><Icon name="list" size={16} /></button>
            <button onClick={() => setMode("board")} className={`h-8 px-2 rounded-sm ${mode === "board" ? "bg-steel-700 text-white" : "text-slate-500"}`} title="Board"><Icon name="layout-grid" size={16} /></button>
          </div>
          <button className="btn btn-primary"><Icon name="plus" size={17} />Neuer Meilenstein</button>
        </div>
      </div>

      {items.length === 0 ? (
        <EmptyState icon="flag" title="Keine Meilensteine" body="Lege Meilensteine an, um Projektziele und abhängige Arbeit zu bündeln." tone="teal" />
      ) : mode === "list" ? (
        <div className="grid gap-3">
          {items.map((m) => (
            <article key={m.id} className="card flex items-stretch overflow-hidden hover:border-steel-600 transition">
              <div style={{ background: m.color, width: 4 }}></div>
              <div className="flex flex-1 items-center gap-4 p-3">
                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl text-white shadow-sm" style={{ background: m.color }}><Icon name="flag" size={20} /></span>
                <div className="min-w-0 flex-1">
                  <h3 className="text-sm font-semibold text-ink">{m.name}</h3>
                  <p className="text-xs text-slate-600 truncate">{m.desc}</p>
                </div>
                <div className="flex items-center gap-2">
                  <Pill tone={m.statusTone}>{m.statusLabel}</Pill>
                  {m.tags[0] ? <Badge color={m.tags[0].color}>{m.tags[0].name}</Badge> : null}
                </div>
                <span className="text-xs font-semibold text-slate-500 w-32 text-right">{m.taskCount} Aufgaben</span>
                <div className="flex gap-1">
                  <button className="btn btn-ghost btn-icon" title="Bearbeiten"><Icon name="edit-3" size={18} /></button>
                  <button className="btn btn-ghost btn-icon" title="Löschen"><Icon name="trash-2" size={18} /></button>
                </div>
              </div>
            </article>
          ))}
        </div>
      ) : (
        <div className="grid grid-flow-col auto-cols-[minmax(17rem,1fr)] gap-4 overflow-x-auto pb-2">
          {cols.map((col) => {
            const colItems = items.filter((m) => m.status === col.value);
            return (
              <section key={col.value} className="grid min-h-[260px] content-start gap-3 rounded-lg border border-line p-3" style={{ background: "rgba(244,247,250,0.6)" }}>
                <header className="flex items-center justify-between gap-3">
                  <h2 className="truncate text-sm font-semibold text-ink">{col.label}</h2>
                  <div className="flex items-center gap-2">
                    <span className="rounded-full bg-white px-2 py-1 text-xs font-semibold text-slate-600 shadow-sm">{colItems.length}</span>
                    <button className="btn btn-ghost btn-icon" style={{ background: "#fff", border: "1px solid var(--color-line)" }} title="Neu"><Icon name="plus" size={18} /></button>
                  </div>
                </header>
                {colItems.map((m) => (
                  <article key={m.id} className="card overflow-hidden hover:shadow-panel transition">
                    <div style={{ background: m.color, height: 4 }}></div>
                    <div className="p-4 grid gap-3 min-h-56">
                      <div className="flex items-start gap-3">
                        <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl text-white shadow-sm" style={{ background: m.color }}><Icon name="flag" size={20} /></span>
                        <div className="min-w-0">
                          <h3 className="line-clamp-2 text-base font-semibold text-ink leading-tight">{m.name}</h3>
                          <p className="mt-1 text-xs font-semibold text-slate-500">{m.dueDate ? `Fällig ${m.dueDate}` : "Ohne Fälligkeit"}</p>
                        </div>
                      </div>
                      <div className="flex flex-wrap items-center gap-2">
                        <Pill tone={m.statusTone}>{m.statusLabel}</Pill>
                        {m.tags.map((t) => <Badge key={t.name} color={t.color}>{t.name}</Badge>)}
                      </div>
                      {m.desc ? <p className="text-sm text-slate-600 line-clamp-3">{m.desc}</p> : null}
                      <div className="flex flex-wrap justify-end gap-2 border-t border-line pt-3">
                        <Badge tone="steel">{m.taskCount} Aufgaben</Badge>
                        <Badge tone="violet">{m.ticketCount} Tickets</Badge>
                        <Badge tone="teal">{m.featureCount} Features</Badge>
                      </div>
                    </div>
                  </article>
                ))}
              </section>
            );
          })}
        </div>
      )}
    </Section>
  );
}

Object.assign(window, { LiveProjectForm, ProjectFormDetails, ProjectFormMilestones, ProjectFormFeatures, ProjectFormTasks, ProjectFormTickets, ProjectFormBacklog, ProjectFormComments, ProjectFormNotes, ProjectFormAttachments, ProjectFormImport });
