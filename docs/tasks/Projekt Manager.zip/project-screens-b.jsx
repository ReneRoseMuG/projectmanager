// ProjectForm artboards – mirror apps/web/src/components/projects/ProjectForm.tsx.
// The FormModal shell (steel→steel-600 gradient header, scroll body, fixed
// footer) wraps a TabBar and the content of the active tab.

const PF_TABS_FULL = [
  { value: "details", label: "Details" },
  { value: "features", label: "Features" },
  { value: "tasks", label: "Aufgaben" },
  { value: "tickets", label: "Tickets" },
  { value: "comments", label: "Kommentare" },
  { value: "notes", label: "Notizen" },
  { value: "attachments", label: "Dateien" },
  { value: "backlog", label: "Backlog" },
  { value: "import", label: "Import" }
];

// ProjectForm filters out "import" when no project (create mode).
const PF_TABS_CREATE = PF_TABS_FULL.filter((t) => t.value !== "import");

const PF_SWATCHES = ["#2E5984", "#D9416A", "#ED8C3A", "#E2BA2C", "#4D9359", "#2F8E96", "#6A40BE", "#C13D9A", "#0F2542"];

function PFShell({ subtitle, tabs, active, counts = {}, footerStart, submitLabel, children }) {
  const tabItems = tabs.map((t) => ({ ...t, count: counts[t.value] }));
  return (
    <FormModal
      breadcrumb={["Projekte", subtitle === "create" ? "Neues Projekt" : "Apollo CRM"]}
      title={subtitle === "create" ? "Projekt anlegen" : "Projekt bearbeiten"}
      subtitle={subtitle === "create" ? "Stammdaten, Status und Beziehungen festlegen." : "Zuletzt aktualisiert am 12. Mai 2026"}
      icon="folder-kanban"
      footerStart={footerStart}
      submitLabel={submitLabel || (subtitle === "create" ? "Projekt anlegen" : "Speichern")}
    >
      <TabBar tabs={tabItems} active={active} />
      <div className="grid min-h-0 flex-1 gap-5 overflow-auto bg-shell p-5">{children}</div>
    </FormModal>
  );
}

// Reusable RTE mock that matches RichTextEditor's appearance from the codebase.
function PFRte({ html, minHeight = "9rem", toolbar = "full" }) {
  const tools = toolbar === "minimal"
    ? ["B", "I", "list"]
    : ["B", "I", "U", "S", "|", "H1", "H2", "H3", "|", "list", "list-ordered", "quote", "code", "link", "image"];
  return (
    <div className="rte" style={{ minHeight }}>
      <div className="rte-toolbar">
        {tools.map((t, i) => t === "|" ? <span key={i} className="mx-1 w-px bg-line"></span> :
          ["list", "list-ordered", "quote", "code", "link", "image"].includes(t)
            ? <button key={i} className="rte-btn"><Icon name={t} size={14} /></button>
            : <button key={i} className="rte-btn">{t}</button>
        )}
      </div>
      <div className="rte-body" dangerouslySetInnerHTML={{ __html: html }}></div>
    </div>
  );
}

// SegmentedControl matching apps/web/src/components/ui/SegmentedControl.tsx
function PFSegmented({ value, options }) {
  return (
    <div className="inline-flex items-center gap-1 rounded-md border border-line bg-white p-1">
      {options.map((o) => (
        <button key={o.value} className={`h-9 px-3 rounded-sm text-sm font-semibold transition ${o.value === value ? "text-white" : "text-slate-600 hover:text-ink"}`} style={o.value === value ? { background: o.bg } : {}}>
          {o.label}
        </button>
      ))}
    </div>
  );
}

// ColorPicker matching apps/web/src/components/ui/ColorPicker.tsx
function PFColorPicker({ value }) {
  return (
    <div className="flex flex-wrap gap-2">
      {PF_SWATCHES.map((s) => (
        <button key={s} className={`h-9 w-9 rounded-full border-2 ${value === s ? "border-steel-900" : "border-white"}`} style={{ background: s, boxShadow: "0 0 0 1px var(--color-line)" }}></button>
      ))}
    </div>
  );
}

// TagPicker — minimal mock
function PFTagPicker({ tags }) {
  return (
    <div className="grid gap-3">
      <div className="flex flex-wrap gap-2">
        {tags.map((t) => <Badge key={t.name} color={t.color}>{t.name} ✕</Badge>)}
        <button className="badge badge-mute" style={{ borderStyle: "dashed" }}>+ Tag</button>
      </div>
      <label className="relative max-w-md">
        <Icon name="search" size={14} style={{ position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)", color: "var(--color-slate-400)" }} />
        <input className="h-10 w-full rounded-md border border-line bg-white pl-8 pr-3 text-sm outline-none focus:border-steel-600" placeholder="Tag suchen oder anlegen…" />
      </label>
    </div>
  );
}

// ───── 4) ProjectForm – CREATE, Tab Details ─────
window.PS_ProjectFormCreate = function () {
  useLucide();
  return (
    <AppShell active="/projects">
      <div className="opacity-30 pointer-events-none">
        <PageHeader title="Projekte" subtitle="6 Einträge" />
        <ListBoardChrome viewMode="board" />
      </div>
      <PFShell subtitle="create" tabs={PF_TABS_CREATE} active="details" counts={{ features: 0, tickets: 0, comments: 0, notes: 0, attachments: 0 }}>
        <Section title="Stammdaten">
          <div className="grid gap-4 md:grid-cols-[minmax(0,1fr)_10rem]">
            <Field label="Projektname" required><input className="input" placeholder="z. B. Apollo CRM" /></Field>
            <Field label="Kürzel"><input className="input input-mono" readOnly placeholder="—" /></Field>
          </div>
          <div className="mt-4"><Field label="Beschreibung">
            <PFRte html="<p style='color:#94a3b8'>Worum geht es in diesem Projekt?</p>" />
          </Field></div>
        </Section>
        <Section title="Identität">
          <div className="grid gap-4 md:grid-cols-2">
            <Field label="Farbe"><PFColorPicker value="#2E5984" /></Field>
            <Field label="Status">
              <PFSegmented value="active" options={[
                { value: "active", label: "Aktiv", bg: "var(--color-steel-700)" },
                { value: "on_hold", label: "Pausiert", bg: "var(--color-tangerine)" },
                { value: "completed", label: "Abgeschlossen", bg: "var(--color-violet)" },
                { value: "archived", label: "Archiviert", bg: "var(--color-steel-700)" }
              ]} />
            </Field>
          </div>
        </Section>
        <Section title="Zeitraum">
          <div className="grid gap-4 md:grid-cols-2">
            <Field label="Start"><input className="input" type="date" /></Field>
            <Field label="Fällig"><input className="input" type="date" /></Field>
          </div>
        </Section>
        <Section title="Tags"><PFTagPicker tags={[]} /></Section>
      </PFShell>
    </AppShell>
  );
};

// ───── 5) ProjectForm – EDIT, Tab Details ─────
window.PS_ProjectFormDetailsEdit = function () {
  useLucide();
  const p = PROJ_SAMPLE[0];
  return (
    <AppShell active="/projects">
      <div className="opacity-30 pointer-events-none">
        <PageHeader title="Projekte" subtitle="6 Einträge" />
      </div>
      <PFShell subtitle="edit" tabs={PF_TABS_FULL} active="details" counts={{ features: 3, tickets: 5, comments: 4, notes: 2, attachments: 6, backlog: 14 }} footerStart={<button className="btn btn-ghost text-crimson"><Icon name="trash-2" size={17} />Löschen</button>}>
        <Section title="Stammdaten">
          <div className="grid gap-4 md:grid-cols-[minmax(0,1fr)_10rem]">
            <Field label="Projektname" required><input className="input" defaultValue={p.name} /></Field>
            <Field label="Kürzel"><input className="input input-mono uppercase text-slate-600" defaultValue={p.code} readOnly /></Field>
          </div>
          <div className="mt-4"><Field label="Beschreibung">
            <PFRte html={`<p>${p.desc}</p>`} />
          </Field></div>
        </Section>
        <Section title="Identität">
          <div className="grid gap-4 md:grid-cols-2">
            <Field label="Farbe"><PFColorPicker value={p.color} /></Field>
            <Field label="Status">
              <PFSegmented value={p.status} options={[
                { value: "active", label: "Aktiv", bg: "var(--color-steel-700)" },
                { value: "on_hold", label: "Pausiert", bg: "var(--color-tangerine)" },
                { value: "completed", label: "Abgeschlossen", bg: "var(--color-violet)" },
                { value: "archived", label: "Archiviert", bg: "var(--color-steel-700)" }
              ]} />
            </Field>
          </div>
        </Section>
        <Section title="Zeitraum">
          <div className="grid gap-4 md:grid-cols-2">
            <Field label="Start"><input className="input" type="date" defaultValue="2026-02-01" /></Field>
            <Field label="Fällig"><input className="input" type="date" defaultValue="2026-09-30" /></Field>
          </div>
        </Section>
        <Section title="Tags"><PFTagPicker tags={p.tags} /></Section>
      </PFShell>
    </AppShell>
  );
};
