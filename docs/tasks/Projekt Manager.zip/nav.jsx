// Navigation + Router + AppShell for the live prototype.

const NavCtx = React.createContext(null);

function NavProvider({ children }) {
  const [path, setPath] = React.useState("/projects");
  const [modal, setModal] = React.useState(null); // { kind, mode, tab, entity }

  const navigate = (next) => setPath(next);
  const openModal = (m) => setModal(m);
  const closeModal = () => setModal(null);
  const setModalTab = (tab) => setModal((m) => ({ ...m, tab }));

  return (
    <NavCtx.Provider value={{ path, navigate, modal, openModal, closeModal, setModalTab }}>
      {children}
    </NavCtx.Provider>
  );
}

function useNav() { return React.useContext(NavCtx); }

// Sidebar — clickable
function LiveSidebar() {
  const { path, navigate } = useNav();
  const items = [
    { to: "/projects", label: "Projekte", icon: "folder-kanban" },
    { to: "/tickets", label: "Tickets", icon: "bug" },
    { to: "/features", label: "Features", icon: "book-open" },
    { to: "/wiki", label: "Wiki", icon: "library" },
    { to: "/calendar", label: "Kalender", icon: "calendar-days" }
  ];
  const settings = [
    { to: "/settings/tags", label: "Tags", icon: "tags" },
    { to: "/settings/backup", label: "Sicherung", icon: "database-backup" },
    { to: "/settings/test-data", label: "Testdaten", icon: "database-zap" }
  ];
  const isActive = (to) => path === to || (to !== "/projects" && path.startsWith(to)) || (to === "/projects" && path.startsWith("/projects")) || (to === "/features" && path.startsWith("/features")) || (to === "/wiki" && path.startsWith("/wiki"));
  const Item = ({ item }) => {
    const sel = isActive(item.to);
    return (
      <button onClick={() => navigate(item.to)} className={`w-full flex h-10 items-center gap-3 rounded-lg px-3 text-sm font-medium transition ${sel ? "bg-white font-semibold text-steel-700 shadow-md" : "text-white/75 hover:bg-white/10"}`}>
        <Icon name={item.icon} size={17} />
        <span className="text-left flex-1">{item.label}</span>
      </button>
    );
  };
  return (
    <aside className="w-64 shrink-0 p-4 text-white" style={{ background: "linear-gradient(180deg, var(--color-steel-700), var(--color-steel-800))" }}>
      <button onClick={() => navigate("/projects")} className="mb-8 flex w-full items-center gap-3 text-left">
        <span className="flex h-10 w-10 items-center justify-center rounded-md text-steel-700 shadow-lg font-bold" style={{ background: "linear-gradient(135deg, var(--color-steel-300), #fff)" }}>TM</span>
        <div>
          <strong className="block text-sm font-bold">Taskmanager</strong>
          <span className="text-[11px] uppercase tracking-widest text-steel-300">Lokal</span>
        </div>
      </button>
      <div className="mb-2 mt-5 px-1.5 text-[10px] font-semibold uppercase tracking-widest text-steel-400">Navigation</div>
      <nav className="grid gap-1">{items.map((i) => <Item key={i.to} item={i} />)}</nav>
      <div className="mb-2 mt-5 px-1.5 text-[10px] font-semibold uppercase tracking-widest text-steel-400">Einstellungen</div>
      <nav className="grid gap-1">{settings.map((i) => <Item key={i.to} item={i} />)}</nav>
    </aside>
  );
}

// TopBar (search is decorative)
function LiveTopBar() {
  return (
    <header className="relative flex h-16 items-center justify-between border-b border-line bg-white px-6 shrink-0">
      <div className="min-w-0 flex-1 max-w-2xl">
        <label className="relative block">
          <Icon name="search" size={16} style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", color: "var(--color-slate-400)" }} />
          <input className="h-10 w-full rounded-md border border-line bg-white pl-9 pr-20 text-sm outline-none focus:border-steel-600" placeholder="Global suchen" />
          <span className="absolute right-2 top-1/2 -translate-y-1/2 rounded border border-line bg-shell px-1.5 py-0.5 text-[10px] font-semibold text-slate-500">Ctrl K</span>
        </label>
      </div>
      <div className="flex items-center gap-3">
        <button className="inline-flex h-8 items-center gap-2 rounded-full bg-fern px-3 text-xs font-semibold uppercase tracking-wide text-white">
          <span className="h-2 w-2 rounded-full bg-white/80"></span>API online
        </button>
      </div>
    </header>
  );
}

// Live AppShell
function LiveShell({ children }) {
  // Refresh lucide on every render of any nested component.
  React.useEffect(() => { if (window.lucide) window.lucide.createIcons(); });
  return (
    <div className="flex h-full w-full bg-shell text-ink" style={{ minHeight: 0 }}>
      <LiveSidebar />
      <div className="flex min-w-0 flex-1 flex-col">
        <LiveTopBar />
        <main className="min-w-0 flex-1 overflow-auto p-6">
          <div className="mx-auto max-w-7xl grid gap-6">{children}</div>
        </main>
      </div>
    </div>
  );
}

// ListBoardChrome with state
function LiveListBoardChrome({ search, setSearch, filters, addLabel = "Neu", onAdd, viewMode, setViewMode }) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-3">
      <label className="relative">
        <Icon name="search" size={16} style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", color: "var(--color-slate-400)" }} />
        <input value={search} onChange={(e) => setSearch(e.target.value)} className="h-10 w-64 rounded-md border border-line bg-white pl-9 pr-3 text-sm outline-none focus:border-steel-600" placeholder="Suchen" />
      </label>
      <div className="flex flex-wrap items-center gap-2">
        {filters}
        <div className="inline-flex h-10 items-center gap-1 rounded-md border border-line bg-white p-1">
          <button onClick={() => setViewMode("list")} className={`h-8 px-2 rounded-sm ${viewMode === "list" ? "bg-steel-700 text-white" : "text-slate-500"}`} title="Liste">
            <Icon name="list" size={16} />
          </button>
          <button onClick={() => setViewMode("board")} className={`h-8 px-2 rounded-sm ${viewMode === "board" ? "bg-steel-700 text-white" : "text-slate-500"}`} title="Board">
            <Icon name="layout-grid" size={16} />
          </button>
        </div>
        <button onClick={onAdd} className="btn btn-primary btn-icon" title={addLabel}><Icon name="plus" size={17} /></button>
      </div>
    </div>
  );
}

// Live filter chips
function LiveFilterChips({ value, onChange, options, allCount }) {
  return (
    <div className="flex flex-wrap items-center gap-2">
      <button onClick={() => onChange("all")} className={`h-9 px-3 rounded-full text-xs font-semibold border ${value === "all" ? "bg-steel-700 text-white border-steel-700" : "bg-white text-slate-600 border-line"}`}>
        Alle <span className="ml-1 opacity-70">{allCount}</span>
      </button>
      {options.map((o) => (
        <button key={o.value} onClick={() => onChange(o.value)} className={`h-9 px-3 rounded-full text-xs font-semibold border ${o.value === value ? "bg-steel-700 text-white border-steel-700" : "bg-white text-slate-600 border-line"}`}>
          {o.label} <span className="ml-1 opacity-70">{o.count}</span>
        </button>
      ))}
    </div>
  );
}

// Walk up the DOM to find the nearest scrolling ancestor.
function findScrollParent(el) {
  let p = el && el.parentElement;
  while (p) {
    const s = getComputedStyle(p);
    if (/(auto|scroll|overlay)/.test(s.overflowY)) return p;
    p = p.parentElement;
  }
  return null;
}

// Live TabBar — sticks to the top of its scroll container. When it docks
// against the top edge it lifts ~3px and gains a soft shadow to visualise
// Z-axis elevation; it settles back down on reverse scroll. Detection uses
// a 1px sentinel placed immediately above the bar so the visual transition
// happens exactly when sticky engages.
function LiveTabBar({ tabs, active, onChange }) {
  const sentinelRef = React.useRef(null);
  const [stuck, setStuck] = React.useState(false);

  React.useEffect(() => {
    const sentinel = sentinelRef.current;
    if (!sentinel) return;
    const root = findScrollParent(sentinel);
    const observer = new IntersectionObserver(
      ([entry]) => setStuck(entry.intersectionRatio < 1),
      { root: root || null, threshold: [1] }
    );
    observer.observe(sentinel);
    return () => observer.disconnect();
  }, []);

  return (
    <>
      {/* Sentinel: while fully visible, the bar is not yet stuck. */}
      <div ref={sentinelRef} aria-hidden="true" style={{ height: 1, marginBottom: -1 }}></div>
      <nav
        className="flex min-h-12 gap-1 overflow-x-auto border-b border-line bg-white px-5"
        style={{
          position: "sticky",
          top: 0,
          zIndex: 30,
          transform: stuck ? "translate3d(0,-3px,0)" : "translate3d(0,0,0)",
          boxShadow: stuck
            ? "0 10px 18px -12px rgba(15,37,66,0.28), 0 4px 8px -6px rgba(15,37,66,0.16)"
            : "0 0 0 rgba(15,37,66,0)",
          transition: "transform 240ms cubic-bezier(.22,.8,.3,1), box-shadow 240ms cubic-bezier(.22,.8,.3,1)",
          willChange: "transform"
        }}
      >
        {tabs.map((tab) => {
          const sel = active === tab.value;
          return (
            <button key={tab.value} onClick={() => onChange(tab.value)} className={`flex h-12 shrink-0 items-center gap-2 border-b-2 px-3 text-sm font-semibold transition ${sel ? "border-steel-700 text-steel-700" : "border-transparent text-slate-500 hover:text-ink"}`}>
              {tab.label}
              {typeof tab.count === "number" ? <span className={`rounded-full px-2 py-0.5 text-xs ${sel ? "bg-steel-700 text-white" : "bg-shell text-slate-500"}`}>{tab.count}</span> : null}
            </button>
          );
        })}
      </nav>
    </>
  );
}

// Live Modal Shell
function LiveModalShell({ headerKind = "steel", icon, breadcrumb, title, subtitle, submitLabel, footerStart, onClose, children, width = 960 }) {
  const headerBg = headerKind === "teal"
    ? "linear-gradient(135deg, var(--color-teal), rgba(47,142,150,0.75))"
    : "linear-gradient(135deg, var(--color-steel-700), var(--color-steel-600))";
  // Close on Esc
  React.useEffect(() => {
    const h = (e) => { if (e.key === "Escape") onClose?.(); };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [onClose]);
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-6" style={{ background: "rgba(15,37,66,0.55)" }} onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} className="flex flex-col overflow-hidden rounded-2xl bg-shell" style={{ width, maxWidth: "100%", maxHeight: "95%", boxShadow: "var(--shadow-modal)" }}>
        <header className="relative shrink-0 overflow-hidden px-6 py-5 text-white" style={{ background: headerBg }}>
          <div className="pointer-events-none absolute -right-8 -top-32 h-80 w-80 rounded-full bg-white/12 blur-sm"></div>
          <div className="relative flex items-start justify-between gap-4">
            <div className="grid gap-2">
              <div className="flex flex-wrap items-center gap-2 text-xs font-semibold uppercase text-white/75">
                {breadcrumb.map((b, i) => <span key={i} className="inline-flex items-center gap-2">{i > 0 ? <span>›</span> : null}<span>{b}</span></span>)}
              </div>
              <div className="flex items-center gap-3">
                <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/12"><Icon name={icon} size={21} /></span>
                <div>
                  <h2 className="text-2xl font-bold tracking-normal">{title}</h2>
                  {subtitle ? <p className="text-sm text-white/75">{subtitle}</p> : null}
                </div>
              </div>
            </div>
            <button onClick={onClose} className="flex h-9 w-9 items-center justify-center rounded-full text-white/80 hover:bg-white/12"><Icon name="x" size={18} /></button>
          </div>
        </header>
        {children}
        <footer className="flex shrink-0 flex-wrap items-center justify-between gap-3 border-t border-line bg-white px-5 py-4">
          <div className="flex items-center gap-2">{footerStart}</div>
          <div className="flex items-center gap-3">
            <button onClick={onClose} className="btn btn-secondary">Abbrechen</button>
            <button onClick={onClose} className="btn btn-primary"><Icon name="save" size={17} />{submitLabel}</button>
          </div>
        </footer>
      </div>
    </div>
  );
}

// Live Page-Form Shell — same chrome as LiveModalShell, but rendered inline as
// a route (variant="page" in apps/web/src/components/ui/FormModal.tsx).
// Used by /projects/:id and /projects/new (the actual ProjectDetailPage in main).
function LivePageFormShell({ headerKind = "steel", icon, breadcrumb, title, subtitle, submitLabel = "Speichern", footerStart, onClose, children }) {
  const headerBg = headerKind === "teal"
    ? "linear-gradient(135deg, var(--color-teal), rgba(47,142,150,0.75))"
    : "linear-gradient(135deg, var(--color-steel-700), var(--color-steel-600))";
  return (
    <div className="mx-auto flex w-full max-w-7xl flex-col overflow-hidden rounded-2xl bg-shell" style={{ boxShadow: "var(--shadow-panel)", height: "calc(100vh - 112px)" }}>
      {/* Scroll container — header scrolls away, TabBar (inside children) sticks to the top */}
      <div className="flex-1 min-w-0 overflow-y-auto overflow-x-hidden">
        <header className="relative overflow-hidden px-6 py-5 text-white" style={{ background: headerBg }}>
          <div className="pointer-events-none absolute -right-8 -top-32 h-80 w-80 rounded-full bg-white/12 blur-sm"></div>
          <div className="relative flex items-start justify-between gap-4">
            <div className="grid gap-2">
              <div className="flex flex-wrap items-center gap-2 text-xs font-semibold uppercase text-white/75">
                {breadcrumb.map((b, i) => <span key={i} className="inline-flex items-center gap-2">{i > 0 ? <span>›</span> : null}<span>{b}</span></span>)}
              </div>
              <div className="flex items-center gap-3">
                <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/12"><Icon name={icon} size={21} /></span>
                <div>
                  <h2 className="text-2xl font-bold tracking-normal">{title}</h2>
                  {subtitle ? <p className="text-sm text-white/75">{subtitle}</p> : null}
                </div>
              </div>
            </div>
            <button onClick={onClose} className="flex h-9 w-9 items-center justify-center rounded-full text-white/80 hover:bg-white/12" title="Schließen"><Icon name="x" size={18} /></button>
          </div>
        </header>
        {children}
      </div>
      <footer className="flex shrink-0 flex-wrap items-center justify-between gap-3 border-t border-line bg-white px-5 py-4">
        <div className="flex items-center gap-2">{footerStart}</div>
        <div className="flex items-center gap-3">
          <button onClick={onClose} className="btn btn-secondary">Abbrechen</button>
          <button onClick={onClose} className="btn btn-primary"><Icon name="save" size={17} />{submitLabel}</button>
        </div>
      </footer>
    </div>
  );
}

Object.assign(window, {
  NavCtx, NavProvider, useNav, LiveSidebar, LiveTopBar, LiveShell,
  LiveListBoardChrome, LiveFilterChips, LiveTabBar, LiveModalShell, LivePageFormShell
});
