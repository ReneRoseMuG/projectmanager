// More live pages.

// ───── Features ─────
function LiveFeaturesPage() {
  const { navigate, openModal } = useNav();
  const [viewMode, setViewMode] = React.useState("board");
  const [search, setSearch] = React.useState("");
  const [statusFilter, setStatusFilter] = React.useState("all");
  const features = MOCK.features.filter((f) => (statusFilter === "all" || f.status === statusFilter) && (!search.trim() || f.title.toLowerCase().includes(search.toLowerCase())));
  const statusOpts = [
    { value: "draft", label: "Entwurf", count: MOCK.features.filter((f) => f.status === "draft").length },
    { value: "active", label: "Aktiv", count: MOCK.features.filter((f) => f.status === "active").length },
    { value: "done", label: "Erledigt", count: MOCK.features.filter((f) => f.status === "done").length },
    { value: "archived", label: "Archiviert", count: MOCK.features.filter((f) => f.status === "archived").length }
  ];
  const cols = [
    { value: "draft", label: "Entwurf" }, { value: "active", label: "Aktiv" },
    { value: "done", label: "Erledigt" }, { value: "archived", label: "Archiviert" }
  ];

  const Card = ({ f }) => (
    <article className="card overflow-hidden cursor-pointer hover:shadow-panel transition" onClick={() => navigate(`/features/${f.id}`)}>
      <div style={{ background: "var(--color-steel-600)", height: 4 }}></div>
      <div className="p-4 grid gap-3">
        <div className="flex items-start gap-3">
          <span className="flex h-[52px] w-[52px] shrink-0 items-center justify-center rounded-2xl bg-steel-600 text-white" style={{ boxShadow: "var(--shadow-steel-icon)" }}>
            <Icon name="book-open" size={22} />
          </span>
          <div className="min-w-0">
            <h3 className="text-base font-semibold text-ink leading-tight">{f.title}</h3>
            <p className="block truncate font-mono text-xs text-slate-500">/features/{f.slug}</p>
            <span className="mt-2 inline-flex"><Pill tone={f.statusTone}>{f.statusLabel}</Pill></span>
          </div>
        </div>
        {f.desc ? <p className="text-sm text-slate-600 line-clamp-3">{f.desc}</p> : null}
        <div className="flex items-center justify-between gap-3 border-t border-line pt-3">
          <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-steel-700">
            <Icon name="file-text" size={14} />{f.useCaseCount} Use Cases
          </span>
          <span className="flex h-9 w-9 items-center justify-center rounded-full bg-steel-100 text-steel-700">
            <Icon name="arrow-right" size={16} />
          </span>
        </div>
      </div>
    </article>
  );

  return (
    <>
      <PageHeader title="Features" subtitle="Fachliche Features und Use Cases" />
      <LiveListBoardChrome viewMode={viewMode} setViewMode={setViewMode} search={search} setSearch={setSearch} addLabel="Neues Feature"
        onAdd={() => openModal({ kind: "feature-form", mode: "create", tab: "details" })}
        filters={<LiveFilterChips value={statusFilter} onChange={setStatusFilter} options={statusOpts} allCount={MOCK.features.length} />} />
      {viewMode === "list" ? (
        <div className="grid gap-3">
          {features.map((f) => (
            <article key={f.id} className="card flex items-stretch overflow-hidden hover:border-steel-600 cursor-pointer" onClick={() => navigate(`/features/${f.id}`)}>
              <div style={{ background: "var(--color-steel-600)", width: 4 }}></div>
              <div className="flex flex-1 items-center gap-4 p-4">
                <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-steel-600 text-white"><Icon name="book-open" size={20} /></span>
                <div className="flex-1 min-w-0">
                  <h3 className="text-sm font-semibold text-ink">{f.title}</h3>
                  <p className="text-xs text-slate-500 font-mono">/features/{f.slug}</p>
                </div>
                <Pill tone={f.statusTone}>{f.statusLabel}</Pill>
                <span className="text-xs text-slate-500 inline-flex items-center gap-1"><Icon name="file-text" size={13} />{f.useCaseCount}</span>
              </div>
            </article>
          ))}
        </div>
      ) : (
        <div className="grid grid-flow-col auto-cols-[minmax(17rem,1fr)] gap-4 overflow-x-auto pb-2">
          {cols.map((col) => {
            const items = features.filter((f) => f.status === col.value);
            return (
              <section key={col.value} className="grid min-h-[260px] content-start gap-3 rounded-lg border border-line p-3" style={{ background: "rgba(244,247,250,0.6)" }}>
                <header className="flex items-center justify-between gap-3">
                  <h2 className="truncate text-sm font-semibold text-ink">{col.label}</h2>
                  <div className="flex items-center gap-2">
                    <span className="rounded-full bg-white px-2 py-1 text-xs font-semibold text-slate-600 shadow-sm">{items.length}</span>
                    <button className="btn btn-ghost btn-icon" style={{ background: "#fff", border: "1px solid var(--color-line)" }} onClick={() => openModal({ kind: "feature-form", mode: "create", tab: "details" })}><Icon name="plus" size={18} /></button>
                  </div>
                </header>
                {items.map((f) => <Card key={f.id} f={f} />)}
              </section>
            );
          })}
        </div>
      )}
    </>
  );
}

// ───── Feature Detail ─────
function LiveFeatureDetailPage({ id }) {
  const { navigate, openModal } = useNav();
  const feature = MOCK.features.find((f) => f.id === id);
  if (!feature) return <div className="rounded-lg border border-line bg-white p-8 text-center text-sm text-slate-600">Feature nicht gefunden</div>;
  const useCases = MOCK.useCases[id] || [];
  const projects = (MOCK.featureProjects[id] || []).map((pid) => MOCK.projects.find((p) => p.id === pid)).filter(Boolean);
  const tickets = MOCK.tickets.filter((t) => projects.find((p) => p.id === t.projectId)).slice(0, 3);

  return (
    <>
      <header className="relative overflow-hidden rounded-2xl p-6 text-white" style={{ background: "linear-gradient(135deg, var(--color-steel-700), var(--color-steel-600), var(--color-violet))", boxShadow: "var(--shadow-steel)" }}>
        <div className="pointer-events-none absolute -right-20 -top-48 h-[480px] w-[480px] rounded-full bg-white/10 blur-sm"></div>
        <div className="relative grid gap-5">
          <div className="flex flex-wrap items-start justify-between gap-5">
            <div className="min-w-0">
              <nav className="flex flex-wrap items-center gap-2 text-sm text-white/70">
                <button onClick={() => navigate("/features")} className="hover:text-white">Features</button>
                <Icon name="chevron-right" size={16} />
                <span className="text-white">{feature.title}</span>
              </nav>
              <h1 className="mt-3 text-[30px] font-bold leading-tight">{feature.title}</h1>
              <p className="mt-1 font-mono text-xs text-white/75">/features/{feature.slug}</p>
              {feature.desc ? <p className="mt-3 max-w-3xl text-sm leading-6 text-white/85">{feature.desc}</p> : null}
            </div>
            <button className="btn btn-ghost text-white" style={{ background: "rgba(255,255,255,0.1)", border: "1px solid rgba(255,255,255,0.2)" }} onClick={() => openModal({ kind: "feature-form", mode: "edit", entity: feature, tab: "details" })}>
              <Icon name="edit-3" size={17} />Bearbeiten
            </button>
          </div>
          <div className="grid gap-4 border-t border-white/15 pt-4 sm:grid-cols-2 lg:grid-cols-4">
            <div><span className="kicker-light">Status</span><span className="mt-1 block text-lg"><Pill tone={feature.statusTone}>{feature.statusLabel}</Pill></span></div>
            <div><span className="kicker-light">Use Cases</span><span className="mt-1 block text-2xl font-bold">{feature.useCaseCount}</span></div>
            <div><span className="kicker-light">Sortierung</span><span className="mt-1 block text-2xl font-bold">#{feature.sortOrder}</span></div>
            <div><span className="kicker-light">Verknüpfte Projekte</span><span className="mt-1 block text-2xl font-bold">{projects.length}</span></div>
          </div>
        </div>
      </header>

      <div className="card overflow-hidden">
        <div className="grid gap-4 p-5 md:grid-cols-2">
          <section>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold uppercase tracking-wider text-slate-500">Use Cases</h3>
              <button className="btn btn-secondary btn-sm" onClick={() => openModal({ kind: "feature-form", mode: "edit", entity: feature, tab: "useCases" })}>
                <Icon name="list" size={14} />Verwalten
              </button>
            </div>
            <ul className="grid gap-2">
              {useCases.map((u) => (
                <li key={u.id} className="flex items-center gap-3 rounded-md border border-line bg-white p-3 text-sm">
                  <Icon name="file-text" size={16} style={{ color: "var(--color-steel-600)" }} />
                  <span className="flex-1 text-ink">{u.title}</span>
                  <Pill tone={u.statusTone}>{u.statusLabel}</Pill>
                </li>
              ))}
            </ul>
          </section>
          <section>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold uppercase tracking-wider text-slate-500">Verknüpfte Projekte</h3>
              <button className="btn btn-secondary btn-sm" onClick={() => openModal({ kind: "feature-form", mode: "edit", entity: feature, tab: "projects" })}>
                <Icon name="link" size={14} />Verknüpfen
              </button>
            </div>
            <div className="grid gap-2">
              {projects.map((p) => (
                <button key={p.id} className="flex items-center gap-3 rounded-md border border-line bg-white p-3 hover:border-steel-600 text-left" onClick={() => navigate(`/projects/${p.id}`)}>
                  <span className="flex h-9 w-9 items-center justify-center rounded-md text-white" style={{ background: p.color }}><Icon name="folder-open" size={16} /></span>
                  <span className="flex-1 text-sm font-semibold text-ink">{p.name}</span>
                  <span className="text-xs text-slate-500">{p.openCount} offen</span>
                </button>
              ))}
            </div>
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-500 mt-6 mb-3">Tickets</h3>
            <ul className="grid gap-2">
              {tickets.map((t) => (
                <li key={t.id} className="flex items-center gap-3 rounded-md border border-line bg-white p-3 hover:border-steel-600 cursor-pointer" onClick={() => openModal({ kind: "ticket-form", mode: "edit", entity: t })}>
                  <Icon name="bug" size={16} style={{ color: "var(--color-crimson)" }} />
                  <span className="text-sm text-ink flex-1">TICKET-{t.id} · {t.title}</span>
                  <Pill tone={t.statusTone}>{t.statusLabel}</Pill>
                </li>
              ))}
            </ul>
          </section>
        </div>
      </div>
    </>
  );
}

// ───── Wiki ─────
function LiveWikiPage({ pageId }) {
  const { navigate, openModal } = useNav();
  const flat = (nodes) => nodes.flatMap((n) => [n, ...(n.children ? flat(n.children) : [])]);
  const all = flat(MOCK.wikiTree);
  const selectedId = pageId || 12;
  const selected = all.find((n) => n.id === selectedId);

  const Tree = ({ nodes, depth = 0 }) => (
    <ul className={depth > 0 ? "ml-3 border-l border-line pl-3 grid gap-0.5" : "grid gap-0.5"}>
      {nodes.map((n) => {
        const isActive = n.id === selectedId;
        return (
          <li key={n.id}>
            <button onClick={() => navigate(`/wiki/${n.id}`)} className={`w-full flex items-center gap-2 rounded-md px-2 py-1.5 text-sm text-left ${isActive ? "bg-steel-100 font-semibold text-steel-700" : "text-slate-600 hover:bg-shell"}`}>
              <Icon name={n.children?.length ? "chevron-down" : "file-text"} size={14} />
              <span className="flex-1 truncate">{n.title}</span>
            </button>
            {n.children && n.children.length > 0 ? <Tree nodes={n.children} depth={depth + 1} /> : null}
          </li>
        );
      })}
    </ul>
  );

  return (
    <>
      <PageHeader title="Wiki" subtitle="Projektwissen und Dokumentation" action={<button className="btn btn-primary" onClick={() => openModal({ kind: "wiki-form", mode: "create" })}><Icon name="plus" size={17} />Neue Seite</button>} />
      <div className="grid gap-6 xl:grid-cols-[24rem_minmax(0,1fr)]">
        <aside className="card p-4">
          <label className="relative block mb-3">
            <Icon name="search" size={14} style={{ position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)", color: "var(--color-slate-400)" }} />
            <input className="h-9 w-full rounded-md border border-line bg-white pl-8 pr-3 text-sm outline-none focus:border-steel-600" placeholder="Wiki durchsuchen" />
          </label>
          <Tree nodes={MOCK.wikiTree} />
        </aside>
        <div className="grid content-start gap-4">
          <nav className="flex items-center gap-2 text-xs text-slate-500">
            <span>Wiki</span><Icon name="chevron-right" size={14} /><span className="text-ink font-semibold">{selected ? selected.title : "—"}</span>
          </nav>
          {selected ? (
            <article className="card p-6">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h1 className="text-2xl font-bold text-ink">{selected.title}</h1>
                  <p className="mt-1 font-mono text-xs text-slate-500">/wiki/{selected.slug}</p>
                </div>
                <div className="flex gap-2">
                  <button className="btn btn-secondary"><Icon name="history" size={17} />Versionen</button>
                  <button className="btn btn-primary" onClick={() => openModal({ kind: "wiki-form", mode: "edit", entity: selected })}><Icon name="edit-3" size={17} />Bearbeiten</button>
                </div>
              </div>
              <div className="rte-body mt-5">
                <h2 style={{ fontSize: 20, fontWeight: 700, marginTop: 16, marginBottom: 8 }}>Komponenten</h2>
                <p>Die Anwendung besteht aus zwei Workspaces: <code style={{ background: "var(--color-steel-100)", padding: "1px 6px", borderRadius: 4 }}>apps/api</code> (Fastify + SQLite) und <code style={{ background: "var(--color-steel-100)", padding: "1px 6px", borderRadius: 4 }}>apps/web</code> (Vite + React).</p>
                <h2 style={{ fontSize: 20, fontWeight: 700, marginTop: 20, marginBottom: 8 }}>Datenmodell</h2>
                <p>Die zentralen Entitäten sind <b>Projekt</b>, <b>Feature</b>, <b>Use Case</b>, <b>Ticket</b>, <b>Aufgabe</b> und <b>Wiki-Seite</b>. Relationen werden über typed-Junctions abgebildet.</p>
                <ul style={{ listStyle: "disc", paddingLeft: 22, margin: "8px 0" }}>
                  <li>Projekte haben N Features</li>
                  <li>Features haben N Use Cases</li>
                  <li>Tickets können einem Projekt <i>oder</i> Feature gehören</li>
                </ul>
                <h2 style={{ fontSize: 20, fontWeight: 700, marginTop: 20, marginBottom: 8 }}>Backups</h2>
                <p>Die Sicherung erfolgt über Google Drive. Details siehe <button onClick={() => navigate("/settings/backup")} style={{ color: "var(--color-teal)", textDecoration: "underline", background: "none", border: 0, padding: 0, cursor: "pointer" }}>Betrieb → Backup</button>.</p>
              </div>
              <footer className="mt-6 flex items-center justify-between border-t border-line pt-4 text-xs text-slate-500">
                <span>Zuletzt geändert von <b>RM</b> · 11. Mai 2026</span>
                <span>Version 4</span>
              </footer>
            </article>
          ) : (
            <article className="card p-12 text-center text-sm text-slate-500">
              <Icon name="file-text" size={32} style={{ display: "inline-block" }} />
              <p className="mt-2">Wähle eine Wiki-Seite aus der Navigation links.</p>
            </article>
          )}
        </div>
      </div>
    </>
  );
}

Object.assign(window, { LiveFeaturesPage, LiveFeatureDetailPage, LiveWikiPage });
