// Page screens — mirror the routes under apps/web/src/pages/

// ───── Project cards / rows used in lists ─────
function ProjectCardSample({ name, status, statusTone, color, code, desc, tags, done, total, openCount }) {
  const progress = total > 0 ? Math.round((done / total) * 100) : 0;
  return (
    <article className="card overflow-hidden">
      <div style={{ background: color, height: 4 }}></div>
      <div className="p-4 grid gap-3">
        <div className="flex items-start gap-3">
          <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl text-white shadow-sm" style={{ background: color }}>
            <Icon name="folder-open" size={20} />
          </span>
          <div className="min-w-0">
            <h2 className="text-base font-semibold text-ink leading-tight">{name}</h2>
            <p className="mt-1 font-mono text-xs uppercase text-slate-500">{code}</p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Pill tone={statusTone}>{status}</Pill>
          {tags?.map((t) => <Badge key={t.name} color={t.color}>{t.name}</Badge>)}
        </div>
        {desc ? <p className="text-sm text-slate-600 line-clamp-3">{desc}</p> : null}
        <div className="grid gap-2 border-t border-line pt-3">
          {total > 0 ? <Progress value={progress} color={color} label={`${done} / ${total} erledigt`} /> : null}
          <span className="justify-self-end text-xs font-semibold text-slate-500">{openCount} offen</span>
        </div>
      </div>
    </article>
  );
}

function ProjectRowSample({ name, status, statusTone, color, desc, openCount, tag }) {
  return (
    <article className="card flex items-stretch overflow-hidden">
      <div style={{ background: color, width: 4 }}></div>
      <div className="flex flex-1 items-center gap-4 p-4">
        <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl text-white" style={{ background: color }}>
          <Icon name="folder-open" size={20} />
        </span>
        <div className="min-w-0 flex-1">
          <h3 className="text-sm font-semibold text-ink">{name}</h3>
          {desc ? <p className="text-xs text-slate-600 truncate">{desc}</p> : null}
        </div>
        <div className="flex items-center gap-2">
          <Pill tone={statusTone}>{status}</Pill>
          {tag ? <Badge color={tag.color}>{tag.name}</Badge> : null}
        </div>
        <span className="text-xs font-semibold text-slate-500 w-20 text-right">{openCount} offen</span>
        <div className="flex gap-1">
          <button className="btn btn-ghost btn-icon"><Icon name="edit-3" size={18} /></button>
          <button className="btn btn-ghost btn-icon"><Icon name="trash-2" size={18} /></button>
        </div>
      </div>
    </article>
  );
}

// ───── Page 1: Projekte (Board) ─────
window.ProjectsBoardScreen = function () {
  useLucide();
  const projects = [
    { name: "Apollo CRM", code: "AC", status: "Aktiv", tone: "fern", color: "#2E5984", desc: "Konsolidierung der Kundendaten und Migration des Vertriebs-Funnels in das neue CRM.", tags: [{ name: "Roadmap", color: "#4D9359" }], done: 18, total: 32, openCount: 7 },
    { name: "Helios Reporting", code: "HR", status: "Aktiv", tone: "fern", color: "#2F8E96", desc: "Monatliche Vertriebsberichte automatisieren – Excel-Export ablösen.", tags: [{ name: "Daten", color: "#2F8E96" }], done: 9, total: 14, openCount: 3 },
    { name: "Orion Onboarding", code: "OO", status: "Pausiert", tone: "tangerine", color: "#ED8C3A", desc: "Neuer Self-Service-Flow für Onboarding bei Bestandskunden.", tags: [{ name: "UX", color: "#6A40BE" }], done: 4, total: 22, openCount: 8 },
    { name: "Lumen Mobile", code: "LM", status: "Pausiert", tone: "tangerine", color: "#D9416A", desc: "Mobile-App MVP wartet auf Freigabe vom Steering Committee.", done: 6, total: 18, openCount: 6 },
    { name: "Atlas Migration", code: "AM", status: "Abgeschlossen", tone: "violet", color: "#6A40BE", desc: "Migration von Legacy-System in die neue Plattform abgeschlossen.", tags: [{ name: "Infra", color: "#1B355C" }], done: 24, total: 24, openCount: 0 },
    { name: "Vega Archiv", code: "VA", status: "Archiviert", tone: "steel", color: "#6B92BD", desc: "Alte Wikis und Dokumente konsolidiert für Auditzwecke.", done: 12, total: 12, openCount: 0 }
  ];
  const columns = [
    { value: "active", label: "Aktiv" },
    { value: "on_hold", label: "Pausiert" },
    { value: "completed", label: "Abgeschlossen" },
    { value: "archived", label: "Archiviert" }
  ];
  const groups = {
    active: projects.filter((p) => p.status === "Aktiv"),
    on_hold: projects.filter((p) => p.status === "Pausiert"),
    completed: projects.filter((p) => p.status === "Abgeschlossen"),
    archived: projects.filter((p) => p.status === "Archiviert")
  };
  return (
    <AppShell active="/projects">
      <PageHeader title="Projekte" subtitle="6 Einträge" />
      <ListBoardChrome viewMode="board" filters={
        <FilterChips value="all" allCount={6} options={[
          { value: "active", label: "Aktiv", count: 2 },
          { value: "on_hold", label: "Pausiert", count: 2 },
          { value: "completed", label: "Abgeschlossen", count: 1 },
          { value: "archived", label: "Archiviert", count: 1 }
        ]} />
      } />
      <div className="grid grid-flow-col auto-cols-[minmax(17rem,1fr)] gap-4 overflow-x-auto pb-2">
        {columns.map((col) => (
          <section key={col.value} className="grid min-h-[260px] content-start gap-3 rounded-lg border border-line p-3" style={{ background: "rgba(244,247,250,0.6)" }}>
            <header className="flex items-center justify-between gap-3">
              <h2 className="truncate text-sm font-semibold text-ink">{col.label}</h2>
              <div className="flex items-center gap-2">
                <span className="rounded-full bg-white px-2 py-1 text-xs font-semibold text-slate-600 shadow-sm">{groups[col.value].length}</span>
                <button className="btn btn-ghost btn-icon" style={{ background: "#fff", border: "1px solid var(--color-line)" }}><Icon name="plus" size={18} /></button>
              </div>
            </header>
            {groups[col.value].map((p) => <ProjectCardSample key={p.name} {...p} statusTone={p.tone} />)}
          </section>
        ))}
      </div>
    </AppShell>
  );
};

// ───── Page 2: Projekte (Liste) ─────
window.ProjectsListScreen = function () {
  useLucide();
  const rows = [
    { name: "Apollo CRM", status: "Aktiv", tone: "fern", color: "#2E5984", desc: "Konsolidierung der Kundendaten und Migration des Vertriebs-Funnels.", openCount: 7, tag: { name: "Roadmap", color: "#4D9359" } },
    { name: "Helios Reporting", status: "Aktiv", tone: "fern", color: "#2F8E96", desc: "Monatliche Vertriebsberichte automatisieren.", openCount: 3, tag: { name: "Daten", color: "#2F8E96" } },
    { name: "Orion Onboarding", status: "Pausiert", tone: "tangerine", color: "#ED8C3A", desc: "Self-Service-Flow für Bestandskunden.", openCount: 8 },
    { name: "Lumen Mobile", status: "Pausiert", tone: "tangerine", color: "#D9416A", desc: "Mobile-App MVP wartet auf Freigabe.", openCount: 6 },
    { name: "Atlas Migration", status: "Abgeschlossen", tone: "violet", color: "#6A40BE", desc: "Migration von Legacy-System abgeschlossen.", openCount: 0 },
    { name: "Vega Archiv", status: "Archiviert", tone: "steel", color: "#6B92BD", desc: "Alte Wikis konsolidiert.", openCount: 0 }
  ];
  return (
    <AppShell active="/projects">
      <PageHeader title="Projekte" subtitle="6 Einträge" />
      <ListBoardChrome viewMode="list" filters={
        <FilterChips value="all" allCount={6} options={[
          { value: "active", label: "Aktiv", count: 2 },
          { value: "on_hold", label: "Pausiert", count: 2 },
          { value: "completed", label: "Abgeschlossen", count: 1 },
          { value: "archived", label: "Archiviert", count: 1 }
        ]} />
      } />
      <div className="grid gap-3">{rows.map((r) => <ProjectRowSample key={r.name} {...r} statusTone={r.tone} />)}</div>
    </AppShell>
  );
};

// ───── Page 3: Projekt Detail ─────
window.ProjectDetailScreen = function () {
  useLucide();
  return (
    <AppShell active="/projects">
      <HeroHeader
        breadcrumb={["Projekte", "Apollo CRM"]}
        title="Apollo CRM"
        description="Konsolidierung der Kundendaten und Migration des Vertriebs-Funnels in das neue CRM. Steering Committee jeden 2. Mittwoch."
        stats={[
          { label: "Fortschritt", value: "56 %" },
          { label: "Aufgaben", value: "18 / 32" },
          { label: "Offen", value: "7" },
          { label: "Backlog", value: "14" },
          { label: "Aktualisiert", value: "12. Mai 2026" }
        ]}
      />
      <div className="grid gap-6 lg:grid-cols-3">
        <section className="card p-5 lg:col-span-2 grid gap-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-500">Aktive Aufgaben</h2>
            <span className="text-xs text-slate-500">7 offen</span>
          </div>
          {[
            { title: "Datenmapping CRM → SAP klären", status: "In Arbeit", tone: "tangerine", priority: "Hoch", priorityTone: "tangerine", assignee: "MR", due: "14. Mai" },
            { title: "Importjob für Kontaktduplikate", status: "Offen", tone: "crimson", priority: "Dringend", priorityTone: "crimson", assignee: "JS", due: "Heute" },
            { title: "Stakeholder-Interviews Phase 2", status: "In Arbeit", tone: "tangerine", priority: "Mittel", priorityTone: "mustard", assignee: "AK", due: "22. Mai" },
            { title: "Migrationstool Smoke-Test", status: "Offen", tone: "crimson", priority: "Hoch", priorityTone: "tangerine", assignee: "JL", due: "—" }
          ].map((t, i) => (
            <div key={i} className="flex items-center gap-3 rounded-md border border-line bg-white p-3">
              <span className="h-3 w-3 rounded-full" style={{ background: t.tone === "tangerine" ? "var(--color-tangerine)" : "var(--color-crimson)" }}></span>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-ink truncate">{t.title}</p>
              </div>
              <Badge tone={t.priorityTone}>{t.priority}</Badge>
              <Pill tone={t.tone}>{t.status}</Pill>
              <span className="text-xs text-slate-500 w-16 text-right">{t.due}</span>
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-steel-100 text-steel-700 text-xs font-bold">{t.assignee}</span>
            </div>
          ))}
        </section>
        <aside className="grid gap-6">
          <section className="card p-5">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-500 mb-3">Verknüpfte Features</h3>
            <div className="grid gap-2">
              {["Datenimport", "Kunden-360", "Reporting Dashboard"].map((f) => (
                <a key={f} className="flex items-center gap-3 rounded-md border border-line bg-white p-3 hover:border-steel-600">
                  <span className="flex h-9 w-9 items-center justify-center rounded-md bg-steel-600 text-white"><Icon name="book-open" size={16} /></span>
                  <span className="text-sm font-semibold text-ink flex-1">{f}</span>
                  <Icon name="chevron-right" size={16} style={{ color: "var(--color-slate-400)" }} />
                </a>
              ))}
            </div>
          </section>
          <section className="card p-5">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-500 mb-3">Letzte Aktivität</h3>
            <ul className="grid gap-3 text-sm">
              <li className="flex gap-3"><span className="mt-1 h-2 w-2 rounded-full bg-fern"></span><span><b>JS</b> hat Ticket <b>TICKET-204</b> gelöst <span className="text-slate-400">· vor 2h</span></span></li>
              <li className="flex gap-3"><span className="mt-1 h-2 w-2 rounded-full bg-tangerine"></span><span><b>MR</b> hat Aufgabe verschoben <span className="text-slate-400">· vor 5h</span></span></li>
              <li className="flex gap-3"><span className="mt-1 h-2 w-2 rounded-full bg-violet"></span><span><b>AK</b> hat Notiz hinzugefügt <span className="text-slate-400">· gestern</span></span></li>
            </ul>
          </section>
        </aside>
      </div>
    </AppShell>
  );
};

// ───── Page 4: Tickets (Kanban) ─────
window.TicketsKanbanScreen = function () {
  useLucide();
  const tickets = [
    { title: "Login schlägt nach Passwort-Reset fehl", status: "open", statusLabel: "Offen", statusTone: "steel", type: "Bug", typeTone: "crimson", priority: "Dringend", priorityTone: "crimson", priorityColor: "#D9416A", due: "Heute", assignee: "JS" },
    { title: "Export-Button im Reporting greift nicht", status: "open", statusLabel: "Offen", statusTone: "steel", type: "Bug", typeTone: "crimson", priority: "Hoch", priorityTone: "tangerine", priorityColor: "#ED8C3A", due: "14. Mai", assignee: "MR" },
    { title: "Doppelte E-Mail-Validierung", status: "in_progress", statusLabel: "In Arbeit", statusTone: "tangerine", type: "Verbesserung", typeTone: "teal", priority: "Mittel", priorityTone: "mustard", priorityColor: "#E2BA2C", due: "20. Mai", assignee: "AK" },
    { title: "Suche ignoriert Umlaute", status: "in_progress", statusLabel: "In Arbeit", statusTone: "tangerine", type: "Bug", typeTone: "crimson", priority: "Hoch", priorityTone: "tangerine", priorityColor: "#ED8C3A", due: "Morgen", assignee: "JL" },
    { title: "Tooltip-Farbe Accessibility", status: "in_review", statusLabel: "In Prüfung", statusTone: "mustard", type: "Verbesserung", typeTone: "teal", priority: "Niedrig", priorityTone: "steel", priorityColor: "#94B2D1", due: "—", assignee: "SK" },
    { title: "Speicherprobleme bei großem Import", status: "resolved", statusLabel: "Gelöst", statusTone: "fern", type: "Bug", typeTone: "crimson", priority: "Dringend", priorityTone: "crimson", priorityColor: "#D9416A", due: "08. Mai", assignee: "MR" },
    { title: "Onboarding-Hinweise Wording", status: "closed", statusLabel: "Geschlossen", statusTone: "violet", type: "Frage", typeTone: "violet", priority: "Niedrig", priorityTone: "steel", priorityColor: "#94B2D1", due: "—", assignee: "AK" }
  ];
  const cols = [
    { value: "open", label: "Offen" },
    { value: "in_progress", label: "In Arbeit" },
    { value: "in_review", label: "In Prüfung" },
    { value: "resolved", label: "Gelöst" },
    { value: "closed", label: "Geschlossen" }
  ];
  return (
    <AppShell active="/tickets">
      <PageHeader title="Tickets" subtitle="7 Einträge" />
      <ListBoardChrome viewMode="board" />
      <div className="grid grid-flow-col auto-cols-[minmax(17rem,1fr)] gap-4 overflow-x-auto pb-2">
        {cols.map((col) => {
          const items = tickets.filter((t) => t.status === col.value);
          return (
            <section key={col.value} className="grid min-h-[260px] content-start gap-3 rounded-lg border border-line p-3" style={{ background: "rgba(244,247,250,0.6)" }}>
              <header className="flex items-center justify-between gap-3">
                <h2 className="truncate text-sm font-semibold text-ink">{col.label}</h2>
                <div className="flex items-center gap-2">
                  <span className="rounded-full bg-white px-2 py-1 text-xs font-semibold text-slate-600 shadow-sm">{items.length}</span>
                  <button className="btn btn-ghost btn-icon" style={{ background: "#fff", border: "1px solid var(--color-line)" }}><Icon name="plus" size={18} /></button>
                </div>
              </header>
              {items.map((t, i) => (
                <article key={i} className="card overflow-hidden">
                  <div style={{ background: t.priorityColor, height: 4 }}></div>
                  <div className="p-4 grid gap-2">
                    <h3 className="text-sm font-semibold text-ink line-clamp-2">{t.title}</h3>
                    <div className="flex flex-wrap items-center gap-2">
                      <Pill tone={t.statusTone}>{t.statusLabel}</Pill>
                      <Badge tone={t.typeTone}>{t.type}</Badge>
                    </div>
                    <div className="flex items-center justify-between gap-3 border-t border-line pt-2 text-xs text-slate-600">
                      <span className="inline-flex items-center gap-1"><Icon name="calendar-clock" size={14} />{t.due}</span>
                      <span className="flex h-7 w-7 items-center justify-center rounded-full bg-steel-100 text-steel-700 text-[11px] font-bold">{t.assignee}</span>
                    </div>
                  </div>
                </article>
              ))}
            </section>
          );
        })}
      </div>
    </AppShell>
  );
};

Object.assign(window, { ProjectCardSample, ProjectRowSample });
