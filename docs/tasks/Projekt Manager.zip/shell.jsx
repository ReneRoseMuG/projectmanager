// Shared atoms & shell — used across all artboards.

// Tiny lucide-icon wrapper. Renders <i data-lucide=...> which lucide.createIcons()
// upgrades to inline SVG after each React render.
function Icon({ name, size = 16, className = "", style = {} }) {
  return <i data-lucide={name} style={{ width: size, height: size, display: "inline-flex", ...style }} className={className}></i>;
}

// Re-run lucide after every render so newly mounted icons get SVGs.
function useLucide() {
  React.useEffect(() => {
    if (window.lucide) window.lucide.createIcons();
  });
}

function Pill({ tone = "steel", children }) {
  return <span className={`pill pill-${tone}`}>{children}</span>;
}

function Badge({ tone = "mute", children, color }) {
  if (color) {
    return <span className="badge" style={{ borderColor: color + "33", background: color + "14", color }}>{children}</span>;
  }
  return <span className={`badge badge-${tone}`}>{children}</span>;
}

function Btn({ variant = "secondary", icon, children, className = "", iconOnly = false }) {
  const base = variant === "primary" ? "btn btn-primary" : variant === "danger" ? "btn btn-danger" : variant === "ghost" ? "btn btn-ghost" : "btn btn-secondary";
  return (
    <button className={`${base} ${iconOnly ? "btn-icon" : ""} ${className}`}>
      {icon ? <Icon name={icon} size={17} /> : null}
      {children}
    </button>
  );
}

function Progress({ value, color = "var(--color-steel-700)", label }) {
  return (
    <div className="grid gap-1">
      <div className="progress"><div className="progress-bar" style={{ width: `${value}%`, background: color }}></div></div>
      {label ? <span className="text-xs text-slate-500">{label}</span> : null}
    </div>
  );
}

// Sidebar (mirrors components/layout/Sidebar.tsx)
function Sidebar({ active }) {
  const items = [
    { to: "/projects", label: "Projekte", icon: "folder-kanban" },
    { to: "/tickets", label: "Tickets", icon: "bug" },
    { to: "/features", label: "Features", icon: "book-open" },
    { to: "/wiki", label: "Wiki", icon: "library" },
    { to: "/calendar", label: "Kalender", icon: "calendar-days" }
  ];
  const settings = [
    { to: "/settings/tags", label: "Tags", icon: "tags" },
    { to: "/settings/backup", label: "Sicherung", icon: "database-backup" },
    { to: "/settings/test-data", label: "Testdaten", icon: "database-zap" }
  ];
  const Item = ({ item }) => {
    const isActive = active === item.to;
    return (
      <a className={`flex h-10 items-center gap-3 rounded-lg px-3 text-sm font-medium transition ${isActive ? "bg-white font-semibold text-steel-700 shadow-md" : "text-white/75 hover:bg-white/5"}`}>
        <Icon name={item.icon} size={17} />
        {item.label}
      </a>
    );
  };
  return (
    <aside className="w-64 shrink-0 p-4 text-white" style={{ background: "linear-gradient(180deg, var(--color-steel-700), var(--color-steel-800))" }}>
      <div className="mb-8 flex items-center gap-3">
        <span className="flex h-10 w-10 items-center justify-center rounded-md text-steel-700 shadow-lg font-bold" style={{ background: "linear-gradient(135deg, var(--color-steel-300), #fff)" }}>TM</span>
        <div>
          <strong className="block text-sm font-bold">Taskmanager</strong>
          <span className="text-[11px] uppercase tracking-widest text-steel-300">Lokal</span>
        </div>
      </div>
      <div className="mb-2 mt-5 px-1.5 text-[10px] font-semibold uppercase tracking-widest text-steel-400">Navigation</div>
      <nav className="grid gap-1">{items.map((i) => <Item key={i.to} item={i} />)}</nav>
      <div className="mb-2 mt-5 px-1.5 text-[10px] font-semibold uppercase tracking-widest text-steel-400">Einstellungen</div>
      <nav className="grid gap-1">{settings.map((i) => <Item key={i.to} item={i} />)}</nav>
    </aside>
  );
}

// TopBar (mirrors components/layout/TopBar.tsx)
function TopBar({ searchValue = "" }) {
  return (
    <header className="relative flex h-16 items-center justify-between border-b border-line bg-white px-6 shrink-0">
      <div className="min-w-0 flex-1 max-w-2xl">
        <label className="relative block">
          <Icon name="search" size={16} style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", color: "var(--color-slate-400)" }} />
          <input className="h-10 w-full rounded-md border border-line bg-white pl-9 pr-20 text-sm outline-none focus:border-steel-600" placeholder="Global suchen" defaultValue={searchValue} />
          <span className="absolute right-2 top-1/2 -translate-y-1/2 rounded border border-line bg-shell px-1.5 py-0.5 text-[10px] font-semibold text-slate-500">Ctrl K</span>
        </label>
      </div>
      <div className="flex items-center gap-3">
        <button className="inline-flex h-8 items-center gap-2 rounded-full bg-fern px-3 text-xs font-semibold uppercase tracking-wide text-white">
          <span className="h-2 w-2 rounded-full bg-white/80"></span>
          API online
        </button>
      </div>
    </header>
  );
}

// AppShell wrapper: sidebar + topbar + main, fixed within an artboard
function AppShell({ active = "/projects", children, scrollable = false }) {
  return (
    <div className="flex h-full w-full bg-shell text-ink" style={{ minHeight: 0 }}>
      <Sidebar active={active} />
      <div className="flex min-w-0 flex-1 flex-col">
        <TopBar />
        <main className={`min-w-0 flex-1 p-6 ${scrollable ? "overflow-auto" : ""}`}>
          <div className="mx-auto max-w-7xl grid gap-6">{children}</div>
        </main>
      </div>
    </div>
  );
}

// Section header + box
function Section({ title, children, action }) {
  return (
    <section className="grid gap-3">
      {title || action ? (
        <div className="flex items-center justify-between">
          {title ? <h3 className="text-sm font-bold uppercase text-slate-500 tracking-wider">{title}</h3> : <span />}
          {action}
        </div>
      ) : null}
      {children}
    </section>
  );
}

// Page header (h1 + subtitle + actions)
function PageHeader({ title, subtitle, action }) {
  return (
    <header className="flex flex-wrap items-center justify-between gap-3">
      <div>
        <h1 className="text-2xl font-semibold text-ink">{title}</h1>
        {subtitle ? <p className="text-sm text-slate-600">{subtitle}</p> : null}
      </div>
      {action}
    </header>
  );
}

// Hero header with steel→violet gradient (detail pages)
function HeroHeader({ breadcrumb, title, description, stats, kind = "violet" }) {
  const bg = kind === "violet"
    ? "linear-gradient(135deg, var(--color-steel-700), var(--color-steel-600), var(--color-violet))"
    : kind === "teal"
    ? "linear-gradient(135deg, var(--color-teal), rgba(47,142,150,0.75))"
    : "linear-gradient(135deg, var(--color-magenta), rgba(193,61,154,0.75))";
  return (
    <header className="relative overflow-hidden rounded-2xl p-6 text-white" style={{ background: bg, boxShadow: "var(--shadow-steel)" }}>
      <div className="pointer-events-none absolute -right-20 -top-48 h-[480px] w-[480px] rounded-full bg-white/10 blur-sm"></div>
      <div className="relative grid gap-5">
        <div className="flex flex-wrap items-start justify-between gap-5">
          <div className="min-w-0">
            <nav className="flex flex-wrap items-center gap-2 text-sm text-white/70">
              {breadcrumb.map((b, i) => (
                <React.Fragment key={i}>
                  {i > 0 ? <Icon name="chevron-right" size={16} /> : null}
                  <span className={i === breadcrumb.length - 1 ? "text-white" : ""}>{b}</span>
                </React.Fragment>
              ))}
            </nav>
            <h1 className="mt-3 text-[30px] font-bold leading-tight tracking-normal">{title}</h1>
            {description ? <p className="mt-1 max-w-[720px] text-[15px] leading-6 text-white/85">{description}</p> : null}
          </div>
          <button className="btn btn-ghost text-white" style={{ background: "rgba(255,255,255,0.1)", border: "1px solid rgba(255,255,255,0.2)" }}>
            <Icon name="edit-3" size={17} />Bearbeiten
          </button>
        </div>
        {stats ? (
          <div className="grid gap-4 border-t border-white/20 pt-5 sm:grid-cols-2 lg:grid-cols-5">
            {stats.map((s, i) => (
              <div key={i}>
                <span className="kicker-light">{s.label}</span>
                <span className="mt-1 block text-2xl font-bold">{s.value}</span>
              </div>
            ))}
          </div>
        ) : null}
      </div>
    </header>
  );
}

// Tab bar (mirrors components/ui/TabBar.tsx)
function TabBar({ tabs, active }) {
  return (
    <nav className="relative z-10 flex min-h-12 shrink-0 gap-1 overflow-x-auto border-b border-line bg-white px-5">
      {tabs.map((tab) => {
        const selected = active === tab.value;
        return (
          <button key={tab.value} className={`flex h-12 shrink-0 items-center gap-2 border-b-2 px-3 text-sm font-semibold transition ${selected ? "border-steel-700 text-steel-700" : "border-transparent text-slate-500 hover:text-ink"}`}>
            {tab.label}
            {typeof tab.count === "number" ? <span className={`rounded-full px-2 py-0.5 text-xs ${selected ? "bg-steel-700 text-white" : "bg-shell text-slate-500"}`}>{tab.count}</span> : null}
          </button>
        );
      })}
    </nav>
  );
}

// FormModal shell (mirrors components/ui/FormModal.tsx)
function FormModal({ breadcrumb, title, subtitle, icon, footerStart, submitLabel = "Speichern", children, headerKind = "steel" }) {
  const headerBg = headerKind === "teal"
    ? "linear-gradient(135deg, var(--color-teal), rgba(47,142,150,0.75))"
    : "linear-gradient(135deg, var(--color-steel-700), var(--color-steel-600))";
  return (
    <div className="absolute inset-0 flex items-center justify-center" style={{ background: "rgba(15,37,66,0.55)" }}>
      <div className="flex max-h-[92%] w-[920px] flex-col overflow-hidden rounded-2xl bg-shell" style={{ boxShadow: "var(--shadow-modal)" }}>
        <header className="relative shrink-0 overflow-hidden px-6 py-5 text-white" style={{ background: headerBg }}>
          <div className="pointer-events-none absolute -right-8 -top-32 h-80 w-80 rounded-full bg-white/12 blur-sm"></div>
          <div className="relative flex items-start justify-between gap-4">
            <div className="grid gap-2">
              <div className="flex flex-wrap items-center gap-2 text-xs font-semibold uppercase text-white/75">
                {breadcrumb.map((b, i) => (
                  <span key={i} className="inline-flex items-center gap-2">
                    {i > 0 ? <span>›</span> : null}<span>{b}</span>
                  </span>
                ))}
              </div>
              <div className="flex items-center gap-3">
                <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/12">
                  <Icon name={icon} size={21} />
                </span>
                <div>
                  <h2 className="text-2xl font-bold tracking-normal">{title}</h2>
                  {subtitle ? <p className="text-sm text-white/75">{subtitle}</p> : null}
                </div>
              </div>
            </div>
            <button className="flex h-9 w-9 items-center justify-center rounded-full text-white/80 hover:bg-white/12">
              <Icon name="x" size={18} />
            </button>
          </div>
        </header>
        {children}
        <footer className="flex shrink-0 flex-wrap items-center justify-between gap-3 border-t border-line bg-white px-5 py-4">
          <div className="flex items-center gap-2">{footerStart}</div>
          <div className="flex items-center gap-3">
            <Btn>Abbrechen</Btn>
            <Btn variant="primary" icon="save">{submitLabel}</Btn>
          </div>
        </footer>
      </div>
    </div>
  );
}

// Empty state
function EmptyState({ icon, title, body, tone = "fern", actions = [] }) {
  return (
    <div className="rounded-lg border border-dashed border-line bg-white p-8 text-center">
      <span className={`mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-2xl text-${tone}`} style={{ background: `var(--color-${tone === "fern" ? "fern" : tone})1a` }}>
        <Icon name={icon} size={22} />
      </span>
      <h3 className="text-base font-semibold text-ink">{title}</h3>
      {body ? <p className="mt-1 text-sm text-slate-600">{body}</p> : null}
      {actions.length ? (
        <div className="mt-4 flex justify-center gap-2">
          {actions.map((a, i) => <Btn key={i} variant={a.primary ? "primary" : "secondary"} icon={a.icon}>{a.label}</Btn>)}
        </div>
      ) : null}
    </div>
  );
}

// Form field helpers
function Field({ label, required, children, hint }) {
  return (
    <label className="grid gap-1.5">
      <span className="field-label">{label}{required ? <span className="ml-1 text-crimson">*</span> : null}</span>
      {children}
      {hint ? <span className="text-xs text-slate-500">{hint}</span> : null}
    </label>
  );
}

function SegmentedControl({ options, value }) {
  return (
    <div className="inline-flex items-center gap-1 rounded-md border border-line bg-white p-1">
      {options.map((o) => (
        <button key={o.value} className={`h-9 px-3 rounded-sm text-sm font-semibold transition ${o.value === value ? "bg-steel-700 text-white" : "text-slate-600 hover:text-ink"}`}>
          {o.label}
        </button>
      ))}
    </div>
  );
}

function RadioList({ options, value }) {
  const colorMap = { fern: "fern", tangerine: "tangerine", crimson: "crimson", violet: "violet" };
  return (
    <div className="grid gap-1.5">
      {options.map((o) => {
        const sel = o.value === value;
        const c = colorMap[o.activeColor] || "steel-700";
        return (
          <label key={o.value} className={`flex items-center gap-3 rounded-md border px-3 py-2.5 text-sm font-medium cursor-pointer ${sel ? "border-transparent text-white" : "border-line bg-white text-ink"}`} style={sel ? { background: `var(--color-${c})` } : {}}>
            <span className={`h-4 w-4 rounded-full border-2 ${sel ? "border-white" : "border-line"}`} style={sel ? { background: "rgba(255,255,255,0.2)" } : {}}>
              {sel ? <span className="block m-[3px] h-1.5 w-1.5 rounded-full bg-white"></span> : null}
            </span>
            {o.label}
          </label>
        );
      })}
    </div>
  );
}

function ColorSwatches({ swatches, selected }) {
  return (
    <div className="flex flex-wrap gap-2">
      {swatches.map((s) => (
        <button key={s} className={`h-9 w-9 rounded-full border-2 ${selected === s ? "border-steel-900" : "border-white"}`} style={{ background: s, boxShadow: "0 0 0 1px var(--color-line)" }}></button>
      ))}
    </div>
  );
}

// FilterChips
function FilterChips({ options, value, allCount }) {
  return (
    <div className="flex flex-wrap items-center gap-2">
      <button className={`h-9 px-3 rounded-full text-xs font-semibold border ${value === "all" ? "bg-steel-700 text-white border-steel-700" : "bg-white text-slate-600 border-line"}`}>
        Alle <span className="ml-1 opacity-70">{allCount}</span>
      </button>
      {options.map((o) => (
        <button key={o.value} className={`h-9 px-3 rounded-full text-xs font-semibold border ${o.value === value ? "bg-steel-700 text-white border-steel-700" : "bg-white text-slate-600 border-line"}`}>
          {o.label} <span className="ml-1 opacity-70">{o.count}</span>
        </button>
      ))}
    </div>
  );
}

// SearchInput + ViewToggle (board/list)
function ListBoardChrome({ search = "", filters, addLabel = "Neu", viewMode = "board" }) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-3">
      <label className="relative">
        <Icon name="search" size={16} style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", color: "var(--color-slate-400)" }} />
        <input className="h-10 w-64 rounded-md border border-line bg-white pl-9 pr-3 text-sm outline-none focus:border-steel-600" placeholder="Suchen" defaultValue={search} />
      </label>
      <div className="flex flex-wrap items-center gap-2">
        {filters}
        <div className="inline-flex h-10 items-center gap-1 rounded-md border border-line bg-white p-1">
          <button className={`h-8 px-2 rounded-sm ${viewMode === "list" ? "bg-steel-700 text-white" : "text-slate-500"}`}>
            <Icon name="list" size={16} />
          </button>
          <button className={`h-8 px-2 rounded-sm ${viewMode === "board" ? "bg-steel-700 text-white" : "text-slate-500"}`}>
            <Icon name="layout-grid" size={16} />
          </button>
        </div>
        <button className="btn btn-primary btn-icon" title={addLabel}><Icon name="plus" size={17} /></button>
      </div>
    </div>
  );
}

// Expose to window for cross-file scripts
Object.assign(window, {
  Icon, useLucide, Pill, Badge, Btn, Progress, Sidebar, TopBar, AppShell, Section,
  PageHeader, HeroHeader, TabBar, FormModal, EmptyState, Field, SegmentedControl,
  RadioList, ColorSwatches, FilterChips, ListBoardChrome
});
