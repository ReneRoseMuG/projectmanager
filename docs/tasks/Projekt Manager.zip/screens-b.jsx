// More page screens.

// ───── Page 5: Tickets (Liste) ─────
window.TicketsListScreen = function () {
  useLucide();
  const rows = [
    { id: 204, title: "Login schlägt nach Passwort-Reset fehl", status: "Offen", tone: "steel", type: "Bug", typeTone: "crimson", priority: "Dringend", priorityTone: "crimson", priorityColor: "#D9416A", due: "Heute", overdue: true, assignee: "JS", desc: "Reset-Mail erzeugt Token, aber Login akzeptiert es nicht." },
    { id: 211, title: "Export-Button im Reporting greift nicht", status: "Offen", tone: "steel", type: "Bug", typeTone: "crimson", priority: "Hoch", priorityTone: "tangerine", priorityColor: "#ED8C3A", due: "14. Mai", assignee: "MR", desc: "Klick auf CSV-Export löst nichts aus, Browser-Konsole zeigt 500." },
    { id: 214, title: "Doppelte E-Mail-Validierung", status: "In Arbeit", tone: "tangerine", type: "Verbesserung", typeTone: "teal", priority: "Mittel", priorityTone: "mustard", priorityColor: "#E2BA2C", due: "20. Mai", assignee: "AK", desc: "Validierung auch beim Import von externen Listen." },
    { id: 215, title: "Suche ignoriert Umlaute", status: "In Arbeit", tone: "tangerine", type: "Bug", typeTone: "crimson", priority: "Hoch", priorityTone: "tangerine", priorityColor: "#ED8C3A", due: "Morgen", assignee: "JL", desc: "„Müller“ und „Mueller“ liefern unterschiedliche Treffer." },
    { id: 218, title: "Tooltip-Farbe Accessibility", status: "In Prüfung", tone: "mustard", type: "Verbesserung", typeTone: "teal", priority: "Niedrig", priorityTone: "steel", priorityColor: "#94B2D1", due: "—", assignee: "SK", desc: "Kontrast auf hellem Hintergrund zu schwach." },
    { id: 220, title: "Speicherprobleme bei großem Import", status: "Gelöst", tone: "fern", type: "Bug", typeTone: "crimson", priority: "Dringend", priorityTone: "crimson", priorityColor: "#D9416A", due: "08. Mai", assignee: "MR", desc: "Streaming-Import statt In-Memory implementiert." }
  ];
  return (
    <AppShell active="/tickets">
      <PageHeader title="Tickets" subtitle="6 Einträge" />
      <ListBoardChrome viewMode="list" />
      <div className="grid gap-3">
        {rows.map((r) => (
          <article key={r.id} className="card flex items-stretch overflow-hidden">
            <div style={{ background: r.priorityColor, width: 4 }}></div>
            <div className="flex flex-1 items-center gap-4 p-4">
              <span className="block h-3 w-3 rounded-full" style={{ background: r.tone === "tangerine" ? "var(--color-tangerine)" : r.tone === "mustard" ? "var(--color-mustard)" : r.tone === "fern" ? "var(--color-fern)" : r.tone === "violet" ? "var(--color-violet)" : "var(--color-steel-400)" }}></span>
              <div className="min-w-0 flex-1">
                <h3 className="text-sm font-semibold text-ink">TICKET-{r.id} · {r.title}</h3>
                <p className="text-xs text-slate-600 truncate">{r.desc}</p>
              </div>
              <div className="flex items-center gap-2">
                <Pill tone={r.tone}>{r.status}</Pill>
                <Badge tone={r.typeTone}>{r.type}</Badge>
                <Badge tone={r.priorityTone}>{r.priority}</Badge>
              </div>
              <span className={`inline-flex w-24 items-center gap-1 text-xs font-semibold ${r.overdue ? "text-crimson" : "text-slate-500"}`}>
                <Icon name="calendar-clock" size={14} />{r.due}
              </span>
              <span className="flex h-9 w-9 items-center justify-center rounded-full bg-steel-100 text-steel-700 text-xs font-bold">{r.assignee}</span>
              <div className="flex gap-1">
                <button className="btn btn-ghost btn-icon"><Icon name="edit-3" size={18} /></button>
                <button className="btn btn-ghost btn-icon"><Icon name="trash-2" size={18} /></button>
              </div>
            </div>
          </article>
        ))}
      </div>
    </AppShell>
  );
};

// ───── Page 6: Features (Board) ─────
window.FeaturesScreen = function () {
  useLucide();
  const features = [
    { title: "Kunden-360", slug: "kunden-360", desc: "Konsolidierte Sicht auf alle Kundendaten, Aktivitäten und Tickets.", status: "draft", statusLabel: "Entwurf", statusTone: "mustard", useCases: 5 },
    { title: "Reporting Dashboard", slug: "reporting-dashboard", desc: "Live-Dashboard mit Vertriebs-KPIs, Filter nach Region und Zeitraum.", status: "active", statusLabel: "Aktiv", statusTone: "fern", useCases: 7 },
    { title: "Datenimport CSV/Excel", slug: "datenimport", desc: "Mappable Importpipeline mit Validierung und Konflikterkennung.", status: "active", statusLabel: "Aktiv", statusTone: "fern", useCases: 4 },
    { title: "Onboarding Self-Service", slug: "onboarding", desc: "Setup-Flow für neue Mandanten ohne manuelle Konfiguration.", status: "draft", statusLabel: "Entwurf", statusTone: "mustard", useCases: 3 },
    { title: "Single Sign-On", slug: "sso", desc: "SAML/OIDC für Enterprise-Kunden.", status: "done", statusLabel: "Erledigt", statusTone: "violet", useCases: 2 },
    { title: "Legacy Reports", slug: "legacy-reports", desc: "Excel-basierte Vorlagen abgelöst.", status: "archived", statusLabel: "Archiviert", statusTone: "steel", useCases: 0 }
  ];
  const cols = [
    { value: "draft", label: "Entwurf" },
    { value: "active", label: "Aktiv" },
    { value: "done", label: "Erledigt" },
    { value: "archived", label: "Archiviert" }
  ];
  return (
    <AppShell active="/features">
      <PageHeader title="Features" subtitle="Fachliche Features und Use Cases" />
      <ListBoardChrome viewMode="board" addLabel="Neues Feature" filters={
        <FilterChips value="all" allCount={6} options={[
          { value: "draft", label: "Entwurf", count: 2 },
          { value: "active", label: "Aktiv", count: 2 },
          { value: "done", label: "Erledigt", count: 1 },
          { value: "archived", label: "Archiviert", count: 1 }
        ]} />
      } />
      <div className="grid grid-flow-col auto-cols-[minmax(17rem,1fr)] gap-4 overflow-x-auto pb-2">
        {cols.map((col) => {
          const items = features.filter((f) => f.status === col.value);
          return (
            <section key={col.value} className="grid min-h-[260px] content-start gap-3 rounded-lg border border-line p-3" style={{ background: "rgba(244,247,250,0.6)" }}>
              <header className="flex items-center justify-between gap-3">
                <h2 className="truncate text-sm font-semibold text-ink">{col.label}</h2>
                <div className="flex items-center gap-2">
                  <span className="rounded-full bg-white px-2 py-1 text-xs font-semibold text-slate-600 shadow-sm">{items.length}</span>
                  <button className="btn btn-ghost btn-icon" style={{ background: "#fff", border: "1px solid var(--color-line)" }}><Icon name="plus" size={18} /></button>
                </div>
              </header>
              {items.map((f) => (
                <article key={f.slug} className="card overflow-hidden">
                  <div style={{ background: "var(--color-steel-600)", height: 4 }}></div>
                  <div className="p-4 grid gap-3">
                    <div className="flex items-start gap-3">
                      <span className="flex h-[52px] w-[52px] shrink-0 items-center justify-center rounded-2xl bg-steel-600 text-white" style={{ boxShadow: "var(--shadow-steel-icon)" }}>
                        <Icon name="book-open" size={22} />
                      </span>
                      <div className="min-w-0">
                        <h3 className="text-base font-semibold text-ink leading-tight">{f.title}</h3>
                        <p className="block truncate font-mono text-xs text-slate-500">/features/{f.slug}</p>
                        <span className="mt-2 inline-flex"><Pill tone={f.statusTone}>{f.statusLabel}</Pill></span>
                      </div>
                    </div>
                    {f.desc ? <p className="text-sm text-slate-600 line-clamp-3">{f.desc}</p> : null}
                    <div className="flex items-center justify-between gap-3 border-t border-line pt-3">
                      <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-steel-700">
                        <Icon name="file-text" size={14} />{f.useCases} Use Cases
                      </span>
                      <span className="flex h-9 w-9 items-center justify-center rounded-full bg-steel-100 text-steel-700">
                        <Icon name="arrow-right" size={16} />
                      </span>
                    </div>
                  </div>
                </article>
              ))}
            </section>
          );
        })}
      </div>
    </AppShell>
  );
};

// ───── Page 7: Feature Detail ─────
window.FeatureDetailScreen = function () {
  useLucide();
  return (
    <AppShell active="/features">
      <HeroHeader
        breadcrumb={["Features", "Reporting Dashboard"]}
        title="Reporting Dashboard"
        description="Live-Dashboard mit Vertriebs-KPIs, Filter nach Region und Zeitraum. Drill-down in Tickets und Backlog-Items."
        stats={[
          { label: "Status", value: <Pill tone="fern">Aktiv</Pill> },
          { label: "Use Cases", value: "7" },
          { label: "Sortierung", value: "#3" },
          { label: "Aktualisiert", value: "11. Mai 2026" }
        ]}
      />
      <div className="card overflow-hidden">
        <p className="px-5 pt-4 font-mono text-xs text-slate-500">/features/reporting-dashboard</p>
        <div className="grid gap-4 p-5 md:grid-cols-2">
          <section>
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-500 mb-3">Use Cases</h3>
            <ul className="grid gap-2">
              {[
                { t: "Vertriebsleiter sieht KPIs nach Region", s: "Aktiv", tone: "fern" },
                { t: "Mitarbeiter filtert nach Zeitraum", s: "Aktiv", tone: "fern" },
                { t: "Export als PDF für Steering", s: "Entwurf", tone: "mustard" },
                { t: "Vergleich mit Vorjahr", s: "Entwurf", tone: "mustard" },
                { t: "Live-Drill-down in Tickets", s: "Aktiv", tone: "fern" }
              ].map((u, i) => (
                <li key={i} className="flex items-center gap-3 rounded-md border border-line bg-white p-3 text-sm">
                  <Icon name="file-text" size={16} style={{ color: "var(--color-steel-600)" }} />
                  <span className="flex-1 text-ink">{u.t}</span>
                  <Pill tone={u.tone}>{u.s}</Pill>
                </li>
              ))}
            </ul>
          </section>
          <section>
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-500 mb-3">Verknüpfte Projekte</h3>
            <div className="grid gap-2">
              {[
                { name: "Apollo CRM", color: "#2E5984", open: 7 },
                { name: "Helios Reporting", color: "#2F8E96", open: 3 }
              ].map((p) => (
                <a key={p.name} className="flex items-center gap-3 rounded-md border border-line bg-white p-3">
                  <span className="flex h-9 w-9 items-center justify-center rounded-md text-white" style={{ background: p.color }}><Icon name="folder-open" size={16} /></span>
                  <span className="flex-1 text-sm font-semibold text-ink">{p.name}</span>
                  <span className="text-xs text-slate-500">{p.open} offen</span>
                </a>
              ))}
            </div>
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-500 mt-6 mb-3">Tickets</h3>
            <ul className="grid gap-2">
              {[
                { id: 211, title: "Export-Button im Reporting greift nicht", tone: "steel", s: "Offen", tt: "Bug" },
                { id: 218, title: "Tooltip-Farbe Accessibility", tone: "mustard", s: "In Prüfung", tt: "Verbesserung" }
              ].map((t) => (
                <li key={t.id} className="flex items-center gap-3 rounded-md border border-line bg-white p-3">
                  <Icon name="bug" size={16} style={{ color: "var(--color-crimson)" }} />
                  <span className="text-sm text-ink flex-1">TICKET-{t.id} · {t.title}</span>
                  <Pill tone={t.tone}>{t.s}</Pill>
                </li>
              ))}
            </ul>
          </section>
        </div>
      </div>
    </AppShell>
  );
};

// ───── Page 8: Wiki ─────
window.WikiScreen = function () {
  useLucide();
  const tree = [
    { id: 1, title: "Einführung", slug: "einführung", children: [
      { id: 11, title: "Vision", slug: "einführung/vision" },
      { id: 12, title: "Architektur-Überblick", slug: "einführung/architektur", active: true }
    ]},
    { id: 2, title: "Entwicklung", slug: "entwicklung", children: [
      { id: 21, title: "Setup lokal", slug: "entwicklung/setup" },
      { id: 22, title: "Conventions", slug: "entwicklung/conventions" },
      { id: 23, title: "Test-Strategie", slug: "entwicklung/tests" }
    ]},
    { id: 3, title: "Betrieb", slug: "betrieb", children: [
      { id: 31, title: "Backup", slug: "betrieb/backup" },
      { id: 32, title: "Monitoring", slug: "betrieb/monitoring" }
    ]},
    { id: 4, title: "Glossar", slug: "glossar", children: [] }
  ];
  const Tree = ({ nodes, depth = 0 }) => (
    <ul className={depth > 0 ? "ml-3 border-l border-line pl-3 grid gap-0.5" : "grid gap-0.5"}>
      {nodes.map((n) => (
        <li key={n.id}>
          <a className={`flex items-center gap-2 rounded-md px-2 py-1.5 text-sm ${n.active ? "bg-steel-100 font-semibold text-steel-700" : "text-slate-600 hover:bg-shell"}`}>
            <Icon name={n.children?.length ? "chevron-down" : "file-text"} size={14} />
            <span className="flex-1 truncate">{n.title}</span>
          </a>
          {n.children && n.children.length > 0 ? <Tree nodes={n.children} depth={depth + 1} /> : null}
        </li>
      ))}
    </ul>
  );
  return (
    <AppShell active="/wiki">
      <PageHeader title="Wiki" subtitle="Projektwissen und Dokumentation" action={<Btn variant="primary" icon="plus">Neue Seite</Btn>} />
      <div className="grid gap-6 xl:grid-cols-[24rem_minmax(0,1fr)]">
        <aside className="card p-4">
          <label className="relative block mb-3">
            <Icon name="search" size={14} style={{ position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)", color: "var(--color-slate-400)" }} />
            <input className="h-9 w-full rounded-md border border-line bg-white pl-8 pr-3 text-sm outline-none" placeholder="Wiki durchsuchen" />
          </label>
          <Tree nodes={tree} />
        </aside>
        <div className="grid content-start gap-4">
          <nav className="flex items-center gap-2 text-xs text-slate-500">
            <span>Wiki</span><Icon name="chevron-right" size={14} /><span>Einführung</span><Icon name="chevron-right" size={14} /><span className="text-ink font-semibold">Architektur-Überblick</span>
          </nav>
          <article className="card p-6">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h1 className="text-2xl font-bold text-ink">Architektur-Überblick</h1>
                <p className="mt-1 font-mono text-xs text-slate-500">/wiki/einführung/architektur</p>
              </div>
              <div className="flex gap-2">
                <Btn icon="history">Versionen</Btn>
                <Btn icon="edit-3" variant="primary">Bearbeiten</Btn>
              </div>
            </div>
            <div className="rte-body mt-5">
              <h2 style={{ fontSize: 20, fontWeight: 700, marginTop: 16, marginBottom: 8 }}>Komponenten</h2>
              <p>Die Anwendung besteht aus zwei Workspaces: <code style={{ background: "var(--color-steel-100)", padding: "1px 6px", borderRadius: 4 }}>apps/api</code> (Fastify + SQLite) und <code style={{ background: "var(--color-steel-100)", padding: "1px 6px", borderRadius: 4 }}>apps/web</code> (Vite + React).</p>
              <h2 style={{ fontSize: 20, fontWeight: 700, marginTop: 20, marginBottom: 8 }}>Datenmodell</h2>
              <p>Die zentralen Entitäten sind <b>Projekt</b>, <b>Feature</b>, <b>Use Case</b>, <b>Ticket</b>, <b>Aufgabe</b> und <b>Wiki-Seite</b>. Relationen werden über typed-Junctions abgebildet.</p>
              <ul style={{ listStyle: "disc", paddingLeft: 22, margin: "8px 0" }}>
                <li>Projekte haben N Features</li>
                <li>Features haben N Use Cases</li>
                <li>Tickets können einem Projekt <i>oder</i> Feature gehören</li>
              </ul>
              <h2 style={{ fontSize: 20, fontWeight: 700, marginTop: 20, marginBottom: 8 }}>Backups</h2>
              <p>Die Sicherung erfolgt über Google Drive. Details siehe <a style={{ color: "var(--color-teal)", textDecoration: "underline" }}>Betrieb → Backup</a>.</p>
            </div>
            <footer className="mt-6 flex items-center justify-between border-t border-line pt-4 text-xs text-slate-500">
              <span>Zuletzt geändert von <b>RM</b> · 11. Mai 2026</span>
              <span>Version 4</span>
            </footer>
          </article>
        </div>
      </div>
    </AppShell>
  );
};

// ───── Page 9: Calendar ─────
window.CalendarScreen = function () {
  useLucide();
  const days = ["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"];
  // Build a 5-week grid for May 2026
  const cells = [];
  let day = 1;
  for (let i = 0; i < 35; i++) {
    if (i < 4 || day > 31) {
      cells.push({ day: i < 4 ? 27 + i : day - 31, muted: true });
      if (i >= 4) day++;
    } else {
      cells.push({ day });
      day++;
    }
  }
  const events = {
    5: [{ color: "#2E5984", text: "Sprint Review" }],
    7: [{ color: "#4D9359", text: "Daily 9:30" }],
    11: [{ color: "#2F8E96", text: "Reporting Demo" }],
    12: [{ color: "#ED8C3A", text: "Steering Apollo" }, { color: "#6A40BE", text: "UX Workshop" }],
    14: [{ color: "#D9416A", text: "Hotfix Fenster" }],
    18: [{ color: "#2E5984", text: "Sprint Planning" }],
    21: [{ color: "#E2BA2C", text: "1:1 MR" }],
    25: [{ color: "#2E5984", text: "Sprint Review" }],
    27: [{ color: "#6A40BE", text: "Retro" }],
    28: [{ color: "#4D9359", text: "Release Cut" }]
  };
  const today = 13;
  return (
    <AppShell active="/calendar">
      <PageHeader title="Kalender" subtitle="14 Termine" action={<Btn variant="primary" icon="plus">Neuer Termin</Btn>} />
      <div className="card overflow-hidden">
        <div className="flex items-center justify-between border-b border-line p-4">
          <div className="flex items-center gap-2">
            <Btn icon="chevron-left" iconOnly />
            <Btn icon="chevron-right" iconOnly />
            <Btn>Heute</Btn>
          </div>
          <h2 className="text-xl font-bold text-ink">Mai 2026</h2>
          <div className="inline-flex items-center gap-1 rounded-md border border-line bg-white p-1">
            <button className="h-8 px-3 rounded-sm bg-steel-700 text-white text-xs font-semibold">Monat</button>
            <button className="h-8 px-3 rounded-sm text-slate-600 text-xs font-semibold">Woche</button>
            <button className="h-8 px-3 rounded-sm text-slate-600 text-xs font-semibold">Tag</button>
          </div>
        </div>
        <div className="grid grid-cols-7 border-b border-line bg-shell">
          {days.map((d) => <div key={d} className="px-3 py-2 text-xs font-bold uppercase text-slate-500">{d}</div>)}
        </div>
        <div className="grid grid-cols-7" style={{ gridAutoRows: "minmax(100px, 1fr)" }}>
          {cells.map((c, i) => {
            const isToday = !c.muted && c.day === today;
            const evs = !c.muted ? events[c.day] || [] : [];
            return (
              <div key={i} className={`border-r border-b border-line p-2 ${c.muted ? "bg-shell/60" : "bg-white"}`}>
                <span className={`inline-flex h-6 w-6 items-center justify-center rounded-full text-xs font-bold ${isToday ? "bg-steel-700 text-white" : c.muted ? "text-slate-400" : "text-slate-700"}`}>{c.day}</span>
                <div className="mt-1 grid gap-1">
                  {evs.map((e, k) => (
                    <span key={k} className="block truncate rounded px-2 py-0.5 text-[11px] font-semibold text-white" style={{ background: e.color }}>{e.text}</span>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
      <section className="card p-5">
        <h3 className="text-sm font-bold uppercase tracking-wider text-slate-500 mb-3">Anstehende Termine</h3>
        <ul className="grid gap-2">
          {[
            { date: "13. Mai · 09:30", title: "Daily", color: "#4D9359" },
            { date: "14. Mai · 14:00", title: "Hotfix Fenster Apollo", color: "#D9416A" },
            { date: "18. Mai · 10:00", title: "Sprint Planning", color: "#2E5984" },
            { date: "21. Mai · 15:00", title: "1:1 mit MR", color: "#E2BA2C" }
          ].map((e, i) => (
            <li key={i} className="flex items-center gap-3 rounded-md border border-line bg-white p-3">
              <span className="h-9 w-1.5 rounded-full" style={{ background: e.color }}></span>
              <div className="flex-1">
                <p className="text-sm font-semibold text-ink">{e.title}</p>
                <p className="text-xs text-slate-500">{e.date}</p>
              </div>
              <Btn icon="edit-3" iconOnly />
            </li>
          ))}
        </ul>
      </section>
    </AppShell>
  );
};
