// Modal screens — create/edit forms. Each renders the AppShell under a darkened overlay.

function ModalScene({ active, modal }) {
  return (
    <div className="relative h-full w-full overflow-hidden">
      <AppShell active={active}>
        {/* mute background — just an empty placeholder of the page */}
        <PageHeader title="" />
      </AppShell>
      <div className="absolute inset-0 flex items-center justify-center" style={{ background: "rgba(15,37,66,0.55)" }}>
        {modal}
      </div>
    </div>
  );
}

// Reusable form body container
function ModalBody({ children }) {
  return <div className="grid min-h-0 flex-1 gap-5 overflow-auto bg-shell p-5">{children}</div>;
}

function ModalShell({ headerKind = "steel", icon, breadcrumb, title, subtitle, submitLabel, footerStart, children, width = 960 }) {
  const headerBg = headerKind === "teal"
    ? "linear-gradient(135deg, var(--color-teal), rgba(47,142,150,0.75))"
    : "linear-gradient(135deg, var(--color-steel-700), var(--color-steel-600))";
  return (
    <div className="flex flex-col overflow-hidden rounded-2xl bg-shell" style={{ width, maxHeight: "92%", boxShadow: "var(--shadow-modal)" }}>
      <header className="relative shrink-0 overflow-hidden px-6 py-5 text-white" style={{ background: headerBg }}>
        <div className="pointer-events-none absolute -right-8 -top-32 h-80 w-80 rounded-full bg-white/12 blur-sm"></div>
        <div className="relative flex items-start justify-between gap-4">
          <div className="grid gap-2">
            <div className="flex flex-wrap items-center gap-2 text-xs font-semibold uppercase text-white/75">
              {breadcrumb.map((b, i) => <span key={i} className="inline-flex items-center gap-2">{i > 0 ? <span>›</span> : null}<span>{b}</span></span>)}
            </div>
            <div className="flex items-center gap-3">
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/12"><Icon name={icon} size={21} /></span>
              <div>
                <h2 className="text-2xl font-bold tracking-normal">{title}</h2>
                {subtitle ? <p className="text-sm text-white/75">{subtitle}</p> : null}
              </div>
            </div>
          </div>
          <button className="flex h-9 w-9 items-center justify-center rounded-full text-white/80 hover:bg-white/12"><Icon name="x" size={18} /></button>
        </div>
      </header>
      {children}
      <footer className="flex shrink-0 flex-wrap items-center justify-between gap-3 border-t border-line bg-white px-5 py-4">
        <div className="flex items-center gap-2">{footerStart}</div>
        <div className="flex items-center gap-3">
          <Btn>Abbrechen</Btn>
          <Btn variant="primary" icon="save">{submitLabel}</Btn>
        </div>
      </footer>
    </div>
  );
}

// ───── Modal 1: Projekt — Details ─────
window.ProjectFormDetailsModal = function () {
  useLucide();
  const tabs = [
    { value: "details", label: "Details" },
    { value: "features", label: "Features", count: 3 },
    { value: "tasks", label: "Aufgaben" },
    { value: "tickets", label: "Tickets", count: 5 },
    { value: "comments", label: "Kommentare", count: 4 },
    { value: "notes", label: "Notizen", count: 2 },
    { value: "attachments", label: "Dateien", count: 6 },
    { value: "backlog", label: "Backlog", count: 14 },
    { value: "import", label: "Import" }
  ];
  return (
    <ModalScene active="/projects" modal={
      <ModalShell icon="folder-kanban" breadcrumb={["Projekte", "Apollo CRM"]} title="Projekt bearbeiten" subtitle="Zuletzt aktualisiert am 12. Mai 2026" submitLabel="Speichern" footerStart={<Btn icon="trash-2" variant="ghost" className="text-crimson">Löschen</Btn>}>
        <TabBar tabs={tabs} active="details" />
        <ModalBody>
          <Section title="Stammdaten">
            <div className="grid gap-4 md:grid-cols-[minmax(0,1fr)_10rem]">
              <Field label="Projektname" required><input className="input" defaultValue="Apollo CRM" /></Field>
              <Field label="Kürzel"><input className="input input-mono" defaultValue="AC" readOnly /></Field>
            </div>
            <div className="mt-4"><Field label="Beschreibung">
              <div className="rte">
                <div className="rte-toolbar">
                  {["B", "I", "U", "S"].map((t) => <button key={t} className="rte-btn">{t}</button>)}
                  <span className="mx-1 w-px bg-line"></span>
                  <button className="rte-btn"><Icon name="list" size={14} /></button>
                  <button className="rte-btn"><Icon name="list-ordered" size={14} /></button>
                  <button className="rte-btn"><Icon name="link" size={14} /></button>
                  <button className="rte-btn"><Icon name="image" size={14} /></button>
                </div>
                <div className="rte-body">Konsolidierung der Kundendaten und Migration des Vertriebs-Funnels in das neue CRM. Steering Committee jeden 2. Mittwoch.</div>
              </div>
            </Field></div>
          </Section>
          <Section title="Identität">
            <div className="grid gap-4 md:grid-cols-2">
              <Field label="Farbe">
                <ColorSwatches selected="#2E5984" swatches={["#2E5984", "#D9416A", "#ED8C3A", "#E2BA2C", "#4D9359", "#2F8E96", "#6A40BE", "#C13D9A", "#0F2542"]} />
              </Field>
              <Field label="Status">
                <SegmentedControl value="active" options={[
                  { value: "active", label: "Aktiv" },
                  { value: "on_hold", label: "Pausiert" },
                  { value: "completed", label: "Abgeschlossen" },
                  { value: "archived", label: "Archiviert" }
                ]} />
              </Field>
            </div>
          </Section>
          <Section title="Zeitraum">
            <div className="grid gap-4 md:grid-cols-2">
              <Field label="Start"><input className="input" type="date" defaultValue="2026-02-01" /></Field>
              <Field label="Fällig"><input className="input" type="date" defaultValue="2026-09-30" /></Field>
            </div>
          </Section>
          <Section title="Tags">
            <div className="flex flex-wrap gap-2">
              <Badge color="#4D9359">Roadmap ✕</Badge>
              <Badge color="#2E5984">Backend ✕</Badge>
              <button className="badge badge-mute" style={{ borderStyle: "dashed" }}>+ Tag</button>
            </div>
          </Section>
        </ModalBody>
      </ModalShell>
    } />
  );
};

// ───── Modal 2: Projekt — Aufgaben Tab ─────
window.ProjectFormTasksModal = function () {
  useLucide();
  const tabs = [
    { value: "details", label: "Details" },
    { value: "features", label: "Features", count: 3 },
    { value: "tasks", label: "Aufgaben" },
    { value: "tickets", label: "Tickets", count: 5 },
    { value: "comments", label: "Kommentare", count: 4 },
    { value: "notes", label: "Notizen", count: 2 },
    { value: "attachments", label: "Dateien", count: 6 },
    { value: "backlog", label: "Backlog", count: 14 },
    { value: "import", label: "Import" }
  ];
  const tasks = [
    { title: "Datenmapping CRM → SAP klären", status: "In Arbeit", tone: "tangerine", priority: "Hoch", priorityTone: "tangerine", assignee: "MR", due: "14. Mai" },
    { title: "Importjob für Kontaktduplikate", status: "Offen", tone: "crimson", priority: "Dringend", priorityTone: "crimson", assignee: "JS", due: "Heute" },
    { title: "Stakeholder-Interviews Phase 2", status: "In Arbeit", tone: "tangerine", priority: "Mittel", priorityTone: "mustard", assignee: "AK", due: "22. Mai" },
    { title: "Migrationstool Smoke-Test", status: "Offen", tone: "crimson", priority: "Hoch", priorityTone: "tangerine", assignee: "JL", due: "—" },
    { title: "Account-Manager Schulung", status: "Erledigt", tone: "fern", priority: "Niedrig", priorityTone: "steel", assignee: "SK", due: "07. Mai" }
  ];
  return (
    <ModalScene active="/projects" modal={
      <ModalShell icon="folder-kanban" breadcrumb={["Projekte", "Apollo CRM"]} title="Projekt bearbeiten" subtitle="Zuletzt aktualisiert am 12. Mai 2026" submitLabel="Speichern" footerStart={<Btn icon="trash-2" variant="ghost" className="text-crimson">Löschen</Btn>}>
        <TabBar tabs={tabs} active="tasks" />
        <ModalBody>
          <Section title="Aufgaben" action={
            <div className="flex gap-2">
              <Btn icon="link">Verknüpfen</Btn>
              <Btn variant="primary" icon="plus">Neue Aufgabe</Btn>
            </div>
          }>
            <div className="grid grid-cols-3 gap-3">
              {[
                { col: "Offen", tone: "crimson", items: tasks.filter((t) => t.status === "Offen") },
                { col: "In Arbeit", tone: "tangerine", items: tasks.filter((t) => t.status === "In Arbeit") },
                { col: "Erledigt", tone: "fern", items: tasks.filter((t) => t.status === "Erledigt") }
              ].map((c) => (
                <section key={c.col} className="grid content-start gap-2 rounded-lg border border-line p-3" style={{ background: "rgba(244,247,250,0.6)" }}>
                  <header className="flex items-center justify-between">
                    <div className="flex items-center gap-2"><span className="h-2 w-2 rounded-full" style={{ background: `var(--color-${c.tone})` }}></span><h3 className="text-sm font-semibold">{c.col}</h3></div>
                    <span className="rounded-full bg-white px-2 py-0.5 text-xs font-semibold text-slate-600 shadow-sm">{c.items.length}</span>
                  </header>
                  {c.items.map((t, i) => (
                    <article key={i} className="card p-3 grid gap-2">
                      <p className="text-sm font-semibold text-ink">{t.title}</p>
                      <div className="flex items-center gap-2">
                        <Badge tone={t.priorityTone}>{t.priority}</Badge>
                      </div>
                      <div className="flex items-center justify-between border-t border-line pt-2 text-xs text-slate-500">
                        <span className="inline-flex items-center gap-1"><Icon name="calendar-clock" size={13} />{t.due}</span>
                        <span className="flex h-6 w-6 items-center justify-center rounded-full bg-steel-100 text-steel-700 text-[10px] font-bold">{t.assignee}</span>
                      </div>
                    </article>
                  ))}
                </section>
              ))}
            </div>
          </Section>
        </ModalBody>
      </ModalShell>
    } />
  );
};

// ───── Modal 3: Projekt — Backlog Tab ─────
window.ProjectFormBacklogModal = function () {
  useLucide();
  const tabs = [
    { value: "details", label: "Details" },
    { value: "features", label: "Features", count: 3 },
    { value: "tasks", label: "Aufgaben" },
    { value: "tickets", label: "Tickets", count: 5 },
    { value: "comments", label: "Kommentare", count: 4 },
    { value: "notes", label: "Notizen", count: 2 },
    { value: "attachments", label: "Dateien", count: 6 },
    { value: "backlog", label: "Backlog", count: 14 },
    { value: "import", label: "Import" }
  ];
  const items = [
    { title: "Bulk-Edit für Kontakte", feature: "Kunden-360", priority: "Hoch", priorityTone: "tangerine", status: "Offen", tone: "steel", effort: "M" },
    { title: "Drag&Drop im Pipeline-Board", feature: "Reporting Dashboard", priority: "Mittel", priorityTone: "mustard", status: "Offen", tone: "steel", effort: "L" },
    { title: "Audit-Log für Datenänderungen", feature: "Datenimport CSV/Excel", priority: "Niedrig", priorityTone: "steel", status: "In Arbeit", tone: "tangerine", effort: "M" },
    { title: "Filter „Letzte 7 Tage“", feature: "Reporting Dashboard", priority: "Mittel", priorityTone: "mustard", status: "Erledigt", tone: "fern", effort: "S" },
    { title: "Saved-Views Personalisierung", feature: "Reporting Dashboard", priority: "Hoch", priorityTone: "tangerine", status: "Offen", tone: "steel", effort: "L" },
    { title: "API-Token verlängern", feature: "—", priority: "Mittel", priorityTone: "mustard", status: "Verworfen", tone: "crimson", effort: "XS" }
  ];
  return (
    <ModalScene active="/projects" modal={
      <ModalShell icon="folder-kanban" breadcrumb={["Projekte", "Apollo CRM"]} title="Projekt bearbeiten" subtitle="Zuletzt aktualisiert am 12. Mai 2026" submitLabel="Speichern" footerStart={<Btn icon="trash-2" variant="ghost" className="text-crimson">Löschen</Btn>}>
        <TabBar tabs={tabs} active="backlog" />
        <ModalBody>
          <Section title="Backlog" action={
            <div className="flex items-center gap-2">
              <FilterChips value="all" allCount={6} options={[
                { value: "open", label: "Offen", count: 3 },
                { value: "in_progress", label: "In Arbeit", count: 1 },
                { value: "done", label: "Erledigt", count: 1 },
                { value: "rejected", label: "Verworfen", count: 1 }
              ]} />
              <Btn variant="primary" icon="plus">Neues Item</Btn>
            </div>
          }>
            <div className="card overflow-hidden">
              <div className="grid grid-cols-[minmax(0,1fr)_10rem_8rem_6rem_4rem_auto] gap-3 border-b border-line bg-shell px-4 py-2 text-xs font-bold uppercase text-slate-500">
                <span>Titel</span><span>Feature</span><span>Priorität</span><span>Status</span><span>Effort</span><span className="text-right">Aktionen</span>
              </div>
              {items.map((it, i) => (
                <div key={i} className="grid grid-cols-[minmax(0,1fr)_10rem_8rem_6rem_4rem_auto] items-center gap-3 border-b border-line px-4 py-3 text-sm last:border-b-0">
                  <span className="font-medium text-ink truncate">{it.title}</span>
                  <span className="text-slate-600 truncate font-mono text-xs">{it.feature}</span>
                  <Badge tone={it.priorityTone}>{it.priority}</Badge>
                  <Pill tone={it.tone}>{it.status}</Pill>
                  <span className="font-mono text-xs text-slate-500">{it.effort}</span>
                  <div className="flex justify-end gap-1">
                    <Btn icon="edit-3" iconOnly variant="ghost" />
                    <Btn icon="trash-2" iconOnly variant="ghost" />
                  </div>
                </div>
              ))}
            </div>
          </Section>
        </ModalBody>
      </ModalShell>
    } />
  );
};

// ───── Modal 4: Feature — Details ─────
window.FeatureFormDetailsModal = function () {
  useLucide();
  const tabs = [
    { value: "details", label: "Details" },
    { value: "useCases", label: "Use Cases", count: 5 },
    { value: "tasks", label: "Aufgaben" },
    { value: "tickets", label: "Tickets" },
    { value: "projects", label: "Projekte", count: 2 },
    { value: "comments", label: "Kommentare", count: 3 },
    { value: "attachments", label: "Dateien", count: 4 }
  ];
  return (
    <ModalScene active="/features" modal={
      <ModalShell icon="book-open" breadcrumb={["Features", "Bearbeiten"]} title="Feature bearbeiten" subtitle="Feature-Inhalt und Beziehungen in einem Formular pflegen." submitLabel="Speichern" footerStart={<Btn icon="trash-2" variant="ghost" className="text-crimson">Löschen</Btn>}>
        <TabBar tabs={tabs} active="details" />
        <ModalBody>
          <Section title="Stammdaten">
            <div className="grid gap-4 md:grid-cols-[minmax(0,1fr)_minmax(0,1fr)_10rem]">
              <Field label="Titel" required><input className="input" defaultValue="Reporting Dashboard" /></Field>
              <Field label="Slug" required>
                <span className="grid grid-cols-[auto_minmax(0,1fr)] overflow-hidden rounded-md border border-line bg-white">
                  <span className="flex h-10 items-center px-2 text-slate-400"><Icon name="link" size={14} /></span>
                  <input className="h-10 min-w-0 px-2 font-mono text-sm outline-none border-l border-line" defaultValue="reporting-dashboard" />
                </span>
              </Field>
              <Field label="Sortierung"><input className="input" type="number" defaultValue="3" /></Field>
            </div>
          </Section>
          <Section title="Status">
            <SegmentedControl value="active" options={[
              { value: "draft", label: "Entwurf" },
              { value: "active", label: "Aktiv" },
              { value: "done", label: "Erledigt" },
              { value: "archived", label: "Archiviert" }
            ]} />
          </Section>
          <Section title="Kurzbeschreibung">
            <div className="rte">
              <div className="rte-toolbar">{["B","I","U"].map((t) => <button key={t} className="rte-btn">{t}</button>)}<span className="mx-1 w-px bg-line"></span><button className="rte-btn"><Icon name="list" size={14}/></button></div>
              <div className="rte-body">Live-Dashboard mit Vertriebs-KPIs, Filter nach Region und Zeitraum. Drill-down in Tickets und Backlog-Items.</div>
            </div>
          </Section>
          <Section title="Inhalt">
            <div className="rte">
              <div className="rte-toolbar">{["B","I","U","S"].map((t) => <button key={t} className="rte-btn">{t}</button>)}<span className="mx-1 w-px bg-line"></span>{["H1","H2","H3"].map((t) => <button key={t} className="rte-btn">{t}</button>)}<span className="mx-1 w-px bg-line"></span><button className="rte-btn"><Icon name="list" size={14}/></button><button className="rte-btn"><Icon name="list-ordered" size={14}/></button><button className="rte-btn"><Icon name="quote" size={14}/></button><button className="rte-btn"><Icon name="code" size={14}/></button><button className="rte-btn"><Icon name="link" size={14}/></button></div>
              <div className="rte-body">
                <p style={{ fontWeight: 700, fontSize: 18, marginBottom: 8 }}>Zielbild</p>
                <p>Ein einziger Ort, an dem Vertrieb, Operations und Geschäftsleitung KPIs konsumieren – ohne Excel-Export.</p>
                <p style={{ fontWeight: 700, fontSize: 18, marginTop: 12, marginBottom: 8 }}>Scope</p>
                <ul style={{ listStyle: "disc", paddingLeft: 22, margin: 0 }}>
                  <li>Filter nach Region, Zeitraum, Status</li>
                  <li>Drill-down in Tickets / Backlog-Items</li>
                  <li>Export als PDF (out of scope für MVP)</li>
                </ul>
              </div>
            </div>
          </Section>
        </ModalBody>
      </ModalShell>
    } />
  );
};

// ───── Modal 5: Feature — Use Cases Tab ─────
window.FeatureFormUseCasesModal = function () {
  useLucide();
  const tabs = [
    { value: "details", label: "Details" },
    { value: "useCases", label: "Use Cases", count: 5 },
    { value: "tasks", label: "Aufgaben" },
    { value: "tickets", label: "Tickets" },
    { value: "projects", label: "Projekte", count: 2 },
    { value: "comments", label: "Kommentare", count: 3 },
    { value: "attachments", label: "Dateien", count: 4 }
  ];
  const useCases = [
    { title: "Vertriebsleiter sieht KPIs nach Region", slug: "kpis-region", status: "Aktiv", tone: "fern" },
    { title: "Mitarbeiter filtert nach Zeitraum", slug: "filter-zeitraum", status: "Aktiv", tone: "fern" },
    { title: "Export als PDF für Steering", slug: "pdf-export", status: "Entwurf", tone: "mustard" },
    { title: "Vergleich mit Vorjahr", slug: "vergleich-vorjahr", status: "Entwurf", tone: "mustard" },
    { title: "Live-Drill-down in Tickets", slug: "drilldown-tickets", status: "Aktiv", tone: "fern" }
  ];
  return (
    <ModalScene active="/features" modal={
      <ModalShell icon="book-open" breadcrumb={["Features", "Bearbeiten"]} title="Feature bearbeiten" subtitle="Use Cases pflegen." submitLabel="Speichern" footerStart={<Btn icon="trash-2" variant="ghost" className="text-crimson">Löschen</Btn>}>
        <TabBar tabs={tabs} active="useCases" />
        <ModalBody>
          <Section title="Use Cases" action={<Btn variant="primary" icon="plus">Neuer Use Case</Btn>}>
            <div className="grid gap-3 md:grid-cols-2">
              {useCases.map((u) => (
                <article key={u.slug} className="card p-4 grid gap-3">
                  <div className="flex items-start gap-3">
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-steel-600 text-white"><Icon name="file-text" size={18} /></span>
                    <div className="min-w-0">
                      <h3 className="text-sm font-semibold text-ink leading-tight">{u.title}</h3>
                      <p className="font-mono text-xs text-slate-500 truncate">/use-cases/{u.slug}</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between border-t border-line pt-2">
                    <Pill tone={u.tone}>{u.status}</Pill>
                    <div className="flex gap-1"><Btn icon="edit-3" iconOnly variant="ghost" /><Btn icon="trash-2" iconOnly variant="ghost" /></div>
                  </div>
                </article>
              ))}
            </div>
          </Section>
        </ModalBody>
      </ModalShell>
    } />
  );
};
