// Feature / Ticket / Event / Wiki modals + ModalManager router.

// ───── Feature Form ─────
function LiveFeatureForm() {
  const { modal, closeModal, setModalTab, openModal } = useNav();
  const isEdit = modal.mode === "edit";
  const feature = modal.entity;
  const activeTab = modal.tab || "details";
  const tabs = [
    { value: "details", label: "Details" },
    { value: "useCases", label: "Use Cases", count: feature ? (MOCK.useCases[feature.id] || []).length : 0 },
    { value: "tasks", label: "Aufgaben" },
    { value: "tickets", label: "Tickets" },
    { value: "projects", label: "Projekte", count: feature ? (MOCK.featureProjects[feature.id] || []).length : 0 },
    { value: "comments", label: "Kommentare", count: 3 },
    { value: "attachments", label: "Dateien", count: 4 }
  ];
  return (
    <LiveModalShell
      icon="book-open"
      breadcrumb={["Features", isEdit ? feature.title : "Neu"]}
      title={isEdit ? "Feature bearbeiten" : "Neues Feature"}
      subtitle="Feature-Inhalt und Beziehungen in einem Formular pflegen."
      submitLabel={isEdit ? "Speichern" : "Feature anlegen"}
      footerStart={isEdit ? <button onClick={closeModal} className="btn btn-ghost text-crimson"><Icon name="trash-2" size={17} />Löschen</button> : null}
      onClose={closeModal}
    >
      <LiveTabBar tabs={tabs} active={activeTab} onChange={setModalTab} />
      <div className="grid min-h-0 flex-1 gap-5 overflow-auto bg-shell p-5">
        {activeTab === "details" ? <FeatureFormDetails feature={feature} /> : null}
        {activeTab === "useCases" ? <FeatureFormUseCases feature={feature} /> : null}
        {activeTab === "projects" ? <FeatureFormProjects feature={feature} /> : null}
        {activeTab === "tasks" ? <ProjectFormTasks project={{ id: 1 }} /> : null}
        {activeTab === "tickets" ? <ProjectFormTickets project={{ id: 1 }} openModal={openModal} /> : null}
        {activeTab === "comments" ? <ProjectFormComments /> : null}
        {activeTab === "attachments" ? <ProjectFormAttachments /> : null}
      </div>
    </LiveModalShell>
  );
}

function FeatureFormDetails({ feature }) {
  const [status, setStatus] = React.useState(feature?.status || "draft");
  const statusOpts = [
    { value: "draft", label: "Entwurf", color: "var(--color-mustard)" },
    { value: "active", label: "Aktiv", color: "var(--color-fern)" },
    { value: "done", label: "Erledigt", color: "var(--color-violet)" },
    { value: "archived", label: "Archiviert", color: "var(--color-steel-700)" }
  ];
  return (
    <>
      <Section title="Stammdaten">
        <div className="grid gap-4 md:grid-cols-[minmax(0,1fr)_minmax(0,1fr)_10rem]">
          <Field label="Titel" required><input className="input" defaultValue={feature?.title || ""} placeholder="z. B. Reporting Dashboard" /></Field>
          <Field label="Slug" required>
            <span className="grid grid-cols-[auto_minmax(0,1fr)] overflow-hidden rounded-md border border-line bg-white">
              <span className="flex h-10 items-center px-2 text-slate-400"><Icon name="link" size={14} /></span>
              <input className="h-10 min-w-0 px-2 font-mono text-sm outline-none border-l border-line" defaultValue={feature?.slug || ""} />
            </span>
          </Field>
          <Field label="Sortierung"><input className="input" type="number" defaultValue={feature?.sortOrder || 0} /></Field>
        </div>
      </Section>
      <Section title="Status">
        <div className="inline-flex items-center gap-1 rounded-md border border-line bg-white p-1">
          {statusOpts.map((o) => (
            <button key={o.value} onClick={() => setStatus(o.value)} className={`h-9 px-3 rounded-sm text-sm font-semibold transition ${o.value === status ? "text-white" : "text-slate-600 hover:text-ink"}`} style={o.value === status ? { background: o.color } : {}}>
              {o.label}
            </button>
          ))}
        </div>
      </Section>
      <Section title="Kurzbeschreibung">
        <RteMock html={feature?.desc || "<p style='color:#94a3b8'>Kurzbeschreibung…</p>"} minHeight="8rem" />
      </Section>
      <Section title="Inhalt">
        <RteMock html="<p style='font-weight:700;font-size:18px;margin-bottom:8px'>Zielbild</p><p>Ein einziger Ort, an dem Vertrieb, Operations und Geschäftsleitung KPIs konsumieren – ohne Excel-Export.</p><p style='font-weight:700;font-size:18px;margin-top:12px;margin-bottom:8px'>Scope</p><ul style='list-style:disc;padding-left:22px;margin:0'><li>Filter nach Region, Zeitraum, Status</li><li>Drill-down in Tickets / Backlog-Items</li><li>Export als PDF (out of scope für MVP)</li></ul>" minHeight="14rem" />
      </Section>
    </>
  );
}

function FeatureFormUseCases({ feature }) {
  const useCases = MOCK.useCases[feature?.id] || [];
  return (
    <Section title="Use Cases" action={<button className="btn btn-primary"><Icon name="plus" size={17} />Neuer Use Case</button>}>
      <div className="grid gap-3 md:grid-cols-2">
        {useCases.map((u) => (
          <article key={u.id} className="card p-4 grid gap-3">
            <div className="flex items-start gap-3">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-steel-600 text-white"><Icon name="file-text" size={18} /></span>
              <div className="min-w-0">
                <h3 className="text-sm font-semibold text-ink leading-tight">{u.title}</h3>
                <p className="font-mono text-xs text-slate-500 truncate">/use-cases/{u.slug}</p>
              </div>
            </div>
            <div className="flex items-center justify-between border-t border-line pt-2">
              <Pill tone={u.statusTone}>{u.statusLabel}</Pill>
              <div className="flex gap-1"><button className="btn btn-ghost btn-icon"><Icon name="edit-3" size={17} /></button><button className="btn btn-ghost btn-icon"><Icon name="trash-2" size={17} /></button></div>
            </div>
          </article>
        ))}
        {useCases.length === 0 ? <p className="col-span-2 text-sm text-slate-500 text-center py-4">Noch keine Use Cases.</p> : null}
      </div>
    </Section>
  );
}

function FeatureFormProjects({ feature }) {
  const projects = (MOCK.featureProjects[feature?.id] || []).map((pid) => MOCK.projects.find((p) => p.id === pid)).filter(Boolean);
  return (
    <Section title="Verknüpfte Projekte" action={<button className="btn btn-primary"><Icon name="link" size={17} />Projekt verknüpfen</button>}>
      <div className="grid gap-3 md:grid-cols-2">
        {projects.map((p) => (
          <article key={p.id} className="card overflow-hidden">
            <div style={{ background: p.color, height: 4 }}></div>
            <div className="p-4 grid gap-3">
              <div className="flex items-start gap-3">
                <span className="flex h-12 w-12 items-center justify-center rounded-xl text-white" style={{ background: p.color }}><Icon name="folder-open" size={20} /></span>
                <div className="min-w-0">
                  <h3 className="text-base font-semibold text-ink">{p.name}</h3>
                  <Pill tone={p.statusTone}>{p.statusLabel}</Pill>
                </div>
              </div>
              <div className="flex items-center justify-between border-t border-line pt-2 text-xs">
                <span className="text-slate-500">{p.openCount} offene Aufgaben</span>
                <button className="btn btn-ghost"><Icon name="unlink" size={15} />Entfernen</button>
              </div>
            </div>
          </article>
        ))}
      </div>
    </Section>
  );
}

// ───── Ticket Form ─────
function LiveTicketForm() {
  const { modal, closeModal } = useNav();
  const t = modal.entity;
  const isEdit = modal.mode === "edit";
  const [type, setType] = React.useState(t?.type || "bug");
  const [priority, setPriority] = React.useState(t?.priority || "medium");
  const [status, setStatus] = React.useState(t?.status || "open");
  const RadioRow = ({ options, value, onChange }) => (
    <div className="grid gap-1.5">
      {options.map((o) => {
        const sel = o.value === value;
        return (
          <button key={o.value} type="button" onClick={() => onChange(o.value)} className={`flex items-center gap-3 rounded-md border px-3 py-2.5 text-sm font-medium ${sel ? "border-transparent text-white" : "border-line bg-white text-ink hover:border-steel-300"}`} style={sel ? { background: `var(--color-${o.color})` } : {}}>
            <span className={`h-4 w-4 rounded-full border-2 ${sel ? "border-white" : "border-line"}`} style={sel ? { background: "rgba(255,255,255,0.2)" } : {}}>
              {sel ? <span className="block m-[3px] h-1.5 w-1.5 rounded-full bg-white"></span> : null}
            </span>
            {o.label}
          </button>
        );
      })}
    </div>
  );
  return (
    <LiveModalShell
      icon="bug"
      breadcrumb={["Tickets", isEdit ? `TICKET-${t.id}` : "Neu"]}
      title={isEdit ? "Ticket bearbeiten" : "Ticket anlegen"}
      subtitle="Status, Priorität und Kontext für die Nachverfolgung."
      submitLabel={isEdit ? "Speichern" : "Ticket anlegen"}
      onClose={closeModal}
    >
      <div className="grid min-h-0 flex-1 gap-5 overflow-auto bg-shell p-5">
        <Section title="Basisdaten">
          <Field label="Titel" required><input className="input" defaultValue={t?.title || ""} placeholder="Kurze Beschreibung des Problems" /></Field>
          <div className="mt-4"><Field label="Beschreibung">
            <RteMock html={t?.desc || "<p style='color:#94a3b8'>Schritte zur Reproduktion, erwartetes vs. tatsächliches Verhalten…</p>"} minHeight="8rem" />
          </Field></div>
        </Section>
        <Section title="Typ & Priorität">
          <div className="grid gap-4 md:grid-cols-2">
            <Field label="Typ">
              <RadioRow value={type} onChange={setType} options={[
                { value: "bug", label: "Bug", color: "crimson" },
                { value: "improvement", label: "Verbesserung", color: "fern" },
                { value: "question", label: "Frage", color: "violet" },
                { value: "task", label: "Aufgabe", color: "tangerine" }
              ]} />
            </Field>
            <Field label="Priorität">
              <RadioRow value={priority} onChange={setPriority} options={[
                { value: "low", label: "Niedrig", color: "fern" },
                { value: "medium", label: "Mittel", color: "violet" },
                { value: "high", label: "Hoch", color: "tangerine" },
                { value: "urgent", label: "Dringend", color: "crimson" }
              ]} />
            </Field>
          </div>
        </Section>
        <Section title="Status & Lösung">
          <Field label="Status">
            <RadioRow value={status} onChange={setStatus} options={[
              { value: "open", label: "Offen", color: "violet" },
              { value: "in_progress", label: "In Arbeit", color: "tangerine" },
              { value: "in_review", label: "In Prüfung", color: "tangerine" },
              { value: "resolved", label: "Gelöst", color: "fern" },
              { value: "closed", label: "Geschlossen", color: "violet" }
            ]} />
          </Field>
        </Section>
        <Section title="Zuweisung">
          <div className="grid gap-4 md:grid-cols-3">
            <Field label="Zuständig">
              <span className="relative block">
                <Icon name="user-round" size={16} style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", color: "var(--color-slate-400)" }} />
                <input className="input" style={{ paddingLeft: 36 }} defaultValue={t?.assignee ? `${t.assignee} · J. Schreiber` : ""} placeholder="Name" />
              </span>
            </Field>
            <Field label="Reporter">
              <span className="relative block">
                <Icon name="user-round" size={16} style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", color: "var(--color-slate-400)" }} />
                <input className="input" style={{ paddingLeft: 36 }} defaultValue={t?.reporter || ""} placeholder="Name" />
              </span>
            </Field>
            <Field label="Fällig"><input className="input" type="date" /></Field>
          </div>
        </Section>
        {type === "bug" ? (
          <Section title="Details">
            <div className="grid gap-4 md:grid-cols-2">
              <Field label="Umgebung"><input className="input" defaultValue={t?.environment || ""} placeholder="z. B. Production v1.2, Chrome 120" /></Field>
              <Field label="Betroffene Version"><input className="input input-mono" defaultValue={t?.affectedVersion || ""} /></Field>
            </div>
          </Section>
        ) : null}
        <Section title="Tags">
          <div className="flex flex-wrap gap-2">
            <Badge color="#D9416A">Hotfix ✕</Badge>
            <Badge color="#2E5984">Backend ✕</Badge>
            <button className="badge badge-mute" style={{ borderStyle: "dashed" }}>+ Tag</button>
          </div>
        </Section>
      </div>
    </LiveModalShell>
  );
}

// ───── Event Form ─────
function LiveEventForm() {
  const { modal, closeModal } = useNav();
  const ev = modal.entity;
  const isEdit = modal.mode === "edit";
  const [allDay, setAllDay] = React.useState(false);
  return (
    <LiveModalShell
      icon="calendar-clock"
      breadcrumb={["Kalender", isEdit ? ev.title : "Neuer Termin"]}
      title={isEdit ? "Termin bearbeiten" : "Termin anlegen"}
      submitLabel={isEdit ? "Speichern" : "Termin anlegen"}
      width={820}
      onClose={closeModal}
      footerStart={isEdit ? <button onClick={closeModal} className="btn btn-ghost text-crimson"><Icon name="trash-2" size={17} />Löschen</button> : null}
    >
      <div className="grid min-h-0 flex-1 gap-5 overflow-auto bg-shell p-5">
        <Section title="Stammdaten">
          <Field label="Titel" required><input className="input" defaultValue={ev?.title || ""} placeholder="z. B. Sprint Review" /></Field>
          <div className="mt-4"><Field label="Beschreibung">
            <RteMock html="<p style='color:#94a3b8'>Agenda, Stakeholder, Vorbereitung…</p>" minHeight="7rem" />
          </Field></div>
        </Section>
        <Section title="Zeitraum">
          <label className="mb-3 flex items-center gap-2 text-sm font-medium">
            <input type="checkbox" checked={allDay} onChange={(e) => setAllDay(e.target.checked)} /> Ganztägig
          </label>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Start"><input className="input" type={allDay ? "date" : "datetime-local"} defaultValue={allDay ? "2026-05-18" : "2026-05-18T10:00"} /></Field>
            <Field label="Ende"><input className="input" type={allDay ? "date" : "datetime-local"} defaultValue={allDay ? "2026-05-18" : "2026-05-18T11:30"} /></Field>
          </div>
        </Section>
        <Section title="Zuordnung">
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Projekt"><select className="input"><option>Keins</option>{MOCK.projects.map((p) => <option key={p.id}>{p.name}</option>)}</select></Field>
            <Field label="Aufgabe"><select className="input"><option>Keine</option>{(MOCK.tasks[1] || []).map((t, i) => <option key={i}>{t.title}</option>)}</select></Field>
          </div>
        </Section>
        <Section title="Farbe">
          <div className="flex flex-wrap gap-2">
            {["#2E5984", "#2F8E96", "#ED8C3A", "#E2BA2C", "#4D9359", "#6B92BD", "#6A40BE", "#C13D9A"].map((s) => (
              <button key={s} className="h-9 w-9 rounded-full border-2 border-white" style={{ background: s, boxShadow: "0 0 0 1px var(--color-line)" }}></button>
            ))}
          </div>
        </Section>
      </div>
    </LiveModalShell>
  );
}

// ───── Wiki Form ─────
function LiveWikiForm() {
  const { modal, closeModal } = useNav();
  const p = modal.entity;
  const isEdit = modal.mode === "edit";
  return (
    <LiveModalShell
      headerKind="teal"
      icon="library"
      breadcrumb={["Wiki", p?.parent || "Root", isEdit ? "Bearbeiten" : "Neu"]}
      title={isEdit ? (p?.title || "Wiki-Seite bearbeiten") : "Neue Wiki-Seite"}
      subtitle="Inhalte strukturieren, Slug pflegen und veröffentlichen."
      submitLabel="Veröffentlichen"
      footerStart={<button className="btn btn-secondary"><Icon name="eye" size={17} />Vorschau</button>}
      width={1000}
      onClose={closeModal}
    >
      <div className="grid min-h-0 flex-1 gap-5 overflow-auto bg-shell p-5">
        <Section>
          <div className="grid gap-4 md:grid-cols-2">
            <Field label="Titel"><input className="input" defaultValue={p?.title || ""} placeholder="Titel der Seite" /></Field>
            <Field label="Kategorie">
              <select className="input">
                <option>Root-Seite</option>
                {MOCK.wikiTree.map((n) => <option key={n.id}>{n.slug}</option>)}
              </select>
            </Field>
          </div>
          <div className="mt-4"><Field label="Slug">
            <span className="grid grid-cols-[auto_minmax(0,1fr)] overflow-hidden rounded-md border border-line bg-white">
              <span className="flex h-10 items-center border-r border-line bg-shell px-3 font-mono text-xs text-slate-500">/wiki/</span>
              <input className="h-10 min-w-0 px-3 font-mono text-sm outline-none" defaultValue={p?.slug || ""} />
            </span>
          </Field></div>
          <div className="mt-4 grid gap-2 md:grid-cols-2">
            <label className="flex items-center justify-between gap-3 rounded-lg border border-line bg-shell/60 p-3 text-sm font-semibold">In Navigation anzeigen <input type="checkbox" defaultChecked /></label>
            <label className="flex items-center justify-between gap-3 rounded-lg border border-line bg-shell/60 p-3 text-sm font-semibold">Nur intern <input type="checkbox" /></label>
          </div>
          <div className="mt-4 max-w-[10rem]">
            <Field label="Sortierung"><input className="input" type="number" defaultValue="2" /></Field>
          </div>
        </Section>
        <Section>
          <RteMock html={isEdit ? "<h2 style='font-size:20px;font-weight:700;margin-bottom:8px'>Komponenten</h2><p>Die Anwendung besteht aus zwei Workspaces: <code style='background:var(--color-steel-100);padding:1px 6px;border-radius:4px'>apps/api</code> (Fastify + SQLite) und <code style='background:var(--color-steel-100);padding:1px 6px;border-radius:4px'>apps/web</code> (Vite + React).</p><h2 style='font-size:20px;font-weight:700;margin-top:16px;margin-bottom:8px'>Datenmodell</h2><p>Die zentralen Entitäten sind <b>Projekt</b>, <b>Feature</b>, <b>Use Case</b>, <b>Ticket</b>, <b>Aufgabe</b> und <b>Wiki-Seite</b>.</p>" : "<p style='color:#94a3b8'>Wiki-Inhalt…</p>"} minHeight="20rem" />
        </Section>
      </div>
    </LiveModalShell>
  );
}

// ───── Modal Manager ─────
function ModalManager() {
  const { modal } = useNav();
  if (!modal) return null;
  if (modal.kind === "project-form") return <LiveProjectForm />;
  if (modal.kind === "feature-form") return <LiveFeatureForm />;
  if (modal.kind === "ticket-form") return <LiveTicketForm />;
  if (modal.kind === "event-form") return <LiveEventForm />;
  if (modal.kind === "wiki-form") return <LiveWikiForm />;
  return null;
}

Object.assign(window, { LiveFeatureForm, LiveTicketForm, LiveEventForm, LiveWikiForm, ModalManager });
