// Live page components — each returns just the content (LiveShell wraps it).
// They read from window.MOCK and use useNav() for navigation + modal opening.

// ───── Projects ─────
function LiveProjectsPage() {
  const { navigate, openModal } = useNav();
  const [viewMode, setViewMode] = React.useState("board");
  const [search, setSearch] = React.useState("");
  const [statusFilter, setStatusFilter] = React.useState("all");
  const projects = MOCK.projects;
  const visible = projects.filter((p) => (statusFilter === "all" || p.status === statusFilter) && (!search.trim() || p.name.toLowerCase().includes(search.toLowerCase()) || (p.desc || "").toLowerCase().includes(search.toLowerCase())));
  const statusOpts = [
    { value: "active", label: "Aktiv", count: projects.filter((p) => p.status === "active").length },
    { value: "on_hold", label: "Pausiert", count: projects.filter((p) => p.status === "on_hold").length },
    { value: "completed", label: "Abgeschlossen", count: projects.filter((p) => p.status === "completed").length },
    { value: "archived", label: "Archiviert", count: projects.filter((p) => p.status === "archived").length }
  ];
  const cols = [
    { value: "active", label: "Aktiv" }, { value: "on_hold", label: "Pausiert" }, { value: "completed", label: "Abgeschlossen" }, { value: "archived", label: "Archiviert" }
  ];

  return (
    <>
      <PageHeader title="Projekte" subtitle={`${projects.length} Einträge`} />
      <LiveListBoardChrome viewMode={viewMode} setViewMode={setViewMode} search={search} setSearch={setSearch} addLabel="Neues Projekt"
        onAdd={() => navigate("/projects/new")}
        filters={<LiveFilterChips value={statusFilter} onChange={setStatusFilter} options={statusOpts} allCount={projects.length} />} />
      {viewMode === "list" ? (
        <div className="grid gap-3">
          {visible.map((p) => (
            <article key={p.id} className="card flex items-stretch overflow-hidden hover:border-steel-600 transition cursor-pointer" onClick={() => navigate(`/projects/${p.id}`)}>
              <div style={{ background: p.color, width: 4 }}></div>
              <div className="flex flex-1 items-center gap-4 p-4">
                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl text-white" style={{ background: p.color }}><Icon name="folder-open" size={20} /></span>
                <div className="min-w-0 flex-1">
                  <h3 className="text-sm font-semibold text-ink">{p.name}</h3>
                  <p className="text-xs text-slate-600 truncate">{p.desc}</p>
                </div>
                <div className="flex items-center gap-2">
                  <Pill tone={p.statusTone}>{p.statusLabel}</Pill>
                  {p.tags[0] ? <Badge color={p.tags[0].color}>{p.tags[0].name}</Badge> : null}
                </div>
                <span className="text-xs font-semibold text-slate-500 w-20 text-right">{p.openCount} offen</span>
                <div className="flex gap-1" onClick={(e) => e.stopPropagation()}>
                  <button className="btn btn-ghost btn-icon" onClick={() => navigate(`/projects/${p.id}`)} title="Bearbeiten"><Icon name="edit-3" size={18} /></button>
                  <button className="btn btn-ghost btn-icon"><Icon name="trash-2" size={18} /></button>
                </div>
              </div>
            </article>
          ))}
        </div>
      ) : (
        <div className="grid grid-flow-col auto-cols-[minmax(17rem,1fr)] gap-4 overflow-x-auto pb-2">
          {cols.map((col) => {
            const items = visible.filter((p) => p.status === col.value);
            return (
              <section key={col.value} className="grid min-h-[260px] content-start gap-3 rounded-lg border border-line p-3" style={{ background: "rgba(244,247,250,0.6)" }}>
                <header className="flex items-center justify-between gap-3">
                  <h2 className="truncate text-sm font-semibold text-ink">{col.label}</h2>
                  <div className="flex items-center gap-2">
                    <span className="rounded-full bg-white px-2 py-1 text-xs font-semibold text-slate-600 shadow-sm">{items.length}</span>
                    <button className="btn btn-ghost btn-icon" style={{ background: "#fff", border: "1px solid var(--color-line)" }} onClick={() => navigate("/projects/new")}><Icon name="plus" size={18} /></button>
                  </div>
                </header>
                {items.map((p) => {
                  const progress = p.total > 0 ? Math.round((p.done / p.total) * 100) : 0;
                  return (
                    <article key={p.id} className="card overflow-hidden hover:shadow-panel transition cursor-pointer" onClick={() => navigate(`/projects/${p.id}`)}>
                      <div style={{ background: p.color, height: 4 }}></div>
                      <div className="p-4 grid gap-3">
                        <div className="flex items-start gap-3">
                          <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl text-white shadow-sm" style={{ background: p.color }}><Icon name="folder-open" size={20} /></span>
                          <div className="min-w-0">
                            <h2 className="text-base font-semibold text-ink leading-tight">{p.name}</h2>
                            <p className="mt-1 font-mono text-xs uppercase text-slate-500">{p.code}</p>
                          </div>
                        </div>
                        <div className="flex flex-wrap items-center gap-2">
                          <Pill tone={p.statusTone}>{p.statusLabel}</Pill>
                          {p.tags?.map((t) => <Badge key={t.name} color={t.color}>{t.name}</Badge>)}
                        </div>
                        {p.desc ? <p className="text-sm text-slate-600 line-clamp-3">{p.desc}</p> : null}
                        <div className="grid gap-2 border-t border-line pt-3">
                          {p.total > 0 ? <Progress value={progress} color={p.color} label={`${p.done} / ${p.total} erledigt`} /> : null}
                          <span className="justify-self-end text-xs font-semibold text-slate-500">{p.openCount} offen</span>
                        </div>
                      </div>
                    </article>
                  );
                })}
              </section>
            );
          })}
        </div>
      )}
    </>
  );
}

// ───── Project Detail (== ProjectForm-as-page) ─────
// Mirrors apps/web/src/pages/ProjectDetailPage.tsx exactly:
//   <ProjectForm variant="page" project={...} />
// Both /projects/:id (edit) and /projects/new (create) route here.
// 10 Tabs: Details, Meilensteine, Features, Aufgaben, Tickets, Kommentare,
// Notizen, Dateien, Backlog (alle) + Import (nur Edit).
function LiveProjectDetailPage({ id }) {
  const { navigate, openModal } = useNav();
  const isEdit = id !== undefined && id !== null;
  const project = isEdit ? MOCK.projects.find((p) => p.id === id) : null;
  const [activeTab, setActiveTab] = React.useState("details");

  if (isEdit && !project) {
    return <div className="rounded-lg border border-line bg-white p-8 text-center text-sm text-slate-600">Projekt nicht gefunden</div>;
  }

  const tabs = [
    { value: "details",     label: "Details" },
    { value: "milestones",  label: "Meilensteine", count: project ? (MOCK.milestones[project.id] || []).length : 0 },
    { value: "features",    label: "Features",     count: project ? (MOCK.projectFeatures[project.id] || []).length : 0 },
    { value: "tasks",       label: "Aufgaben",     count: project ? (MOCK.tasks[project.id] || []).length : 0 },
    { value: "tickets",     label: "Tickets",      count: project ? MOCK.tickets.filter((t) => t.projectId === project.id).length : 0 },
    { value: "comments",    label: "Kommentare",   count: project ? 4 : 0 },
    { value: "notes",       label: "Notizen",      count: project ? 2 : 0 },
    { value: "attachments", label: "Dateien",      count: project ? 6 : 0 },
    { value: "backlog",     label: "Backlog",      count: project ? (MOCK.backlog[project.id] || []).length : 0 },
    { value: "import",      label: "Import" }
  ].filter((t) => isEdit || t.value !== "import");

  return (
    <LivePageFormShell
      icon="folder-kanban"
      breadcrumb={["Projekte", isEdit ? project.name : "Neues Projekt"]}
      title={isEdit ? "Projekt bearbeiten" : "Projekt anlegen"}
      subtitle={isEdit ? `Zuletzt aktualisiert am ${project.updatedAt}` : "Stammdaten, Status und Beziehungen festlegen."}
      submitLabel={isEdit ? "Speichern" : "Projekt anlegen"}
      footerStart={isEdit ? (
        <button className="btn btn-ghost text-crimson"><Icon name="trash-2" size={17} />Löschen</button>
      ) : null}
      onClose={() => navigate("/projects")}
    >
      <LiveTabBar tabs={tabs} active={activeTab} onChange={setActiveTab} />
      <div className="grid gap-5 bg-shell p-5">
        {activeTab === "details"     ? <ProjectFormDetails     project={project} /> : null}
        {activeTab === "milestones"  ? <ProjectFormMilestones  project={project} isEdit={isEdit} /> : null}
        {activeTab === "features"    ? <ProjectFormFeatures    project={project} openModal={openModal} /> : null}
        {activeTab === "tasks"       ? <ProjectFormTasks       project={project} /> : null}
        {activeTab === "tickets"     ? <ProjectFormTickets     project={project} openModal={openModal} /> : null}
        {activeTab === "backlog"     ? <ProjectFormBacklog     project={project} /> : null}
        {activeTab === "comments"    ? <ProjectFormComments    /> : null}
        {activeTab === "notes"       ? <ProjectFormNotes       /> : null}
        {activeTab === "attachments" ? <ProjectFormAttachments /> : null}
        {activeTab === "import"      ? <ProjectFormImport      /> : null}
      </div>
    </LivePageFormShell>
  );
}

// ───── Tickets ─────
function LiveTicketsPage() {
  const { openModal } = useNav();
  const [viewMode, setViewMode] = React.useState("board");
  const [search, setSearch] = React.useState("");
  const tickets = MOCK.tickets.filter((t) => !search.trim() || t.title.toLowerCase().includes(search.toLowerCase()));
  const cols = [
    { value: "open", label: "Offen" }, { value: "in_progress", label: "In Arbeit" },
    { value: "in_review", label: "In Prüfung" }, { value: "resolved", label: "Gelöst" }, { value: "closed", label: "Geschlossen" }
  ];
  return (
    <>
      <PageHeader title="Tickets" subtitle={`${MOCK.tickets.length} Einträge`} />
      <LiveListBoardChrome viewMode={viewMode} setViewMode={setViewMode} search={search} setSearch={setSearch} addLabel="Neues Ticket"
        onAdd={() => openModal({ kind: "ticket-form", mode: "create" })} />
      {viewMode === "list" ? (
        <div className="grid gap-3">
          {tickets.map((r) => (
            <article key={r.id} className="card flex items-stretch overflow-hidden hover:border-steel-600 transition cursor-pointer" onClick={() => openModal({ kind: "ticket-form", mode: "edit", entity: r })}>
              <div style={{ background: r.priorityColor, width: 4 }}></div>
              <div className="flex flex-1 items-center gap-4 p-4">
                <span className="block h-3 w-3 rounded-full" style={{ background: `var(--color-${r.statusTone === "steel" ? "steel-400" : r.statusTone})` }}></span>
                <div className="min-w-0 flex-1">
                  <h3 className="text-sm font-semibold text-ink">TICKET-{r.id} · {r.title}</h3>
                  <p className="text-xs text-slate-600 truncate">{r.desc}</p>
                </div>
                <div className="flex items-center gap-2">
                  <Pill tone={r.statusTone}>{r.statusLabel}</Pill>
                  <Badge tone={r.typeTone}>{r.typeLabel}</Badge>
                  <Badge tone={r.priorityTone}>{r.priorityLabel}</Badge>
                </div>
                <span className={`inline-flex w-24 items-center gap-1 text-xs font-semibold ${r.overdue ? "text-crimson" : "text-slate-500"}`}>
                  <Icon name="calendar-clock" size={14} />{r.due}
                </span>
                <span className="flex h-9 w-9 items-center justify-center rounded-full bg-steel-100 text-steel-700 text-xs font-bold">{r.assignee}</span>
              </div>
            </article>
          ))}
        </div>
      ) : (
        <div className="grid grid-flow-col auto-cols-[minmax(17rem,1fr)] gap-4 overflow-x-auto pb-2">
          {cols.map((col) => {
            const items = tickets.filter((t) => t.status === col.value);
            return (
              <section key={col.value} className="grid min-h-[260px] content-start gap-3 rounded-lg border border-line p-3" style={{ background: "rgba(244,247,250,0.6)" }}>
                <header className="flex items-center justify-between gap-3">
                  <h2 className="truncate text-sm font-semibold text-ink">{col.label}</h2>
                  <div className="flex items-center gap-2">
                    <span className="rounded-full bg-white px-2 py-1 text-xs font-semibold text-slate-600 shadow-sm">{items.length}</span>
                    <button className="btn btn-ghost btn-icon" style={{ background: "#fff", border: "1px solid var(--color-line)" }} onClick={() => openModal({ kind: "ticket-form", mode: "create" })}><Icon name="plus" size={18} /></button>
                  </div>
                </header>
                {items.map((t) => (
                  <article key={t.id} className="card overflow-hidden cursor-pointer hover:shadow-panel transition" onClick={() => openModal({ kind: "ticket-form", mode: "edit", entity: t })}>
                    <div style={{ background: t.priorityColor, height: 4 }}></div>
                    <div className="p-4 grid gap-2">
                      <h3 className="text-sm font-semibold text-ink line-clamp-2">{t.title}</h3>
                      <div className="flex flex-wrap items-center gap-2">
                        <Pill tone={t.statusTone}>{t.statusLabel}</Pill>
                        <Badge tone={t.typeTone}>{t.typeLabel}</Badge>
                      </div>
                      <div className="flex items-center justify-between gap-3 border-t border-line pt-2 text-xs text-slate-600">
                        <span className="inline-flex items-center gap-1"><Icon name="calendar-clock" size={14} />{t.due}</span>
                        <span className="flex h-7 w-7 items-center justify-center rounded-full bg-steel-100 text-steel-700 text-[11px] font-bold">{t.assignee}</span>
                      </div>
                    </div>
                  </article>
                ))}
              </section>
            );
          })}
        </div>
      )}
    </>
  );
}

Object.assign(window, { LiveProjectsPage, LiveProjectDetailPage, LiveTicketsPage });
