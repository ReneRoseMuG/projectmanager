// Final live pages: Calendar + Settings.

// ───── Calendar ─────
function LiveCalendarPage() {
  const { openModal } = useNav();
  const days = ["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"];
  const cells = [];
  let day = 1;
  for (let i = 0; i < 35; i++) {
    if (i < 4 || day > 31) {
      cells.push({ day: i < 4 ? 27 + i : day - 31, muted: true });
      if (i >= 4) day++;
    } else {
      cells.push({ day });
      day++;
    }
  }
  const today = 13;
  return (
    <>
      <PageHeader title="Kalender" subtitle={`${Object.values(MOCK.calendarEvents).flat().length} Termine`} action={
        <button className="btn btn-primary" onClick={() => openModal({ kind: "event-form", mode: "create" })}><Icon name="plus" size={17} />Neuer Termin</button>
      } />
      <div className="card overflow-hidden">
        <div className="flex items-center justify-between border-b border-line p-4">
          <div className="flex items-center gap-2">
            <button className="btn btn-secondary btn-icon"><Icon name="chevron-left" size={17} /></button>
            <button className="btn btn-secondary btn-icon"><Icon name="chevron-right" size={17} /></button>
            <button className="btn btn-secondary">Heute</button>
          </div>
          <h2 className="text-xl font-bold text-ink">Mai 2026</h2>
          <div className="inline-flex items-center gap-1 rounded-md border border-line bg-white p-1">
            <button className="h-8 px-3 rounded-sm bg-steel-700 text-white text-xs font-semibold">Monat</button>
            <button className="h-8 px-3 rounded-sm text-slate-600 text-xs font-semibold">Woche</button>
            <button className="h-8 px-3 rounded-sm text-slate-600 text-xs font-semibold">Tag</button>
          </div>
        </div>
        <div className="grid grid-cols-7 border-b border-line bg-shell">
          {days.map((d) => <div key={d} className="px-3 py-2 text-xs font-bold uppercase text-slate-500">{d}</div>)}
        </div>
        <div className="grid grid-cols-7" style={{ gridAutoRows: "minmax(100px, 1fr)" }}>
          {cells.map((c, i) => {
            const isToday = !c.muted && c.day === today;
            const evs = !c.muted ? MOCK.calendarEvents[c.day] || [] : [];
            return (
              <button key={i} onClick={() => !c.muted && openModal({ kind: "event-form", mode: "create" })} className={`text-left border-r border-b border-line p-2 ${c.muted ? "bg-shell/60" : "bg-white hover:bg-shell"}`}>
                <span className={`inline-flex h-6 w-6 items-center justify-center rounded-full text-xs font-bold ${isToday ? "bg-steel-700 text-white" : c.muted ? "text-slate-400" : "text-slate-700"}`}>{c.day}</span>
                <div className="mt-1 grid gap-1">
                  {evs.map((e, k) => (
                    <span key={k} onClick={(ev) => { ev.stopPropagation(); openModal({ kind: "event-form", mode: "edit", entity: { title: e.text, color: e.color, day: c.day } }); }}
                      className="block truncate rounded px-2 py-0.5 text-[11px] font-semibold text-white hover:opacity-90" style={{ background: e.color }}>{e.text}</span>
                  ))}
                </div>
              </button>
            );
          })}
        </div>
      </div>
      <section className="card p-5">
        <h3 className="text-sm font-bold uppercase tracking-wider text-slate-500 mb-3">Anstehende Termine</h3>
        <ul className="grid gap-2">
          {MOCK.upcoming.map((e, i) => (
            <li key={i} className="flex items-center gap-3 rounded-md border border-line bg-white p-3 cursor-pointer hover:border-steel-600"
              onClick={() => openModal({ kind: "event-form", mode: "edit", entity: { title: e.title, color: e.color } })}>
              <span className="h-9 w-1.5 rounded-full" style={{ background: e.color }}></span>
              <div className="flex-1">
                <p className="text-sm font-semibold text-ink">{e.title}</p>
                <p className="text-xs text-slate-500">{e.date}</p>
              </div>
              <button className="btn btn-ghost btn-icon"><Icon name="edit-3" size={17} /></button>
            </li>
          ))}
        </ul>
      </section>
    </>
  );
}

// ───── Settings · Tags ─────
function LiveSettingsTagsPage() {
  const palette = ["#2E5984", "#D9416A", "#ED8C3A", "#E2BA2C", "#4D9359", "#2F8E96", "#6A40BE", "#C13D9A"];
  const [color, setColor] = React.useState("#2E5984");
  const [name, setName] = React.useState("");
  const [query, setQuery] = React.useState("");
  const tags = MOCK.tags.filter((t) => t.name.toLowerCase().includes(query.toLowerCase()));
  return (
    <div className="card overflow-hidden">
      <header className="px-5 py-5 text-white" style={{ background: "linear-gradient(135deg, var(--color-magenta), rgba(193,61,154,0.75))" }}>
        <div className="flex items-center gap-3">
          <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/12"><Icon name="tags" size={21} /></span>
          <div>
            <h1 className="text-2xl font-bold">Tags verwalten</h1>
            <p className="text-sm text-white/75">{MOCK.tags.length} Tags · genutzt in 9 Projekten, 75 Tasks, 20 Notizen</p>
          </div>
        </div>
      </header>
      <div className="p-5 grid gap-4">
        <section>
          <h2 className="mb-3 text-sm font-bold uppercase text-slate-500">Neuer Tag</h2>
          <div className="grid gap-3 md:grid-cols-[auto_minmax(0,1fr)_auto] md:items-center">
            <span className="h-9 w-9 rounded-full" style={{ background: color, boxShadow: "0 0 0 1px var(--color-line)" }}></span>
            <input className="input" placeholder="Tag-Name" value={name} onChange={(e) => setName(e.target.value)} />
            <button className="btn btn-primary"><Icon name="plus" size={17} />Anlegen</button>
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            {palette.map((s) => (
              <button key={s} onClick={() => setColor(s)} className={`h-9 w-9 rounded-full border-2 ${color === s ? "border-steel-900" : "border-white"}`} style={{ background: s, boxShadow: "0 0 0 1px var(--color-line)" }}></button>
            ))}
          </div>
        </section>
        <section>
          <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
            <h2 className="font-semibold text-ink">Alle Tags · {tags.length} Einträge</h2>
            <div className="flex items-center gap-2">
              <label className="relative">
                <Icon name="search" size={14} style={{ position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)", color: "var(--color-slate-400)" }} />
                <input className="h-9 w-56 rounded-md border border-line pl-8 pr-3 text-sm outline-none" placeholder="Tags suchen" value={query} onChange={(e) => setQuery(e.target.value)} />
              </label>
              <select className="h-9 rounded-md border border-line bg-white px-3 text-sm">
                <option>Verwendung</option><option>Name A-Z</option><option>Neueste</option>
              </select>
            </div>
          </div>
          <div className="grid grid-cols-[auto_minmax(0,1fr)_minmax(9rem,1fr)_7rem_auto] gap-3 border-b border-line pb-2 text-xs font-bold uppercase text-slate-500">
            <span>Farbe</span><span>Name</span><span>Verwendungen</span><span>Status</span><span className="text-right">Aktionen</span>
          </div>
          {tags.map((t) => (
            <div key={t.id} className="grid grid-cols-[auto_minmax(0,1fr)_minmax(9rem,1fr)_7rem_auto] items-center gap-3 border-b border-line py-3 text-sm">
              <span className="h-6 w-6 rounded-full" style={{ background: t.color, boxShadow: "0 0 0 1px var(--color-line)" }}></span>
              <span className="truncate font-semibold text-ink">{t.name}</span>
              <span className="text-slate-500">{t.usage}</span>
              <span className={`rounded-full px-2 py-1 text-center text-xs font-semibold ${t.usage === "verwaist" ? "border border-line bg-shell text-slate-500" : "bg-fern/10 text-fern"}`}>
                {t.usage === "verwaist" ? "verwaist" : "in Nutzung"}
              </span>
              <div className="flex justify-end gap-1">
                <button className="btn btn-ghost btn-icon"><Icon name="pencil" size={17} /></button>
                <button className="btn btn-ghost btn-icon"><Icon name="git-merge" size={17} /></button>
                <button className="btn btn-ghost btn-icon text-crimson"><Icon name="trash-2" size={17} /></button>
              </div>
            </div>
          ))}
        </section>
      </div>
    </div>
  );
}

// ───── Settings · Sicherung ─────
function LiveSettingsBackupPage() {
  return (
    <>
      <PageHeader title="Sicherung" subtitle="Google Drive" action={
        <div className="flex gap-2">
          <button className="btn btn-primary"><Icon name="cloud-upload" size={17} />Sichern</button>
          <button className="btn btn-secondary"><Icon name="refresh-cw" size={17} />Aktualisieren</button>
        </div>
      } />
      <section className="section-card p-4">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2"><Icon name="folder-cog" size={18} /><h2 className="text-base font-semibold">Google-Drive-Zielordner</h2></div>
          <Badge tone="fern">bereit</Badge>
        </div>
        <div className="grid gap-3">
          <div className="flex gap-2">
            <input className="input flex-1 input-mono" defaultValue="https://drive.google.com/drive/folders/1A2bCd3EfGh4iJkLmN5oP" />
            <button className="btn btn-secondary"><Icon name="folder-cog" size={17} />Speichern</button>
          </div>
          <div className="flex flex-wrap gap-3 text-xs text-slate-500">
            <span>Quelle: UI</span>
            <span className="font-mono">ID: 1A2bCd3EfGh4iJkLmN5oP</span>
            <span>OAuth: konfiguriert</span>
          </div>
        </div>
      </section>
      <section className="section-card p-4">
        <div className="mb-2 flex items-center gap-2"><Icon name="database-backup" size={18} /><h2 className="text-base font-semibold">Letzte Sicherung</h2></div>
        <div className="grid gap-2 text-sm text-slate-600 md:grid-cols-3">
          <span><Icon name="file-archive" size={14} className="inline mr-1" />taskmanager-2026-05-13-0930.zip</span>
          <span>42.17 MB</span>
          <span className="font-mono text-xs">dump-9f8a3c</span>
        </div>
      </section>
      <section className="section-card p-4">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2"><Icon name="cloud-download" size={18} /><h2 className="text-base font-semibold">Aktualisierung</h2></div>
          <Badge tone="fern">ready</Badge>
        </div>
        <div className="grid gap-2 text-sm text-slate-600 md:grid-cols-3">
          <span>taskmanager-2026-05-12-0915.zip</span><span>17 Tabellen</span><span>284 Dateien</span>
        </div>
        <div className="mt-4 grid gap-2">
          <p className="rounded-md p-2 text-sm" style={{ background: "rgba(226,186,44,0.1)", border: "1px solid rgba(226,186,44,0.25)", color: "var(--color-mustard-dark)" }}>
            Hinweis: Quell-Dump enthält 3 verwaiste Anhänge.
          </p>
        </div>
        <div className="mt-4 grid gap-2">
          <div className="flex items-center gap-2 text-sm font-semibold text-crimson"><Icon name="alert-triangle" size={16} />Destruktiver Import</div>
          <p className="select-all rounded-md border border-line bg-shell p-2 text-xs text-slate-600 font-mono">IMPORT-2026-05-12-OVERWRITE</p>
          <div className="flex gap-2">
            <input className="input flex-1 input-mono" placeholder="Bestätigungs-Phrase eingeben" />
            <button className="btn btn-danger"><Icon name="cloud-download" size={17} />Importieren</button>
          </div>
        </div>
      </section>
    </>
  );
}

// ───── Settings · Testdaten ─────
function LiveSettingsSeedDataPage() {
  return (
    <>
      <PageHeader title="Testdaten" subtitle="Admin" action={<button className="btn btn-secondary"><Icon name="refresh-cw" size={17} />Aktualisieren</button>} />
      <section className="section-card p-4">
        <div className="mb-4 flex items-center gap-2"><Icon name="database-zap" size={18} /><h2 className="text-base font-semibold">Neuer Seed-Run</h2></div>
        <div className="flex gap-2">
          <input className="input flex-1" placeholder="Bezeichnung" />
          <button className="btn btn-primary"><Icon name="database-zap" size={17} />Erzeugen</button>
        </div>
      </section>
      <section className="section-card">
        <div className="flex items-center justify-between gap-3 border-b border-line p-4">
          <h2 className="text-base font-semibold">Seed-Runs</h2>
          <Badge tone="mute">{MOCK.seedRuns.length}</Badge>
        </div>
        <div className="divide-y divide-line">
          {MOCK.seedRuns.map((r) => (
            <article key={r.id} className="grid gap-3 p-4 md:grid-cols-[minmax(0,1fr)_auto] md:items-center">
              <div>
                <div className="flex items-center gap-2"><h3 className="text-sm font-semibold text-ink">{r.label}</h3><Badge tone="mustard">Testdaten</Badge></div>
                <p className="mt-1 break-all font-mono text-xs text-slate-500">{r.id}</p>
                <p className="mt-1 text-xs text-slate-500">{r.date}</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  <Badge tone="steel">{r.projects} Projekte</Badge>
                  <Badge tone="teal">{r.tasks} Aufgaben</Badge>
                  <Badge tone="violet">{r.files} Dateien</Badge>
                  <Badge tone="mute">{r.total} Einträge</Badge>
                </div>
              </div>
              <button className="btn btn-danger"><Icon name="trash-2" size={17} />Löschen</button>
            </article>
          ))}
        </div>
      </section>
    </>
  );
}

Object.assign(window, { LiveCalendarPage, LiveSettingsTagsPage, LiveSettingsBackupPage, LiveSettingsSeedDataPage });
