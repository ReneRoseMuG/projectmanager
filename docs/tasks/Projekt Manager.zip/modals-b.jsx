// More modal screens.

// ───── Modal 6: Feature — Projekte Tab ─────
window.FeatureFormProjectsModal = function () {
  useLucide();
  const tabs = [
    { value: "details", label: "Details" },
    { value: "useCases", label: "Use Cases", count: 5 },
    { value: "tasks", label: "Aufgaben" },
    { value: "tickets", label: "Tickets" },
    { value: "projects", label: "Projekte", count: 2 },
    { value: "comments", label: "Kommentare", count: 3 },
    { value: "attachments", label: "Dateien", count: 4 }
  ];
  return (
    <ModalScene active="/features" modal={
      <ModalShell icon="book-open" breadcrumb={["Features", "Bearbeiten"]} title="Feature bearbeiten" subtitle="Verknüpfte Projekte." submitLabel="Speichern" footerStart={<Btn icon="trash-2" variant="ghost" className="text-crimson">Löschen</Btn>}>
        <TabBar tabs={tabs} active="projects" />
        <ModalBody>
          <Section title="Verknüpfte Projekte" action={<Btn variant="primary" icon="link">Projekt verknüpfen</Btn>}>
            <div className="grid gap-3 md:grid-cols-2">
              {[
                { name: "Apollo CRM", color: "#2E5984", status: "Aktiv", tone: "fern", open: 7 },
                { name: "Helios Reporting", color: "#2F8E96", status: "Aktiv", tone: "fern", open: 3 }
              ].map((p) => (
                <article key={p.name} className="card overflow-hidden">
                  <div style={{ background: p.color, height: 4 }}></div>
                  <div className="p-4 grid gap-3">
                    <div className="flex items-start gap-3">
                      <span className="flex h-12 w-12 items-center justify-center rounded-xl text-white" style={{ background: p.color }}><Icon name="folder-open" size={20} /></span>
                      <div className="min-w-0">
                        <h3 className="text-base font-semibold text-ink">{p.name}</h3>
                        <Pill tone={p.tone}>{p.status}</Pill>
                      </div>
                    </div>
                    <div className="flex items-center justify-between border-t border-line pt-2 text-xs">
                      <span className="text-slate-500">{p.open} offene Aufgaben</span>
                      <Btn icon="unlink" variant="ghost">Entfernen</Btn>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </Section>
        </ModalBody>
      </ModalShell>
    } />
  );
};

// ───── Modal 7: Ticket anlegen ─────
window.TicketFormModal = function () {
  useLucide();
  return (
    <ModalScene active="/tickets" modal={
      <ModalShell icon="bug" breadcrumb={["Tickets", "Neu"]} title="Ticket anlegen" subtitle="Status, Priorität und Kontext für die Nachverfolgung." submitLabel="Ticket anlegen">
        <ModalBody>
          <Section title="Basisdaten">
            <Field label="Titel" required><input className="input" defaultValue="Login schlägt nach Passwort-Reset fehl" /></Field>
            <div className="mt-4"><Field label="Beschreibung">
              <div className="rte">
                <div className="rte-toolbar">{["B","I","U","S"].map((t) => <button key={t} className="rte-btn">{t}</button>)}<span className="mx-1 w-px bg-line"></span><button className="rte-btn"><Icon name="list" size={14}/></button><button className="rte-btn"><Icon name="link" size={14}/></button><button className="rte-btn"><Icon name="code" size={14}/></button></div>
                <div className="rte-body">Nach Klick auf den Magic-Link aus der Reset-Mail landet der Nutzer im Login-Screen, das Token wird aber nicht akzeptiert (401 vom /auth/verify). Reproduzierbar mit Edge 122 und Safari 17.</div>
              </div>
            </Field></div>
          </Section>
          <Section title="Typ & Priorität">
            <div className="grid gap-4 md:grid-cols-2">
              <Field label="Typ">
                <RadioList value="bug" options={[
                  { value: "bug", label: "Bug", activeColor: "crimson" },
                  { value: "improvement", label: "Verbesserung", activeColor: "fern" },
                  { value: "question", label: "Frage", activeColor: "violet" },
                  { value: "task", label: "Aufgabe", activeColor: "tangerine" }
                ]} />
              </Field>
              <Field label="Priorität">
                <RadioList value="urgent" options={[
                  { value: "low", label: "Niedrig", activeColor: "fern" },
                  { value: "medium", label: "Mittel", activeColor: "violet" },
                  { value: "high", label: "Hoch", activeColor: "tangerine" },
                  { value: "urgent", label: "Dringend", activeColor: "crimson" }
                ]} />
              </Field>
            </div>
          </Section>
          <Section title="Status & Lösung">
            <Field label="Status">
              <RadioList value="open" options={[
                { value: "open", label: "Offen", activeColor: "violet" },
                { value: "in_progress", label: "In Arbeit", activeColor: "tangerine" },
                { value: "in_review", label: "In Prüfung", activeColor: "tangerine" },
                { value: "resolved", label: "Gelöst", activeColor: "fern" },
                { value: "closed", label: "Geschlossen", activeColor: "violet" }
              ]} />
            </Field>
          </Section>
          <Section title="Zuweisung">
            <div className="grid gap-4 md:grid-cols-3">
              <Field label="Zuständig">
                <span className="relative block">
                  <Icon name="user-round" size={16} style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", color: "var(--color-slate-400)" }} />
                  <input className="input pl-9" defaultValue="JS · J. Schreiber" />
                </span>
              </Field>
              <Field label="Reporter">
                <span className="relative block">
                  <Icon name="user-round" size={16} style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", color: "var(--color-slate-400)" }} />
                  <input className="input pl-9" defaultValue="MR · M. Renner" />
                </span>
              </Field>
              <Field label="Fällig"><input className="input" type="date" defaultValue="2026-05-15" /></Field>
            </div>
          </Section>
          <Section title="Details">
            <div className="grid gap-4 md:grid-cols-2">
              <Field label="Umgebung"><input className="input" defaultValue="Production v1.4.2, Edge 122 / Safari 17" /></Field>
              <Field label="Betroffene Version"><input className="input input-mono" defaultValue="1.4.2" /></Field>
            </div>
          </Section>
          <Section title="Tags">
            <div className="flex flex-wrap gap-2">
              <Badge color="#D9416A">Hotfix ✕</Badge>
              <Badge color="#2E5984">Backend ✕</Badge>
              <button className="badge badge-mute" style={{ borderStyle: "dashed" }}>+ Tag</button>
            </div>
          </Section>
        </ModalBody>
      </ModalShell>
    } />
  );
};

// ───── Modal 8: Termin anlegen ─────
window.EventFormModal = function () {
  useLucide();
  return (
    <ModalScene active="/calendar" modal={
      <ModalShell icon="calendar-clock" breadcrumb={["Kalender", "Neuer Termin"]} title="Termin anlegen" submitLabel="Termin anlegen" width={820}>
        <ModalBody>
          <Section title="Stammdaten">
            <Field label="Titel" required><input className="input" defaultValue="Sprint Review Apollo" /></Field>
            <div className="mt-4"><Field label="Beschreibung">
              <div className="rte" style={{ minHeight: "7rem" }}>
                <div className="rte-toolbar">{["B","I","U"].map((t) => <button key={t} className="rte-btn">{t}</button>)}<button className="rte-btn"><Icon name="list" size={14}/></button></div>
                <div className="rte-body">Demo des Reporting-Dashboards (Drill-down in Tickets). Stakeholder: Vertrieb, Operations, GL.</div>
              </div>
            </Field></div>
          </Section>
          <Section title="Zeitraum">
            <label className="mb-3 flex items-center gap-2 text-sm font-medium">
              <input type="checkbox" /> Ganztägig
            </label>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Start"><input className="input" type="datetime-local" defaultValue="2026-05-18T10:00" /></Field>
              <Field label="Ende"><input className="input" type="datetime-local" defaultValue="2026-05-18T11:30" /></Field>
            </div>
          </Section>
          <Section title="Zuordnung">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Projekt">
                <select className="input"><option>Apollo CRM</option><option>Helios Reporting</option><option>Orion Onboarding</option></select>
              </Field>
              <Field label="Aufgabe">
                <select className="input"><option>Stakeholder-Interviews Phase 2</option><option>Datenmapping CRM → SAP klären</option></select>
              </Field>
            </div>
          </Section>
          <Section title="Farbe">
            <ColorSwatches selected="#2E5984" swatches={["#2E5984", "#2F8E96", "#ED8C3A", "#E2BA2C", "#4D9359", "#6B92BD", "#6A40BE", "#C13D9A"]} />
          </Section>
        </ModalBody>
      </ModalShell>
    } />
  );
};

// ───── Modal 9: Wiki-Seite anlegen/bearbeiten ─────
window.WikiFormModal = function () {
  useLucide();
  return (
    <ModalScene active="/wiki" modal={
      <ModalShell headerKind="teal" icon="library" breadcrumb={["Wiki", "Einführung", "Bearbeiten"]} title="Architektur-Überblick" subtitle="Inhalte strukturieren, Slug pflegen und veröffentlichen." submitLabel="Veröffentlichen" footerStart={<Btn icon="eye">Vorschau</Btn>} width={1000}>
        <ModalBody>
          <Section>
            <div className="grid gap-4 md:grid-cols-2">
              <Field label="Titel"><input className="input" defaultValue="Architektur-Überblick" /></Field>
              <Field label="Kategorie">
                <select className="input"><option>einführung</option><option>entwicklung</option><option>betrieb</option><option>Root-Seite</option></select>
              </Field>
            </div>
            <div className="mt-4"><Field label="Slug">
              <span className="grid grid-cols-[auto_minmax(0,1fr)] overflow-hidden rounded-md border border-line bg-white">
                <span className="flex h-10 items-center border-r border-line bg-shell px-3 font-mono text-xs text-slate-500">/wiki/</span>
                <input className="h-10 min-w-0 px-3 font-mono text-sm outline-none" defaultValue="einführung/architektur" />
              </span>
            </Field></div>
            <div className="mt-4 grid gap-2 md:grid-cols-2">
              <label className="flex items-center justify-between gap-3 rounded-lg border border-line bg-shell/60 p-3 text-sm font-semibold">
                In Navigation anzeigen
                <input type="checkbox" defaultChecked />
              </label>
              <label className="flex items-center justify-between gap-3 rounded-lg border border-line bg-shell/60 p-3 text-sm font-semibold">
                Nur intern
                <input type="checkbox" />
              </label>
            </div>
            <div className="mt-4 max-w-[10rem]">
              <Field label="Sortierung"><input className="input" type="number" defaultValue="2" /></Field>
            </div>
          </Section>
          <Section>
            <div className="rte" style={{ minHeight: 280 }}>
              <div className="rte-toolbar">{["B","I","U","S"].map((t) => <button key={t} className="rte-btn">{t}</button>)}<span className="mx-1 w-px bg-line"></span>{["H1","H2","H3"].map((t) => <button key={t} className="rte-btn">{t}</button>)}<span className="mx-1 w-px bg-line"></span><button className="rte-btn"><Icon name="list" size={14}/></button><button className="rte-btn"><Icon name="list-ordered" size={14}/></button><button className="rte-btn"><Icon name="quote" size={14}/></button><button className="rte-btn"><Icon name="code" size={14}/></button><button className="rte-btn"><Icon name="link" size={14}/></button><button className="rte-btn"><Icon name="image" size={14}/></button></div>
              <div className="rte-body">
                <h2 style={{ fontSize: 20, fontWeight: 700, marginBottom: 8 }}>Komponenten</h2>
                <p>Die Anwendung besteht aus zwei Workspaces: <code style={{ background: "var(--color-steel-100)", padding: "1px 6px", borderRadius: 4 }}>apps/api</code> (Fastify + SQLite) und <code style={{ background: "var(--color-steel-100)", padding: "1px 6px", borderRadius: 4 }}>apps/web</code> (Vite + React).</p>
                <h2 style={{ fontSize: 20, fontWeight: 700, marginTop: 16, marginBottom: 8 }}>Datenmodell</h2>
                <p>Die zentralen Entitäten sind <b>Projekt</b>, <b>Feature</b>, <b>Use Case</b>, <b>Ticket</b>, <b>Aufgabe</b> und <b>Wiki-Seite</b>. Relationen werden über typed-Junctions abgebildet.</p>
                <ul style={{ listStyle: "disc", paddingLeft: 22, margin: "8px 0" }}>
                  <li>Projekte haben N Features</li>
                  <li>Features haben N Use Cases</li>
                  <li>Tickets können einem Projekt <i>oder</i> Feature gehören</li>
                </ul>
              </div>
            </div>
          </Section>
        </ModalBody>
      </ModalShell>
    } />
  );
};
