// Mock data — shared across the live prototype.

window.MOCK = {
  projects: [
    { id: 1, name: "Apollo CRM", code: "AC", status: "active", statusLabel: "Aktiv", statusTone: "fern", color: "#2E5984", desc: "Konsolidierung der Kundendaten und Migration des Vertriebs-Funnels in das neue CRM. Steering Committee jeden 2. Mittwoch.", tags: [{ name: "Roadmap", color: "#4D9359" }, { name: "Backend", color: "#2E5984" }], done: 18, total: 32, openCount: 7, updatedAt: "12. Mai 2026", startDate: "2026-02-01", dueDate: "2026-09-30" },
    { id: 2, name: "Helios Reporting", code: "HR", status: "active", statusLabel: "Aktiv", statusTone: "fern", color: "#2F8E96", desc: "Monatliche Vertriebsberichte automatisieren – Excel-Export ablösen.", tags: [{ name: "Daten", color: "#2F8E96" }], done: 9, total: 14, openCount: 3, updatedAt: "10. Mai 2026" },
    { id: 3, name: "Orion Onboarding", code: "OO", status: "on_hold", statusLabel: "Pausiert", statusTone: "tangerine", color: "#ED8C3A", desc: "Neuer Self-Service-Flow für Onboarding bei Bestandskunden.", tags: [{ name: "UX", color: "#C13D9A" }], done: 4, total: 22, openCount: 8, updatedAt: "02. Mai 2026" },
    { id: 4, name: "Lumen Mobile", code: "LM", status: "on_hold", statusLabel: "Pausiert", statusTone: "tangerine", color: "#D9416A", desc: "Mobile-App MVP wartet auf Freigabe vom Steering Committee.", tags: [], done: 6, total: 18, openCount: 6, updatedAt: "28. Apr 2026" },
    { id: 5, name: "Atlas Migration", code: "AM", status: "completed", statusLabel: "Abgeschlossen", statusTone: "violet", color: "#6A40BE", desc: "Migration von Legacy-System in die neue Plattform abgeschlossen.", tags: [{ name: "Infra", color: "#1B355C" }], done: 24, total: 24, openCount: 0, updatedAt: "20. Apr 2026" },
    { id: 6, name: "Vega Archiv", code: "VA", status: "archived", statusLabel: "Archiviert", statusTone: "steel", color: "#6B92BD", desc: "Alte Wikis und Dokumente konsolidiert für Auditzwecke.", tags: [], done: 12, total: 12, openCount: 0, updatedAt: "15. Mär 2026" }
  ],
  tickets: [
    { id: 204, title: "Login schlägt nach Passwort-Reset fehl", status: "open", statusLabel: "Offen", statusTone: "steel", type: "bug", typeLabel: "Bug", typeTone: "crimson", priority: "urgent", priorityLabel: "Dringend", priorityTone: "crimson", priorityColor: "#D9416A", due: "Heute", overdue: true, assignee: "JS", reporter: "MR", desc: "Reset-Mail erzeugt Token, aber Login akzeptiert es nicht (401 vom /auth/verify). Reproduzierbar mit Edge 122 und Safari 17.", environment: "Production v1.4.2, Edge 122 / Safari 17", affectedVersion: "1.4.2", projectId: 1 },
    { id: 211, title: "Export-Button im Reporting greift nicht", status: "open", statusLabel: "Offen", statusTone: "steel", type: "bug", typeLabel: "Bug", typeTone: "crimson", priority: "high", priorityLabel: "Hoch", priorityTone: "tangerine", priorityColor: "#ED8C3A", due: "14. Mai", assignee: "MR", reporter: "AK", desc: "Klick auf CSV-Export löst nichts aus, Browser-Konsole zeigt 500.", projectId: 2 },
    { id: 214, title: "Doppelte E-Mail-Validierung", status: "in_progress", statusLabel: "In Arbeit", statusTone: "tangerine", type: "improvement", typeLabel: "Verbesserung", typeTone: "teal", priority: "medium", priorityLabel: "Mittel", priorityTone: "mustard", priorityColor: "#E2BA2C", due: "20. Mai", assignee: "AK", reporter: "JS", desc: "Validierung auch beim Import von externen Listen.", projectId: 1 },
    { id: 215, title: "Suche ignoriert Umlaute", status: "in_progress", statusLabel: "In Arbeit", statusTone: "tangerine", type: "bug", typeLabel: "Bug", typeTone: "crimson", priority: "high", priorityLabel: "Hoch", priorityTone: "tangerine", priorityColor: "#ED8C3A", due: "Morgen", assignee: "JL", reporter: "MR", desc: "„Müller“ und „Mueller“ liefern unterschiedliche Treffer.", projectId: 1 },
    { id: 218, title: "Tooltip-Farbe Accessibility", status: "in_review", statusLabel: "In Prüfung", statusTone: "mustard", type: "improvement", typeLabel: "Verbesserung", typeTone: "teal", priority: "low", priorityLabel: "Niedrig", priorityTone: "steel", priorityColor: "#94B2D1", due: "—", assignee: "SK", reporter: "AK", desc: "Kontrast auf hellem Hintergrund zu schwach.", projectId: 2 },
    { id: 220, title: "Speicherprobleme bei großem Import", status: "resolved", statusLabel: "Gelöst", statusTone: "fern", type: "bug", typeLabel: "Bug", typeTone: "crimson", priority: "urgent", priorityLabel: "Dringend", priorityTone: "crimson", priorityColor: "#D9416A", due: "08. Mai", assignee: "MR", reporter: "JS", desc: "Streaming-Import statt In-Memory implementiert.", projectId: 1 },
    { id: 198, title: "Onboarding-Hinweise Wording", status: "closed", statusLabel: "Geschlossen", statusTone: "violet", type: "question", typeLabel: "Frage", typeTone: "violet", priority: "low", priorityLabel: "Niedrig", priorityTone: "steel", priorityColor: "#94B2D1", due: "—", assignee: "AK", reporter: "RM", desc: "Wording mit Marketing abgestimmt.", projectId: 3 }
  ],
  features: [
    { id: 1, title: "Kunden-360", slug: "kunden-360", desc: "Konsolidierte Sicht auf alle Kundendaten, Aktivitäten und Tickets.", status: "draft", statusLabel: "Entwurf", statusTone: "mustard", useCaseCount: 5, sortOrder: 1 },
    { id: 2, title: "Reporting Dashboard", slug: "reporting-dashboard", desc: "Live-Dashboard mit Vertriebs-KPIs, Filter nach Region und Zeitraum. Drill-down in Tickets und Backlog-Items.", status: "active", statusLabel: "Aktiv", statusTone: "fern", useCaseCount: 5, sortOrder: 3 },
    { id: 3, title: "Datenimport CSV/Excel", slug: "datenimport", desc: "Mappable Importpipeline mit Validierung und Konflikterkennung.", status: "active", statusLabel: "Aktiv", statusTone: "fern", useCaseCount: 4, sortOrder: 2 },
    { id: 4, title: "Onboarding Self-Service", slug: "onboarding", desc: "Setup-Flow für neue Mandanten ohne manuelle Konfiguration.", status: "draft", statusLabel: "Entwurf", statusTone: "mustard", useCaseCount: 3, sortOrder: 4 },
    { id: 5, title: "Single Sign-On", slug: "sso", desc: "SAML/OIDC für Enterprise-Kunden.", status: "done", statusLabel: "Erledigt", statusTone: "violet", useCaseCount: 2, sortOrder: 5 },
    { id: 6, title: "Legacy Reports", slug: "legacy-reports", desc: "Excel-basierte Vorlagen abgelöst.", status: "archived", statusLabel: "Archiviert", statusTone: "steel", useCaseCount: 0, sortOrder: 6 }
  ],
  useCases: {
    2: [
      { id: 1, title: "Vertriebsleiter sieht KPIs nach Region", slug: "kpis-region", status: "active", statusLabel: "Aktiv", statusTone: "fern" },
      { id: 2, title: "Mitarbeiter filtert nach Zeitraum", slug: "filter-zeitraum", status: "active", statusLabel: "Aktiv", statusTone: "fern" },
      { id: 3, title: "Export als PDF für Steering", slug: "pdf-export", status: "draft", statusLabel: "Entwurf", statusTone: "mustard" },
      { id: 4, title: "Vergleich mit Vorjahr", slug: "vergleich-vorjahr", status: "draft", statusLabel: "Entwurf", statusTone: "mustard" },
      { id: 5, title: "Live-Drill-down in Tickets", slug: "drilldown-tickets", status: "active", statusLabel: "Aktiv", statusTone: "fern" }
    ]
  },
  // tasks per project (id) — used in detail page and ProjectForm "Aufgaben" tab
  tasks: {
    1: [
      { title: "Datenmapping CRM → SAP klären", status: "in_progress", statusLabel: "In Arbeit", statusTone: "tangerine", priority: "high", priorityLabel: "Hoch", priorityTone: "tangerine", assignee: "MR", due: "14. Mai" },
      { title: "Importjob für Kontaktduplikate", status: "todo", statusLabel: "Offen", statusTone: "crimson", priority: "urgent", priorityLabel: "Dringend", priorityTone: "crimson", assignee: "JS", due: "Heute" },
      { title: "Stakeholder-Interviews Phase 2", status: "in_progress", statusLabel: "In Arbeit", statusTone: "tangerine", priority: "medium", priorityLabel: "Mittel", priorityTone: "mustard", assignee: "AK", due: "22. Mai" },
      { title: "Migrationstool Smoke-Test", status: "todo", statusLabel: "Offen", statusTone: "crimson", priority: "high", priorityLabel: "Hoch", priorityTone: "tangerine", assignee: "JL", due: "—" },
      { title: "Account-Manager Schulung", status: "done", statusLabel: "Erledigt", statusTone: "fern", priority: "low", priorityLabel: "Niedrig", priorityTone: "steel", assignee: "SK", due: "07. Mai" }
    ]
  },
  backlog: {
    1: [
      { title: "Bulk-Edit für Kontakte", feature: "Kunden-360", priority: "Hoch", priorityTone: "tangerine", status: "Offen", tone: "steel", effort: "M" },
      { title: "Drag&Drop im Pipeline-Board", feature: "Reporting Dashboard", priority: "Mittel", priorityTone: "mustard", status: "Offen", tone: "steel", effort: "L" },
      { title: "Audit-Log für Datenänderungen", feature: "Datenimport CSV/Excel", priority: "Niedrig", priorityTone: "steel", status: "In Arbeit", tone: "tangerine", effort: "M" },
      { title: "Filter „Letzte 7 Tage“", feature: "Reporting Dashboard", priority: "Mittel", priorityTone: "mustard", status: "Erledigt", tone: "fern", effort: "S" },
      { title: "Saved-Views Personalisierung", feature: "Reporting Dashboard", priority: "Hoch", priorityTone: "tangerine", status: "Offen", tone: "steel", effort: "L" },
      { title: "API-Token verlängern", feature: "—", priority: "Mittel", priorityTone: "mustard", status: "Verworfen", tone: "crimson", effort: "XS" }
    ]
  },
  // Milestones — per project. Mirrors @taskmanager/shared-types Milestone shape
  // (name, description, status, color, dueDate, tags, taskCount, ticketCount, featureCount).
  milestones: {
    1: [
      { id: 11, name: "Phase 2 – Datenmigration", desc: "CRM ↔ SAP-Mapping abgeschlossen, Smoke-Test grün.", status: "active", statusLabel: "Aktiv", statusTone: "fern", color: "#2F8E96", dueDate: "31. Mai 2026", tags: [{ name: "Roadmap", color: "#4D9359" }], taskCount: 14, ticketCount: 3, featureCount: 2 },
      { id: 12, name: "Stakeholder-Freigabe", desc: "Steering hat Migrations-Plan unterzeichnet, Go für Roll-out.", status: "completed", statusLabel: "Abgeschlossen", statusTone: "violet", color: "#6A40BE", dueDate: "12. Mai 2026", tags: [], taskCount: 6, ticketCount: 0, featureCount: 1 },
      { id: 13, name: "Pilot-Roll-out Vertrieb DACH", desc: "Erste 30 Account-Manager auf neuem CRM produktiv.", status: "active", statusLabel: "Aktiv", statusTone: "fern", color: "#2E5984", dueDate: "28. Jun 2026", tags: [{ name: "Backend", color: "#2E5984" }], taskCount: 9, ticketCount: 2, featureCount: 1 },
      { id: 14, name: "Audit-Log Hardening", desc: "Compliance-Anforderungen aus Q2-Review umsetzen.", status: "on_hold", statusLabel: "Pausiert", statusTone: "tangerine", color: "#ED8C3A", dueDate: "Ohne Fälligkeit", tags: [], taskCount: 4, ticketCount: 1, featureCount: 0 }
    ],
    2: [
      { id: 21, name: "Dashboard MVP", desc: "Live-KPIs Region & Zeitraum, exportierbar als PDF.", status: "active", statusLabel: "Aktiv", statusTone: "fern", color: "#2F8E96", dueDate: "10. Jun 2026", tags: [{ name: "Daten", color: "#2F8E96" }], taskCount: 8, ticketCount: 1, featureCount: 1 },
      { id: 22, name: "Excel-Ablösung", desc: "Alte Berichts-Templates abgeschaltet.", status: "active", statusLabel: "Aktiv", statusTone: "fern", color: "#4D9359", dueDate: "24. Jun 2026", tags: [], taskCount: 3, ticketCount: 0, featureCount: 0 }
    ]
  },
  // feature ↔ project links
  featureProjects: { 2: [1, 2] },
  projectFeatures: { 1: [1, 2, 3], 2: [2] },
  wikiTree: [
    { id: 1, title: "Einführung", slug: "einführung", children: [
      { id: 11, title: "Vision", slug: "einführung/vision", children: [] },
      { id: 12, title: "Architektur-Überblick", slug: "einführung/architektur", children: [] }
    ]},
    { id: 2, title: "Entwicklung", slug: "entwicklung", children: [
      { id: 21, title: "Setup lokal", slug: "entwicklung/setup", children: [] },
      { id: 22, title: "Conventions", slug: "entwicklung/conventions", children: [] },
      { id: 23, title: "Test-Strategie", slug: "entwicklung/tests", children: [] }
    ]},
    { id: 3, title: "Betrieb", slug: "betrieb", children: [
      { id: 31, title: "Backup", slug: "betrieb/backup", children: [] },
      { id: 32, title: "Monitoring", slug: "betrieb/monitoring", children: [] }
    ]},
    { id: 4, title: "Glossar", slug: "glossar", children: [] }
  ],
  wikiPages: {
    12: { id: 12, title: "Architektur-Überblick", slug: "einführung/architektur", parent: "Einführung", updatedBy: "RM", updatedAt: "11. Mai 2026", version: 4 }
  },
  tags: [
    { id: 1, name: "Roadmap", color: "#4D9359", usage: "Projekte 4 · Tasks 12 · Notizen 3" },
    { id: 2, name: "Frontend", color: "#6A40BE", usage: "Projekte 2 · Tasks 18 · Notizen 6" },
    { id: 3, name: "Backend", color: "#2E5984", usage: "Projekte 2 · Tasks 22 · Notizen 4" },
    { id: 4, name: "Hotfix", color: "#D9416A", usage: "Tasks 3" },
    { id: 5, name: "Daten", color: "#2F8E96", usage: "Projekte 1 · Tasks 9 · Notizen 2" },
    { id: 6, name: "UX", color: "#C13D9A", usage: "Tasks 7 · Notizen 5" },
    { id: 7, name: "Infra", color: "#1B355C", usage: "Projekte 1 · Tasks 4" },
    { id: 8, name: "Wartung", color: "#ED8C3A", usage: "verwaist" }
  ],
  seedRuns: [
    { id: "seed-01HA2C3...4Q", label: "Demo-Daten Standard", date: "12.05.26 09:14", projects: 6, tasks: 84, files: 12, total: 312 },
    { id: "seed-01H9K7B...XT", label: "QA Kunden-360 Smoke", date: "08.05.26 17:42", projects: 3, tasks: 48, files: 6, total: 187 },
    { id: "seed-01H8RR8...M9", label: "Performance 1k Tasks", date: "02.05.26 11:01", projects: 12, tasks: 1024, files: 0, total: 1248 }
  ],
  calendarEvents: {
    5: [{ color: "#2E5984", text: "Sprint Review" }],
    7: [{ color: "#4D9359", text: "Daily 9:30" }],
    11: [{ color: "#2F8E96", text: "Reporting Demo" }],
    12: [{ color: "#ED8C3A", text: "Steering Apollo" }, { color: "#6A40BE", text: "UX Workshop" }],
    14: [{ color: "#D9416A", text: "Hotfix Fenster" }],
    18: [{ color: "#2E5984", text: "Sprint Planning" }],
    21: [{ color: "#E2BA2C", text: "1:1 MR" }],
    25: [{ color: "#2E5984", text: "Sprint Review" }],
    27: [{ color: "#6A40BE", text: "Retro" }],
    28: [{ color: "#4D9359", text: "Release Cut" }]
  },
  upcoming: [
    { date: "13. Mai · 09:30", title: "Daily", color: "#4D9359" },
    { date: "14. Mai · 14:00", title: "Hotfix Fenster Apollo", color: "#D9416A" },
    { date: "18. Mai · 10:00", title: "Sprint Planning", color: "#2E5984" },
    { date: "21. Mai · 15:00", title: "1:1 mit MR", color: "#E2BA2C" }
  ]
};
