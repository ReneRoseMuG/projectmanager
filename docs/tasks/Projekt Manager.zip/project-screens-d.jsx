// ProjectForm – tabs Kommentare, Notizen, Dateien, Backlog, Import.

// ───── 9) Kommentare Tab (CommentThread) ─────
window.PS_ProjectFormComments = function () {
  useLucide();
  const comments = [
    { user: "Single User", initials: "SU", color: "#2E5984", date: "12. Mai 2026", text: "Steering hat den Migrations-Plan genehmigt. Wir starten mit Phase 2 nächste Woche." },
    { user: "Single User", initials: "SU", color: "#2E5984", date: "11. Mai 2026", text: "Datenmapping ist offen — bitte bis Mittwoch klären, sonst rutscht der Smoke-Test." },
    { user: "Single User", initials: "SU", color: "#2E5984", date: "10. Mai 2026", text: "Stakeholder-Interviews sind bis Donnerstag terminiert." },
    { user: "Single User", initials: "SU", color: "#2E5984", date: "09. Mai 2026", text: "Reset-Bug ist hotgefixt, Patch geht morgen live." }
  ];
  return (
    <AppShell active="/projects">
      <div className="opacity-30 pointer-events-none"><PageHeader title="Projekte" subtitle="6 Einträge" /></div>
      <PFShell subtitle="edit" tabs={PF_TABS_FULL} active="comments" counts={{ features: 3, tickets: 5, comments: 4, notes: 2, attachments: 6, backlog: 14 }} footerStart={<button className="btn btn-ghost text-crimson"><Icon name="trash-2" size={17} />Löschen</button>}>
        <Section title="Kommentare">
          {/* Composer */}
          <div className="grid gap-3">
            <PFRte html="<p style='color:#94a3b8'>Kommentar schreiben</p>" minHeight="7rem" toolbar="minimal" />
            <div className="flex justify-end">
              <button className="btn btn-primary"><Icon name="send" size={16} />Kommentar</button>
            </div>
          </div>
          {/* Thread */}
          <div className="grid gap-3 mt-4">
            {comments.map((c, i) => (
              <article key={i} className="card p-4 grid gap-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <span className="flex h-10 w-10 items-center justify-center rounded-full text-white text-xs font-bold" style={{ background: c.color }}>{c.initials}</span>
                    <div className="min-w-0">
                      <p className="font-semibold text-ink">{c.user}</p>
                      <time className="text-xs text-slate-500">{c.date}</time>
                    </div>
                  </div>
                  <button className="btn btn-ghost btn-icon"><Icon name="trash-2" size={17} /></button>
                </div>
                <p className="text-sm text-slate-700">{c.text}</p>
                <div className="flex flex-wrap items-center gap-2 border-t border-line pt-3 text-xs font-semibold text-slate-500">
                  <span className="rounded-full bg-shell px-2 py-1">0 Reaktionen</span>
                  <span className="rounded-full bg-shell px-2 py-1">Antworten</span>
                </div>
              </article>
            ))}
          </div>
        </Section>
      </PFShell>
    </AppShell>
  );
};

// ───── 10) Notizen Tab (NoteList) ─────
window.PS_ProjectFormNotes = function () {
  useLucide();
  const notes = [
    { id: 1, title: "Onboarding-Notizen Steering", date: "12. Mai 2026", tone: "tangerine" },
    { id: 2, title: "Migrations-Risiken", date: "08. Mai 2026", tone: "violet" }
  ];
  const toneMap = { tangerine: "bg-tangerine/10 text-tangerine", violet: "bg-violet/10 text-violet", fern: "bg-fern/10 text-fern", magenta: "bg-magenta/10 text-magenta" };
  return (
    <AppShell active="/projects">
      <div className="opacity-30 pointer-events-none"><PageHeader title="Projekte" subtitle="6 Einträge" /></div>
      <PFShell subtitle="edit" tabs={PF_TABS_FULL} active="notes" counts={{ features: 3, tickets: 5, comments: 4, notes: 2, attachments: 6, backlog: 14 }} footerStart={<button className="btn btn-ghost text-crimson"><Icon name="trash-2" size={17} />Löschen</button>}>
        <Section>
          <div className="mb-4 flex items-center gap-2"><Icon name="sticky-note" size={18} style={{ color: "var(--color-fern)" }} /><h3 className="text-base font-semibold">Notizen</h3></div>
          <div className="mb-3 flex items-center justify-end">
            <button className="btn btn-primary"><Icon name="plus" size={17} />Neue Notiz</button>
          </div>
          <div className="grid gap-3">
            {notes.map((n) => (
              <article key={n.id} className="flex items-center justify-between gap-3 rounded-xl border border-line bg-white px-4 py-3.5">
                <button className="flex min-w-0 items-center gap-3 text-left">
                  <span className={`flex h-10 w-10 items-center justify-center rounded-xl ${toneMap[n.tone]}`}><Icon name="file-text" size={18} /></span>
                  <span className="min-w-0">
                    <strong className="block truncate text-sm font-semibold text-ink">{n.title}</strong>
                    <time className="mt-0.5 block text-xs text-slate-500">{n.date}</time>
                  </span>
                </button>
                <div className="flex gap-1">
                  <button className="btn btn-ghost btn-icon"><Icon name="edit-3" size={18} /></button>
                  <button className="btn btn-ghost btn-icon"><Icon name="trash-2" size={18} /></button>
                </div>
              </article>
            ))}
          </div>
        </Section>
      </PFShell>
    </AppShell>
  );
};

// ───── 11) Dateien Tab (AttachmentUploader + AttachmentList) ─────
window.PS_ProjectFormAttachments = function () {
  useLucide();
  const files = [
    { name: "kickoff-meeting.pdf", size: "2.4 MB", icon: "file-text" },
    { name: "datenmodell-v3.png", size: "1.1 MB", icon: "image" },
    { name: "scope-q3-2026.xlsx", size: "84 KB", icon: "file-spreadsheet" },
    { name: "vertrag-anbieter.pdf", size: "612 KB", icon: "file-text" },
    { name: "stakeholder-mapping.fig", size: "3.2 MB", icon: "file" },
    { name: "demo-export.csv", size: "26 KB", icon: "file-spreadsheet" }
  ];
  return (
    <AppShell active="/projects">
      <div className="opacity-30 pointer-events-none"><PageHeader title="Projekte" subtitle="6 Einträge" /></div>
      <PFShell subtitle="edit" tabs={PF_TABS_FULL} active="attachments" counts={{ features: 3, tickets: 5, comments: 4, notes: 2, attachments: 6, backlog: 14 }} footerStart={<button className="btn btn-ghost text-crimson"><Icon name="trash-2" size={17} />Löschen</button>}>
        <Section>
          <div className="mb-4 flex items-center gap-2"><Icon name="paperclip" size={18} style={{ color: "var(--color-fern)" }} /><h3 className="text-base font-semibold">Dateien</h3></div>
          {/* AttachmentUploader */}
          <div className="grid place-items-center gap-3 rounded-2xl border-2 border-dashed border-steel-300 px-6 py-9 text-center" style={{ background: "linear-gradient(180deg, rgba(232,239,245,0.5), #fff)" }}>
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-steel-700 text-white" style={{ boxShadow: "var(--shadow-steel-icon)" }}>
              <Icon name="upload" size={22} />
            </div>
            <div>
              <h3 className="text-base font-bold text-ink">Dateien hier ablegen</h3>
              <p className="text-sm text-slate-500">oder über den Button auswählen - max. 25 MB pro Datei</p>
            </div>
            <button className="btn btn-primary"><Icon name="upload" size={16} />Auswählen</button>
          </div>
          {/* AttachmentList */}
          <div className="grid gap-2 mt-4">
            {files.map((f, i) => (
              <div key={i} className="flex items-center gap-3 rounded-md border border-line bg-white p-3">
                <span className="flex h-10 w-10 items-center justify-center rounded-md bg-steel-100 text-steel-700"><Icon name={f.icon} size={18} /></span>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-ink truncate">{f.name}</p>
                  <p className="text-xs text-slate-500">{f.size}</p>
                </div>
                <button className="btn btn-ghost btn-icon"><Icon name="download" size={17} /></button>
                <button className="btn btn-ghost btn-icon text-crimson"><Icon name="trash-2" size={17} /></button>
              </div>
            ))}
          </div>
        </Section>
      </PFShell>
    </AppShell>
  );
};

// ───── 12) Backlog Tab (BacklogListBoardView) ─────
window.PS_ProjectFormBacklog = function () {
  useLucide();
  const items = [
    { title: "Bulk-Edit für Kontakte", feature: "Kunden-360", priority: "Hoch", priorityTone: "tangerine", priorityColor: "#ED8C3A", status: "Offen", statusTone: "steel", desc: "Mehrere Kontakte gleichzeitig editieren – Status, Tags, Owner." },
    { title: "Drag&Drop im Pipeline-Board", feature: "Reporting Dashboard", priority: "Mittel", priorityTone: "mustard", priorityColor: "#E2BA2C", status: "Offen", statusTone: "steel", desc: "Stages per D&D umsortieren statt nur über Dropdown." },
    { title: "Audit-Log für Datenänderungen", feature: "Datenimport CSV/Excel", priority: "Niedrig", priorityTone: "steel", priorityColor: "#94B2D1", status: "In Arbeit", statusTone: "tangerine", desc: "Wer hat wann was geändert – revisionssicher." },
    { title: "Filter „Letzte 7 Tage“", feature: "Reporting Dashboard", priority: "Mittel", priorityTone: "mustard", priorityColor: "#E2BA2C", status: "Erledigt", statusTone: "fern", desc: "Quick-Filter im Dashboard." },
    { title: "Saved-Views Personalisierung", feature: "Reporting Dashboard", priority: "Hoch", priorityTone: "tangerine", priorityColor: "#ED8C3A", status: "Offen", statusTone: "steel", desc: "Benutzer können View-Konfigurationen speichern." },
    { title: "API-Token verlängern", feature: null, priority: "Mittel", priorityTone: "mustard", priorityColor: "#E2BA2C", status: "Verworfen", statusTone: "crimson", desc: "Wird durch SSO ersetzt – nicht mehr nötig." }
  ];
  return (
    <AppShell active="/projects">
      <div className="opacity-30 pointer-events-none"><PageHeader title="Projekte" subtitle="6 Einträge" /></div>
      <PFShell subtitle="edit" tabs={PF_TABS_FULL} active="backlog" counts={{ features: 3, tickets: 5, comments: 4, notes: 2, attachments: 6, backlog: 14 }} footerStart={<button className="btn btn-ghost text-crimson"><Icon name="trash-2" size={17} />Löschen</button>}>
        <Section title="Backlog">
          <ListBoardChrome viewMode="list" addLabel="Neues Backlog-Item" filters={
            <FilterChips value="all" allCount={6} options={[
              { value: "open", label: "Offen", count: 3 },
              { value: "in_progress", label: "In Arbeit", count: 1 },
              { value: "done", label: "Erledigt", count: 1 },
              { value: "rejected", label: "Verworfen", count: 1 }
            ]} />
          } />
          <div className="grid gap-3 mt-4">
            {items.map((it, i) => (
              <article key={i} className={`card flex items-stretch overflow-hidden ${it.status === "Verworfen" ? "opacity-65" : ""}`}>
                <div style={{ background: it.priorityColor, width: 4 }}></div>
                <div className="flex flex-1 items-center gap-4 p-4">
                  <Pill tone={it.statusTone}>{it.status}</Pill>
                  <div className="min-w-0 flex-1">
                    <h3 className={`text-sm font-semibold ${it.status === "Verworfen" ? "text-slate-500 line-through" : "text-ink"}`}>{it.title}</h3>
                    <p className="text-xs text-slate-600 truncate">{it.desc}</p>
                  </div>
                  <Badge tone={it.priorityTone}>{it.priority}</Badge>
                  {it.feature ? <Badge tone="teal">{it.feature}</Badge> : <Badge tone="mute">Ohne Feature</Badge>}
                  <div className="flex gap-1">
                    <button className="btn btn-ghost btn-icon"><Icon name="edit-3" size={18} /></button>
                    <button className="btn btn-ghost btn-icon"><Icon name="trash-2" size={18} /></button>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </Section>
      </PFShell>
    </AppShell>
  );
};

// ───── 13) Import Tab (WikiImportPanel) ─────
window.PS_ProjectFormImport = function () {
  useLucide();
  const rows = [
    { action: "created", actionLabel: "Neu", actionClass: "bg-fern/10 text-fern", type: "feature", title: "Reporting Dashboard", source: "wiki/reporting/index.md" },
    { action: "updated", actionLabel: "Aktualisiert", actionClass: "bg-violet/10 text-violet", type: "use-case", title: "KPI-Filter nach Region", source: "wiki/reporting/usecases/region.md" },
    { action: "updated", actionLabel: "Aktualisiert", actionClass: "bg-violet/10 text-violet", type: "use-case", title: "Drill-down in Tickets", source: "wiki/reporting/usecases/drilldown.md" },
    { action: "skipped", actionLabel: "Unverändert", actionClass: "bg-slate-100 text-slate-600", type: "feature", title: "Kunden-360", source: "wiki/kunden-360/index.md" },
    { action: "warning", actionLabel: "Warnung", actionClass: "bg-mustard/15 text-mustard-dark", type: "use-case", title: "PDF-Export", source: "wiki/reporting/usecases/pdf.md", message: "Slug fehlt – wird aus Titel abgeleitet." },
    { action: "error", actionLabel: "Fehler", actionClass: "bg-crimson/10 text-crimson", type: "feature", title: "Legacy Reports", source: "wiki/legacy/index.md", message: "Front-Matter ungültig (YAML-Parser)." }
  ];
  return (
    <AppShell active="/projects">
      <div className="opacity-30 pointer-events-none"><PageHeader title="Projekte" subtitle="6 Einträge" /></div>
      <PFShell subtitle="edit" tabs={PF_TABS_FULL} active="import" counts={{ features: 3, tickets: 5, comments: 4, notes: 2, attachments: 6, backlog: 14 }} footerStart={<button className="btn btn-ghost text-crimson"><Icon name="trash-2" size={17} />Löschen</button>}>
        <section className="grid gap-4 rounded-lg border border-line bg-white p-5" style={{ boxShadow: "var(--shadow-sm)" }}>
          <div className="flex flex-wrap items-end gap-3">
            <label className="grid min-w-[280px] flex-1 gap-1 text-sm font-medium text-ink">
              Wiki-Ordner
              <input className="h-10 rounded-md border border-line bg-white px-3 text-sm font-normal outline-none focus:border-steel-600" placeholder="C:\…\docs\wiki" defaultValue="C:\projects\apollo\docs\wiki" />
            </label>
            <button className="btn btn-secondary"><Icon name="eye" size={16} />Vorschau</button>
            <button className="btn btn-primary"><Icon name="play" size={16} />Importieren</button>
          </div>
          <div className="grid gap-2 sm:grid-cols-5">
            {[
              { label: "Neu", value: 1 }, { label: "Aktualisiert", value: 2 },
              { label: "Unverändert", value: 1 }, { label: "Warnungen", value: 1 }, { label: "Fehler", value: 1 }
            ].map((t) => (
              <div key={t.label} className="rounded-md border border-line bg-shell px-3 py-2">
                <div className="text-xs font-medium text-slate-500">{t.label}</div>
                <div className="text-xl font-semibold text-ink">{t.value}</div>
              </div>
            ))}
          </div>
          <div className="overflow-hidden rounded-lg border border-line">
            <table className="w-full border-collapse text-left text-sm">
              <thead className="bg-shell text-xs uppercase text-slate-500">
                <tr>
                  <th className="px-3 py-2 font-semibold">Status</th>
                  <th className="px-3 py-2 font-semibold">Typ</th>
                  <th className="px-3 py-2 font-semibold">Titel</th>
                  <th className="px-3 py-2 font-semibold">Quelle</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line">
                {rows.map((r, i) => (
                  <tr key={i} className="align-top">
                    <td className="px-3 py-2"><span className={`inline-flex rounded-full px-2 py-1 text-xs font-semibold ${r.actionClass}`}>{r.actionLabel}</span></td>
                    <td className="px-3 py-2 font-mono text-xs text-slate-500">{r.type}</td>
                    <td className="px-3 py-2">
                      <div className="font-medium text-ink">{r.title}</div>
                      {r.message ? <div className="mt-1 text-xs text-slate-500">{r.message}</div> : null}
                    </td>
                    <td className="max-w-[360px] truncate px-3 py-2 text-xs text-slate-500">{r.source}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </PFShell>
    </AppShell>
  );
};
