// ProjectForm – remaining tabs (Features, Aufgaben, Tickets, Kommentare,
// Notizen, Dateien, Backlog, Import). Each artboard renders the modal in
// edit mode on a single tab.

// ───── 6) Features Tab ─────
// Inside: ProjectFeaturePanel = ListBoardView(features) with board/list toggle.
window.PS_ProjectFormFeatures = function () {
  useLucide();
  const features = [
    { id: 2, title: "Reporting Dashboard", slug: "reporting-dashboard", desc: "Live-Dashboard mit Vertriebs-KPIs, Filter nach Region und Zeitraum.", statusLabel: "Aktiv", statusTone: "fern", useCases: 5 },
    { id: 1, title: "Kunden-360", slug: "kunden-360", desc: "Konsolidierte Sicht auf alle Kundendaten, Aktivitäten und Tickets.", statusLabel: "Entwurf", statusTone: "mustard", useCases: 5 },
    { id: 3, title: "Datenimport CSV/Excel", slug: "datenimport", desc: "Mappable Importpipeline mit Validierung und Konflikterkennung.", statusLabel: "Aktiv", statusTone: "fern", useCases: 4 }
  ];
  return (
    <AppShell active="/projects">
      <div className="opacity-30 pointer-events-none"><PageHeader title="Projekte" subtitle="6 Einträge" /></div>
      <PFShell subtitle="edit" tabs={PF_TABS_FULL} active="features" counts={{ features: 3, tickets: 5, comments: 4, notes: 2, attachments: 6, backlog: 14 }} footerStart={<button className="btn btn-ghost text-crimson"><Icon name="trash-2" size={17} />Löschen</button>}>
        <Section title="Features">
          <ListBoardChrome viewMode="list" addLabel="Neues Feature" />
          <div className="grid gap-3 mt-4">
            {features.map((f) => (
              <article key={f.id} className="card flex items-stretch overflow-hidden">
                <div style={{ background: "var(--color-steel-600)", width: 4 }}></div>
                <div className="flex flex-1 items-center gap-4 p-4">
                  <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-steel-600 text-white shrink-0"><Icon name="book-open" size={20} /></span>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-sm font-semibold text-ink">{f.title}</h3>
                    <p className="text-xs text-slate-600 truncate">{f.desc}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Pill tone={f.statusTone}>{f.statusLabel}</Pill>
                    <Badge tone="steel">{f.useCases} Use Cases</Badge>
                  </div>
                  <span className="font-mono text-xs text-slate-500 w-44 text-right">/features/{f.slug}</span>
                  <button className="btn btn-ghost btn-icon"><Icon name="edit-3" size={18} /></button>
                </div>
              </article>
            ))}
          </div>
        </Section>
      </PFShell>
    </AppShell>
  );
};

// ───── 7) Aufgaben Tab (OwnerTaskBoard → TaskListBoardView – Kanban) ─────
window.PS_ProjectFormTasks = function () {
  useLucide();
  const cols = [
    { value: "todo", label: "Offen", tone: "crimson" },
    { value: "in_progress", label: "In Arbeit", tone: "tangerine" },
    { value: "done", label: "Erledigt", tone: "fern" }
  ];
  const tasks = [
    { title: "Datenmapping CRM → SAP klären", status: "in_progress", priority: "Hoch", priorityTone: "tangerine", priorityColor: "#ED8C3A", assignee: "MR", due: "14. Mai" },
    { title: "Importjob für Kontaktduplikate", status: "todo", priority: "Dringend", priorityTone: "crimson", priorityColor: "#D9416A", assignee: "JS", due: "Heute" },
    { title: "Stakeholder-Interviews Phase 2", status: "in_progress", priority: "Mittel", priorityTone: "mustard", priorityColor: "#E2BA2C", assignee: "AK", due: "22. Mai" },
    { title: "Migrationstool Smoke-Test", status: "todo", priority: "Hoch", priorityTone: "tangerine", priorityColor: "#ED8C3A", assignee: "JL", due: "—" },
    { title: "Account-Manager Schulung", status: "done", priority: "Niedrig", priorityTone: "steel", priorityColor: "#94B2D1", assignee: "SK", due: "07. Mai" },
    { title: "Datenexport Schema dokumentieren", status: "done", priority: "Mittel", priorityTone: "mustard", priorityColor: "#E2BA2C", assignee: "MR", due: "05. Mai" }
  ];
  return (
    <AppShell active="/projects">
      <div className="opacity-30 pointer-events-none"><PageHeader title="Projekte" subtitle="6 Einträge" /></div>
      <PFShell subtitle="edit" tabs={PF_TABS_FULL} active="tasks" counts={{ features: 3, tickets: 5, comments: 4, notes: 2, attachments: 6, backlog: 14 }} footerStart={<button className="btn btn-ghost text-crimson"><Icon name="trash-2" size={17} />Löschen</button>}>
        <Section title="Aufgaben">
          <ListBoardChrome viewMode="board" addLabel="Neue Aufgabe" />
          <div className="mt-4 grid grid-cols-3 gap-3">
            {cols.map((c) => {
              const items = tasks.filter((t) => t.status === c.value);
              return (
                <section key={c.value} className="grid content-start gap-2 rounded-lg border border-line p-3" style={{ background: "rgba(244,247,250,0.6)" }}>
                  <header className="flex items-center justify-between">
                    <div className="flex items-center gap-2"><span className="h-2 w-2 rounded-full" style={{ background: `var(--color-${c.tone})` }}></span><h3 className="text-sm font-semibold">{c.label}</h3></div>
                    <div className="flex items-center gap-2">
                      <span className="rounded-full bg-white px-2 py-0.5 text-xs font-semibold text-slate-600 shadow-sm">{items.length}</span>
                      <button className="btn btn-ghost btn-icon-sm" style={{ background: "#fff", border: "1px solid var(--color-line)" }}><Icon name="plus" size={15} /></button>
                    </div>
                  </header>
                  {items.map((t, i) => (
                    <article key={i} className="card overflow-hidden">
                      <div style={{ background: t.priorityColor, height: 4 }}></div>
                      <div className="p-3 grid gap-2">
                        <p className="text-sm font-semibold text-ink leading-tight">{t.title}</p>
                        <div className="flex items-center gap-2"><Badge tone={t.priorityTone}>{t.priority}</Badge></div>
                        <div className="flex items-center justify-between border-t border-line pt-2 text-xs text-slate-500">
                          <span className="inline-flex items-center gap-1"><Icon name="calendar-clock" size={13} />{t.due}</span>
                          <span className="flex h-6 w-6 items-center justify-center rounded-full bg-steel-100 text-steel-700 text-[10px] font-bold">{t.assignee}</span>
                        </div>
                      </div>
                    </article>
                  ))}
                </section>
              );
            })}
          </div>
        </Section>
      </PFShell>
    </AppShell>
  );
};

// ───── 8) Tickets Tab ─────
window.PS_ProjectFormTickets = function () {
  useLucide();
  const tickets = [
    { id: 204, title: "Login schlägt nach Passwort-Reset fehl", status: "Offen", tone: "steel", type: "Bug", typeTone: "crimson", priority: "Dringend", priorityTone: "crimson", priorityColor: "#D9416A", due: "Heute", assignee: "JS" },
    { id: 214, title: "Doppelte E-Mail-Validierung", status: "In Arbeit", tone: "tangerine", type: "Verbesserung", typeTone: "teal", priority: "Mittel", priorityTone: "mustard", priorityColor: "#E2BA2C", due: "20. Mai", assignee: "AK" },
    { id: 215, title: "Suche ignoriert Umlaute", status: "In Arbeit", tone: "tangerine", type: "Bug", typeTone: "crimson", priority: "Hoch", priorityTone: "tangerine", priorityColor: "#ED8C3A", due: "Morgen", assignee: "JL" },
    { id: 220, title: "Speicherprobleme bei großem Import", status: "Gelöst", tone: "fern", type: "Bug", typeTone: "crimson", priority: "Dringend", priorityTone: "crimson", priorityColor: "#D9416A", due: "08. Mai", assignee: "MR" },
    { id: 198, title: "Onboarding-Hinweise Wording", status: "Geschlossen", tone: "violet", type: "Frage", typeTone: "violet", priority: "Niedrig", priorityTone: "steel", priorityColor: "#94B2D1", due: "—", assignee: "AK" }
  ];
  return (
    <AppShell active="/projects">
      <div className="opacity-30 pointer-events-none"><PageHeader title="Projekte" subtitle="6 Einträge" /></div>
      <PFShell subtitle="edit" tabs={PF_TABS_FULL} active="tickets" counts={{ features: 3, tickets: 5, comments: 4, notes: 2, attachments: 6, backlog: 14 }} footerStart={<button className="btn btn-ghost text-crimson"><Icon name="trash-2" size={17} />Löschen</button>}>
        <Section title="Tickets">
          <ListBoardChrome viewMode="list" addLabel="Neues Ticket" />
          <div className="grid gap-3 mt-4">
            {tickets.map((r) => (
              <article key={r.id} className="card flex items-stretch overflow-hidden">
                <div style={{ background: r.priorityColor, width: 4 }}></div>
                <div className="flex flex-1 items-center gap-4 p-4">
                  <span className="block h-3 w-3 rounded-full shrink-0" style={{ background: `var(--color-${r.tone === "steel" ? "steel-400" : r.tone})` }}></span>
                  <div className="min-w-0 flex-1">
                    <h3 className="text-sm font-semibold text-ink">TICKET-{r.id} · {r.title}</h3>
                  </div>
                  <div className="flex items-center gap-2">
                    <Pill tone={r.tone}>{r.status}</Pill>
                    <Badge tone={r.typeTone}>{r.type}</Badge>
                    <Badge tone={r.priorityTone}>{r.priority}</Badge>
                  </div>
                  <span className="inline-flex w-20 items-center gap-1 text-xs font-semibold text-slate-500"><Icon name="calendar-clock" size={14} />{r.due}</span>
                  <span className="flex h-9 w-9 items-center justify-center rounded-full bg-steel-100 text-steel-700 text-xs font-bold">{r.assignee}</span>
                </div>
              </article>
            ))}
          </div>
        </Section>
      </PFShell>
    </AppShell>
  );
};
