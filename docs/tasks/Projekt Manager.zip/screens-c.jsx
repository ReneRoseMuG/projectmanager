// Settings screens.

// ───── Page 10: Settings → Tags ─────
window.SettingsTagsScreen = function () {
  useLucide();
  const palette = ["#2E5984", "#D9416A", "#ED8C3A", "#E2BA2C", "#4D9359", "#2F8E96", "#6A40BE", "#C13D9A"];
  const tags = [
    { name: "Roadmap", color: "#4D9359", usage: "Projekte 4 · Tasks 12 · Notizen 3" },
    { name: "Frontend", color: "#6A40BE", usage: "Projekte 2 · Tasks 18 · Notizen 6" },
    { name: "Backend", color: "#2E5984", usage: "Projekte 2 · Tasks 22 · Notizen 4" },
    { name: "Hotfix", color: "#D9416A", usage: "Tasks 3" },
    { name: "Daten", color: "#2F8E96", usage: "Projekte 1 · Tasks 9 · Notizen 2" },
    { name: "UX", color: "#C13D9A", usage: "Tasks 7 · Notizen 5" },
    { name: "Infra", color: "#1B355C", usage: "Projekte 1 · Tasks 4" },
    { name: "Wartung", color: "#ED8C3A", usage: "verwaist" }
  ];
  return (
    <AppShell active="/settings/tags">
      <div className="card overflow-hidden">
        <header className="px-5 py-5 text-white" style={{ background: "linear-gradient(135deg, var(--color-magenta), rgba(193,61,154,0.75))" }}>
          <div className="flex items-center gap-3">
            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/12">
              <Icon name="tags" size={21} />
            </span>
            <div>
              <h1 className="text-2xl font-bold">Tags verwalten</h1>
              <p className="text-sm text-white/75">8 Tags · genutzt in 9 Projekten, 75 Tasks, 20 Notizen</p>
            </div>
          </div>
        </header>
        <div className="p-5 grid gap-4">
          <section>
            <h2 className="mb-3 text-sm font-bold uppercase text-slate-500">Neuer Tag</h2>
            <div className="grid gap-3 md:grid-cols-[auto_minmax(0,1fr)_auto] md:items-center">
              <span className="h-9 w-9 rounded-full border border-white" style={{ background: "#2E5984", boxShadow: "0 0 0 1px var(--color-line)" }}></span>
              <input className="input" placeholder="Tag-Name" />
              <Btn variant="primary" icon="plus">Anlegen</Btn>
            </div>
            <div className="mt-3"><ColorSwatches swatches={palette} selected="#2E5984" /></div>
          </section>
          <section>
            <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
              <h2 className="font-semibold text-ink">Alle Tags · 8 Einträge</h2>
              <div className="flex items-center gap-2">
                <label className="relative">
                  <Icon name="search" size={14} style={{ position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)", color: "var(--color-slate-400)" }} />
                  <input className="h-9 w-56 rounded-md border border-line pl-8 pr-3 text-sm outline-none" placeholder="Tags suchen" />
                </label>
                <select className="h-9 rounded-md border border-line bg-white px-3 text-sm">
                  <option>Verwendung</option><option>Name A-Z</option><option>Neueste</option>
                </select>
              </div>
            </div>
            <div className="grid grid-cols-[auto_minmax(0,1fr)_minmax(9rem,1fr)_7rem_auto] gap-3 border-b border-line pb-2 text-xs font-bold uppercase text-slate-500">
              <span>Farbe</span><span>Name</span><span>Verwendungen</span><span>Status</span><span className="text-right">Aktionen</span>
            </div>
            {tags.map((t) => (
              <div key={t.name} className="grid grid-cols-[auto_minmax(0,1fr)_minmax(9rem,1fr)_7rem_auto] items-center gap-3 border-b border-line py-3 text-sm">
                <span className="h-6 w-6 rounded-full" style={{ background: t.color, boxShadow: "0 0 0 1px var(--color-line)" }}></span>
                <span className="truncate font-semibold text-ink">{t.name}</span>
                <span className="text-slate-500">{t.usage}</span>
                <span className={`rounded-full px-2 py-1 text-center text-xs font-semibold ${t.usage === "verwaist" ? "border border-line bg-shell text-slate-500" : "bg-fern/10 text-fern"}`}>
                  {t.usage === "verwaist" ? "verwaist" : "in Nutzung"}
                </span>
                <div className="flex justify-end gap-1">
                  <Btn icon="pencil" iconOnly variant="ghost" />
                  <Btn icon="git-merge" iconOnly variant="ghost" />
                  <Btn icon="trash-2" iconOnly variant="ghost" className="text-crimson" />
                </div>
              </div>
            ))}
          </section>
        </div>
      </div>
    </AppShell>
  );
};

// ───── Page 11: Settings → Sicherung (Google Drive) ─────
window.SettingsBackupScreen = function () {
  useLucide();
  return (
    <AppShell active="/settings/backup">
      <PageHeader title="Sicherung" subtitle="Google Drive" action={
        <div className="flex gap-2">
          <Btn variant="primary" icon="cloud-upload">Sichern</Btn>
          <Btn icon="refresh-cw">Aktualisieren</Btn>
        </div>
      } />
      <section className="section-card p-4">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Icon name="folder-cog" size={18} />
            <h2 className="text-base font-semibold">Google-Drive-Zielordner</h2>
          </div>
          <Badge tone="fern">bereit</Badge>
        </div>
        <div className="grid gap-3">
          <div className="flex gap-2">
            <input className="input flex-1 input-mono" defaultValue="https://drive.google.com/drive/folders/1A2bCd3EfGh4iJkLmN5oP" />
            <Btn icon="folder-cog">Speichern</Btn>
          </div>
          <div className="flex flex-wrap gap-3 text-xs text-slate-500">
            <span>Quelle: UI</span>
            <span className="font-mono">ID: 1A2bCd3EfGh4iJkLmN5oP</span>
            <span>OAuth: konfiguriert</span>
          </div>
        </div>
      </section>
      <section className="section-card p-4">
        <div className="mb-2 flex items-center gap-2">
          <Icon name="database-backup" size={18} />
          <h2 className="text-base font-semibold">Letzte Sicherung</h2>
        </div>
        <div className="grid gap-2 text-sm text-slate-600 md:grid-cols-3">
          <span><Icon name="file-archive" size={14} className="inline mr-1" />taskmanager-2026-05-13-0930.zip</span>
          <span>42.17 MB</span>
          <span className="font-mono text-xs">dump-9f8a3c</span>
        </div>
      </section>
      <section className="section-card p-4">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Icon name="cloud-download" size={18} />
            <h2 className="text-base font-semibold">Aktualisierung</h2>
          </div>
          <Badge tone="fern">ready</Badge>
        </div>
        <div className="grid gap-2 text-sm text-slate-600 md:grid-cols-3">
          <span>taskmanager-2026-05-12-0915.zip</span>
          <span>17 Tabellen</span>
          <span>284 Dateien</span>
        </div>
        <div className="mt-4 grid gap-2">
          <p className="rounded-md p-2 text-sm" style={{ background: "rgba(226,186,44,0.1)", border: "1px solid rgba(226,186,44,0.25)", color: "var(--color-mustard-dark)" }}>
            Hinweis: Quell-Dump enthält 3 verwaiste Anhänge.
          </p>
        </div>
        <div className="mt-4 grid gap-2">
          <div className="flex items-center gap-2 text-sm font-semibold text-crimson">
            <Icon name="alert-triangle" size={16} />Destruktiver Import
          </div>
          <p className="select-all rounded-md border border-line bg-shell p-2 text-xs text-slate-600 font-mono">IMPORT-2026-05-12-OVERWRITE</p>
          <div className="flex gap-2">
            <input className="input flex-1 input-mono" placeholder="Bestätigungs-Phrase eingeben" />
            <Btn variant="danger" icon="cloud-download">Importieren</Btn>
          </div>
        </div>
      </section>
    </AppShell>
  );
};

// ───── Page 12: Settings → Testdaten ─────
window.SettingsSeedDataScreen = function () {
  useLucide();
  const runs = [
    { id: "seed-01HA2C3...4Q", label: "Demo-Daten Standard", date: "12.05.26 09:14", projects: 6, tasks: 84, files: 12, total: 312 },
    { id: "seed-01H9K7B...XT", label: "QA Kunden-360 Smoke", date: "08.05.26 17:42", projects: 3, tasks: 48, files: 6, total: 187 },
    { id: "seed-01H8RR8...M9", label: "Performance 1k Tasks", date: "02.05.26 11:01", projects: 12, tasks: 1024, files: 0, total: 1248 }
  ];
  return (
    <AppShell active="/settings/test-data">
      <PageHeader title="Testdaten" subtitle="Admin" action={<Btn icon="refresh-cw">Aktualisieren</Btn>} />
      <section className="section-card p-4">
        <div className="mb-4 flex items-center gap-2">
          <Icon name="database-zap" size={18} />
          <h2 className="text-base font-semibold">Neuer Seed-Run</h2>
        </div>
        <div className="flex gap-2">
          <input className="input flex-1" placeholder="Bezeichnung" />
          <Btn variant="primary" icon="database-zap">Erzeugen</Btn>
        </div>
      </section>
      <section className="section-card">
        <div className="flex items-center justify-between gap-3 border-b border-line p-4">
          <h2 className="text-base font-semibold">Seed-Runs</h2>
          <Badge tone="mute">{runs.length}</Badge>
        </div>
        <div className="divide-y divide-line">
          {runs.map((r) => (
            <article key={r.id} className="grid gap-3 p-4 md:grid-cols-[minmax(0,1fr)_auto] md:items-center">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-semibold text-ink">{r.label}</h3>
                  <Badge tone="mustard">Testdaten</Badge>
                </div>
                <p className="mt-1 break-all font-mono text-xs text-slate-500">{r.id}</p>
                <p className="mt-1 text-xs text-slate-500">{r.date}</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  <Badge tone="steel">{r.projects} Projekte</Badge>
                  <Badge tone="teal">{r.tasks} Aufgaben</Badge>
                  <Badge tone="violet">{r.files} Dateien</Badge>
                  <Badge tone="mute">{r.total} Einträge</Badge>
                </div>
              </div>
              <Btn variant="danger" icon="trash-2">Löschen</Btn>
            </article>
          ))}
        </div>
      </section>
    </AppShell>
  );
};
